"use client";

import { GLOBAL_CONSTANTS } from "@/constants";
import styled, { css } from "styled-components";

interface OtpSlotProps {
  isactive?: boolean;
}

interface OtpResendButtonProps {
  disabled?: boolean;
}

export const StyledAuthParentWrapper = styled.div`
  width: 100%;
  height: 100vh;
  background: url("/animations/WaveAnimation.svg") center/cover no-repeat;
  position: relative;
  overflow: auto;

  &::before,
  &::after {
    z-index: 1;
    content: "";
    position: absolute;
    top: 10px;
    width: 40%;
    height: 100vh;
    background: url("/assets/images/svgs/StarBg.svg") no-repeat;
    background-size: contain;
  }

  &::before {
    right: 10px;
  }

  &::after {
    left: 10px;
  }

  @media (max-width: ${GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.RESPONSIVE_WIDTH}px) {
    width: 100vw;
    height: 100vh;
    background-position: inherit;
    background: linear-gradient(221.02deg, #765bff 0%, #3b3799 98.95%);

    &::after {
      display: none;
    }

    &::before {
      width: 100%;
      height: 80vh;
    }
  }
`;

export const StyledAuthBox = styled.div`
  width: 600px;
  display: flex;
  flex-direction: column;
  gap: 32px;
  position: relative;
  z-index: 2;

  .company-logo {
    display: flex;
    align-items: center;
    gap: 10px;

    h1 {
      color: #fff;
      font-size: 25px;
      font-weight: 800;
    }
  }

  .mobile-welcome-message {
    display: none;
  }

  .auth-back-button {
    display: none;
  }

  .auth-card {
    width: 100%;
    display: flex;
    flex-direction: column;
    gap: 24px;
    padding: 36px;
    border-radius: 6px;
    background: #fff;
    box-shadow: 0px 15px 35px 0px #3c425714;
    box-shadow: 0px 5px 15px 0px #0000001f;

    .auth-card-heading {
      width: 100%;
      display: flex;
      flex-direction: column;
      gap: 4px;

      h2 {
        color: #3c4257;
        font-weight: 700;
        font-size: 24px;
      }

      .auth-card-otp-sub-heading {
        display: flex;
        align-items: center;
        gap: 6px;

        p {
          color: #3c4257;
          font-weight: 400;
        }
      }
    }

    .auth-card-credential-container {
      width: 100%;
      display: flex;
      flex-direction: column;
      gap: 12px;

      p {
        color: #3c4257;
        font-weight: 500;
      }

      .login-input {
        border: 1px solid #d9dce1;
        border-radius: 5px;
        padding: 6px 12px 6px 16px;
        outline: #635bff;

        &::placeholder {
          color: #a3acba;
          font-weight: 500;
        }
      }

      .auth-card-credential-container-otp-hint {
        color: #3c4257;
        font-weight: 400;
      }
    }

    .auth-card-button-container {
      width: 100%;

      .ant-btn-icon {
        display: flex;
      }

      .ant-btn-variant-outlined:not(:disabled):not(.ant-btn-disabled):hover {
        color: #fff !important;
      }

      button {
        width: 200px;
        background: #635cff;
        cursor: pointer;
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 10px;
        border-radius: 5px;
        padding: 8px 10px;
        font-weight: 600;
        font-size: 16px;
        transition: 0.5s ease all;

        &:hover {
          background-color: #4c43fd;

          svg {
            transform: translateX(5px);
          }
        }

        &:disabled {
          background: #635cff66;
          opacity: 0.7;
          cursor: not-allowed;
          pointer-events: none;
        }
      }
    }

    .auth-card-resend-otp-container {
      display: flex;
      justify-content: space-between;
      align-items: center;
      width: 100%;

      p {
        color: #6c7278;
        font-weight: 400;
        font-size: 12px;
      }
    }
  }

  .contact-support-container {
    width: 100%;

    .contact-support-container-button {
      width: fit-content;
      display: flex;
      align-items: center;
      gap: 10px;
      cursor: pointer;
      border-radius: 4px;
      padding: 3px 20px;

      p {
        color: #697386;
        font-weight: 500;
      }

      &:hover {
        background-color: #3c42570f;
      }
    }
  }

  .otp-inputs-slot-wrapper {
    width: 100%;
    display: flex;
    align-items: stretch;
    gap: 12px;
  }

  @media (max-width: ${GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.RESPONSIVE_WIDTH}px) {
    width: 90%;
    justify-content: center;
    align-items: center;
    gap: 30px;

    .auth-back-button {
      display: block;
      cursor: pointer;
      position: absolute;
      left: 5px;
      top: 10px;
    }

    .mobile-welcome-message {
      width: 100%;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      gap: 5px;

      h2 {
        color: #eeeeee;
        font-weight: 700;
        font-size: 30px;
      }

      p {
        color: #eeeeee;
        font-weight: 500;
      }
    }

    .auth-card {
      padding: 24px;

      .auth-card-heading {
        display: none;
      }

      .auth-card-credential-container {
        gap: 10px;

        p {
          color: #30313d;
          font-size: clamp(13px, 1vw, 14px);
        }

        .auth-card-credential-container-otp-hint {
          color: #30313d;
        }

        .login-input {
          font-size: 13px;

          &::placeholder {
            font-size: clamp(13px, 1vw, 14px);
          }
        }
      }

      .auth-card-button-container {
        button {
          padding: 6px 10px;
          width: 100%;
          font-size: clamp(14px, 1vw, 15px);
        }
      }
    }

    .contact-support-container {
      display: none;
    }
  }
`;

export const StyledOtpSlot = styled.div<OtpSlotProps>`
  flex: 1 1 calc(50% - 12px);
  height: 34px;
  background: #ffffff;
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 4px 8px;
  border-radius: 4px;
  border: 1px solid #d5dbe1;

  ${({ isactive }) =>
    isactive &&
    css`
      border-color: #635bff;
    `}
`;

export const StyledResendOTPButton = styled.div<OtpResendButtonProps>`
  width: 140px;
  display: flex;
  align-items: center;
  justify-content: flex-end;
  gap: 4px;
  border-radius: 4px;
  padding: 3px 10px;
  transition: 0.5s ease all;
  cursor: pointer;

  .resend-otp-text {
    color: #635bff !important;
    font-weight: 600;
    font-size: 12px;
  }

  /* &:hover {
    background-color: #635bff13;
  } */

  ${({ disabled }) =>
    disabled &&
    css`
      opacity: 0.6;
      cursor: not-allowed;
      pointer-events: none;
    `}
`;
