"use client";

import { useEffect, useRef, useState } from "react";
import { OTPInput, SlotProps } from "input-otp";
import { GLOBAL_SVGS } from "../common";
import { GLOBAL_CONSTANTS } from "@/constants";
import {
  StyledAuthBox,
  StyledAuthParentWrapper,
  StyledOtpSlot,
  StyledResendOTPButton,
} from "./Styles.Auth";
import { Button } from "antd";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";

export const AuthParentWrapper = ({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) => {
  useEffect(() => {
    if (
      typeof window !== "undefined" &&
      typeof window.ReactNativeWebView?.postMessage === "function"
    ) {
      window.ReactNativeWebView?.postMessage(
        JSON.stringify({
          type: "THEME",
          theme: "dark",
          topColor: "#6550E0",
          bottomColor: "#3E399E",
        })
      );
    }
  }, []);

  return <StyledAuthParentWrapper>{children}</StyledAuthParentWrapper>;
};

function Slot(props: SlotProps) {
  const { char = "", placeholderChar = "", isActive = false } = props || {};
  return (
    <StyledOtpSlot isactive={!!isActive}>
      {char ?? placeholderChar}
    </StyledOtpSlot>
  );
}

export function ResendOtpButton({
  onResendOTP = () => {},
}: {
  onResendOTP?: () => void;
}) {
  const [disabled, setDisabled] = useState(true);
  const [timer, setTimer] = useState(30);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  // Countdown logic
  const startCountdown = () => {
    setDisabled(true);
    setTimer(30);
    intervalRef.current = setInterval(() => {
      setTimer((prev) => {
        if (prev === 1) {
          if (intervalRef.current !== null) {
            clearInterval(intervalRef.current);
          }
          setDisabled(false);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  // On component mount, start initial countdown
  useEffect(() => {
    startCountdown();
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, []);

  // Simulated API call
  const handleClick = async () => {
    setDisabled(true);
    setTimer(30);
    onResendOTP();

    // After API call, restart countdown
    startCountdown();
  };

  return (
    <StyledResendOTPButton disabled={disabled} onClick={handleClick}>
      <GLOBAL_SVGS.ResendIcon />
      <p className="resend-otp-text">Resend OTP {timer > 0 && `in ${timer}`}</p>
    </StyledResendOTPButton>
  );
}

export const AuthBox = ({
  type = "login",
  loading = false,
  emailOrMobile = "",
  submitButtonEnabled = false,
  onChange = () => {},
  onSubmit = () => {},
  onBackButtonClick = () => {},
  onResendOTP = () => {},
}: {
  type?: string | undefined;
  emailOrMobile?: string | undefined;
  onChange?: (value: string) => void;
  onSubmit?: () => void;
  onResendOTP?: () => void;
  onBackButtonClick?: () => void;
  submitButtonEnabled?: boolean;
  loading?: boolean;
}) => {
  const isMobile = useIsSmallDevice();
  return (
    <StyledAuthBox>
      {type === "otp" && (
        <div className="auth-back-button" onClick={onBackButtonClick}>
          <GLOBAL_SVGS.BackButton />
        </div>
      )}
      <div className="company-logo">
        {!isMobile && <GLOBAL_SVGS.SkylioLogo />}
        {/* {appName ? (
          <Typography.Title
            level={1}
            style={{ color: "#fff" }}
            className="flex items-center justify-center gap-1"
          >
            {appName}
          </Typography.Title>
        ) : (
          <GLOBAL_SVGS.SkylioLogo />
        )} */}
      </div>
      <div className="mobile-welcome-message">
        {type === "login" && (
          <>
            <h2>Welcome</h2>
            <p>Please login to continue</p>
          </>
        )}
        {type === "otp" && (
          <>
            <h2>Verify OTP</h2>
            <p>OTP sent to {emailOrMobile} </p>
          </>
        )}
      </div>
      <div className="auth-card">
        <div className="auth-card-heading">
          <h2>{type === "login" ? "Log in to your account" : "Verify OTP"}</h2>
          {type === "otp" && !!emailOrMobile && (
            <div className="auth-card-otp-sub-heading">
              <GLOBAL_SVGS.TickIcon />
              <p>OTP sent to {emailOrMobile}</p>
            </div>
          )}
        </div>
        <div className="auth-card-credential-container">
          <p>
            {type === "login"
              ? "Mobile Number or Email"
              : `Enter ${GLOBAL_CONSTANTS.OTP_MAX_LENGTH} digit OTP`}
          </p>
          {type === "login" ? (
            <input
              className="login-input"
              placeholder={`+91 9988**2211 or abc@xyz.com`}
              onChange={(e) => onChange(e.target.value)}
              onKeyDown={(e) => {
                if (e?.key === "Enter" && submitButtonEnabled && !loading) {
                  onSubmit();
                }
              }}
            />
          ) : (
            <>
              <OTPInput
                maxLength={GLOBAL_CONSTANTS.OTP_MAX_LENGTH}
                onChange={(val) => onChange(val)}
                onKeyDown={(e) => {
                  if (e?.key === "Enter" && submitButtonEnabled && !loading) {
                    onSubmit();
                  }
                }}
                containerClassName="otp-inputs-slot-wrapper"
                render={({ slots }) => (
                  <>
                    {slots.map((slot, idx) => (
                      <Slot key={idx} {...slot} />
                    ))}
                  </>
                )}
              />
            </>
          )}
          {type === "login" && (
            <p className="auth-card-credential-container-otp-hint">
              You will receive an OTP on this number or email
            </p>
          )}
        </div>
        <div className="auth-card-button-container">
          <Button
            style={{ border: "none", color: "#fff" }}
            disabled={!submitButtonEnabled || loading}
            onClick={onSubmit}
            loading={loading}
            iconPosition={"end"}
          >
            {type === "login" ? "Get" : "Verify"} OTP{" "}
            {!loading && <GLOBAL_SVGS.ArrowIcon />}
          </Button>
        </div>
        {type === "otp" && (
          <div className="auth-card-resend-otp-container">
            <p>Didn&apos;t receive the OTP?</p>
            <ResendOtpButton onResendOTP={onResendOTP} />
          </div>
        )}
      </div>
      <div className="contact-support-container">
        {/* <div className="contact-support-container-button">
          <GLOBAL_SVGS.SupportIcon />
          <p>Contact support</p>
        </div> */}
      </div>
    </StyledAuthBox>
  );
};
