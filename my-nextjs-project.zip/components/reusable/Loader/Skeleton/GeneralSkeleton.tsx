import { Skeleton } from "antd";
import { StyledGeneralSkeleton } from "./Styles";

type SizeProps = "large" | "small" | "default" | undefined

function GeneralSkeleton({
  active = true,
  isLargeWrapped = false,
  size = "large",
  isBlock = true,
  countSmall = 2,
  countLarge = 2,
  largeBoxHeight = 200,
}) {
  const smallArr =
    Array(countSmall)
      ?.fill(0)
      ?.map((_, i) => i + 1) || [];

  const largeArr =
    Array(countLarge)
      ?.fill(0)
      ?.map((_, i) => i + 1) || [];

  return (
    <StyledGeneralSkeleton isLargeWrapped = {isLargeWrapped}>
      {smallArr?.map((val) => {
        return (
          <div key={val} className="small-loader-container">
            <Skeleton.Input active={active} size={size as SizeProps} block={isBlock} />
          </div>
        );
      })}
      {largeArr?.map((val) => {
        return (
          <div key={val} className="large-loader-container">
            <Skeleton.Input
              active={active}
              size={size as SizeProps}
              block={isBlock}
              style={{
                height: `${largeBoxHeight}px`,
              }}
            />
          </div>
        );
      })}
    </StyledGeneralSkeleton>
  );
}

export default GeneralSkeleton;