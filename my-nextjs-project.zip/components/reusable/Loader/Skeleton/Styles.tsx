"use client";

import styled from "styled-components";

export const StyledGeneralSkeleton = styled.div<{
    isLargeWrapped?: boolean
}>`
  width: 100%;
  display: flex;
  flex-wrap: wrap;
  gap: 15px;
  padding: 30px 0;

  .small-loader-container {
    flex: 1 1 calc(50% - 15px);
  }

  .large-loader-container {
    flex: ${({ isLargeWrapped }) => isLargeWrapped ? "1 1 calc(50% - 15px)" : "1 1 100%"};
  }
`;
