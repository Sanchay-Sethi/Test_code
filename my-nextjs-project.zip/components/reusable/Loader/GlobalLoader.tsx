'use client';

import { useEffect } from 'react';
import NProgress from 'nprogress';
import { useNavigation } from '@/lib/context/NavigationContext';
import 'nprogress/nprogress.css';

NProgress.configure({ showSpinner: false, speed: 400, minimum: 0.1 });

export default function GlobalLoader() {
  const { isNavigating } = useNavigation();

  useEffect(() => {
    if (isNavigating) {
      NProgress.start();
    } else {
      NProgress.done();
    }
  }, [isNavigating]);

  return null;
}
