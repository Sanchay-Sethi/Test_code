import { theme, Typography } from "antd";
import { StyledBrandLogo } from "./Styles.BrandLogo";
import Lottie from "lottie-react";
import Loading from "@/public/animations/lottie/loading.json";

const BrandLogoContainer = ({
  message = "",
}: {
  message?: string;
}) => {
  const { token } = theme.useToken();

  return (
    <StyledBrandLogo
      className={`fixed inset-0 flex items-center justify-center`}
      token={token}
    >
      <div className="animate-logo">
        <Lottie animationData={Loading} loop={true} />
      </div>
      {message && (
        <Typography.Text style={{ textAlign: "center" }}>
          {message}
        </Typography.Text>
      )}
    </StyledBrandLogo>
  );
};

const BrandLogo = ({ message = "" }) => {
  return <BrandLogoContainer message={message} />;
};

export default BrandLogo;

{
  /* {appName ? (
        <Image
          src={`/assets/icons/logos/schools/${appName}/logo.png`}
          alt="Loading..."
          preview={false}
          width={150}
          className="animate-logo"
          loading="eager"
        />
      ) : (
        // <Image
        //   src={"/assets/icons/logos/general/company-logo-purple-latest.svg"}
        //   alt="Loading..."
        //   preview={false}
        //   width={150}
        //   className="animate-logo"
        // />
        <Spin />
      )} */
}
