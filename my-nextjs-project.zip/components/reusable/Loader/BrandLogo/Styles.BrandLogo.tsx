"use client";
import { StyledContextProps } from "@/types";
import styled from "styled-components";

export const StyledBrandLogo = styled.div<StyledContextProps>`
  background-color: ${({ token }) => token?.colorBgBase || "#fff"};
  animation: bg-fade 1.8s cubic-bezier(0.66, 0, 0, 1) infinite;
  transition: background-color 0.3s ease-in-out;

  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  gap: 30px;
  height: 100dvh;
  width: 100dvw;
  z-index: 10000;

  .animate-logo {
    animation: pulse-cubic 1.8s cubic-bezier(0.66, 0, 0, 1) infinite;
    will-change: transform, opacity;
  }

  .animate-logo {
    transition: all 0.5s ease-in-out;
  }
`;
