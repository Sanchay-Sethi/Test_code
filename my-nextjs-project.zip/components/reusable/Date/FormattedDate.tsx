"use client";

import dayjs from "dayjs";
import { Tooltip } from "antd";

type FormattedDateProps = {
  dateString: string;
  format?: string;
};

const FormattedDate: React.FC<FormattedDateProps> = ({
  dateString,
  format = "D MMMM YYYY",
}) => {
  const formatted = dayjs(dateString).format(format);
  return (
    <Tooltip title={dateString}>
      <span>{formatted}</span>
    </Tooltip>
  );
};

export default FormattedDate;
