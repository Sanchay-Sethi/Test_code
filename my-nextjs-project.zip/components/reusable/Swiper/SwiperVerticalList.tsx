// Default free mode. If you want to use other props refer: https://swiperjs.com/react
"use client"
import { Swiper, SwiperProps } from "swiper/react";
import { FreeMode } from "swiper/modules";
import "swiper/css";
import "swiper/css/free-mode";
import "swiper/css/pagination";
import "./styles.css";
import { StyledVerticalSwiperContent } from "./Styles.Swiper";

const SwiperVerticalList = ({
  children,
  styles,
  ...props
}: Readonly<{
  children?: React.ReactNode;
  props?: SwiperProps;
  styles?: string;
}>) => {

  return (
    <StyledVerticalSwiperContent styles={styles}>
      <Swiper
        slidesPerView={'auto'}
        spaceBetween={15}
        freeMode={true}
        modules={[FreeMode]}
        className="skylio-swiper"
        direction="vertical"
        autoHeight
        {...(props || {})}
      >
        {children}
      </Swiper>
    </StyledVerticalSwiperContent>
  );
};

export default SwiperVerticalList;
