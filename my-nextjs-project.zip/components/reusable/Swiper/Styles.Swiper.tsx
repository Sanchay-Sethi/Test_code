"use client";

import styled from "styled-components";

interface StyledSwiperContentProps {
  styles?: string;
}

export const StyledSwiperContent = styled.div<StyledSwiperContentProps>`
  .swiper {
    width: 100%;
    padding: 13px;
  }
  ${({ styles }) => styles || ""}
`;

export const StyledVerticalSwiperContent = styled.div<StyledSwiperContentProps>`
  .swiper {
    width: 100%;
    height: 100%;
    padding-bottom: 20px;
  }

  .skylio-swiper {
    -webkit-overflow-scrolling: touch;
    touch-action: auto;
  }

  ${({ styles }) => styles || ""}
`;
