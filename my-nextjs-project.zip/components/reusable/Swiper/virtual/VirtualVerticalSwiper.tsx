'use client';

import { useRef, useEffect, useCallback } from "react";
import { useVirtualizer } from "@tanstack/react-virtual";
import { Swiper, SwiperSlide } from "swiper/react";
import { FreeMode } from "swiper/modules";
import "swiper/css";
import "swiper/css/free-mode";
import "../styles.css";
import { StyledVerticalSwiperContent } from "../Styles.Swiper";

type VirtualSwiperProps<T> = {
  items: T[];
  styles?: string;
  containerHeight?: string;
  cardEstimateWidth?: number;
  renderItem: (item: T, index: number) => React.ReactNode;
  getKey?: (item: T, index: number) => string | number;
  onScrollChange?: (isScrolling: boolean, scrollRef: HTMLDivElement | null) => void;
};

function VirtualSwiper<T>({
  items,
  styles,
  containerHeight = "calc(100vh - 150px)",
  cardEstimateWidth = 110,
  renderItem,
  getKey = (_, index) => index,
  onScrollChange,
}: VirtualSwiperProps<T>) {
  const parentRef = useRef<HTMLDivElement>(null);

  const virtualizer = useVirtualizer({
    count: items.length,
    getScrollElement: () => parentRef.current,
    estimateSize: () => cardEstimateWidth,
    overscan: 5,
    measureElement: (el) => el.getBoundingClientRect().height,
  });

  const handleScroll = useCallback(() => {
    if (parentRef.current && onScrollChange) {
      const isNotAtTop = parentRef.current.scrollTop > 0;
      onScrollChange(isNotAtTop, parentRef.current);
    }
  }, [onScrollChange]);

  useEffect(() => {
    const el = parentRef.current;
    if (!el) return;

    el.addEventListener("scroll", handleScroll);
    return () => el.removeEventListener("scroll", handleScroll);
  }, [handleScroll]);

  return (
    <StyledVerticalSwiperContent styles={styles}>
      <div
        ref={parentRef}
        style={{
          height: containerHeight,
          overflowY: "auto",
        }}
      >
        <div
          style={{
            height: virtualizer.getTotalSize(),
            position: "relative",
          }}
        >
          {virtualizer.getVirtualItems().map((virtualRow) => {
            const item = items[virtualRow.index];
            const key = getKey(item, virtualRow.index);
            return (
              <div
                key={key}
                ref={virtualizer.measureElement}
                style={{
                  position: "absolute",
                  top: 0,
                  left: 0,
                  width: "100%",
                  transform: `translateY(${virtualRow.start}px)`,
                }}
              >
                <Swiper
                  slidesPerView={"auto"}
                  spaceBetween={15}
                  freeMode={true}
                  modules={[FreeMode]}
                  direction="vertical"
                  className="skylio-swiper"
                  autoHeight
                  allowTouchMove={false}
                >
                  <SwiperSlide>
                    {renderItem(item, virtualRow.index)}
                  </SwiperSlide>
                </Swiper>
              </div>
            );
          })}
        </div>
      </div>
    </StyledVerticalSwiperContent>
  );
}

export default VirtualSwiper;
