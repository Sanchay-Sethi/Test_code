// Default free mode. If you want to use other props refer: https://swiperjs.com/react

import { Swiper, SwiperProps } from "swiper/react";
import { FreeMode } from "swiper/modules";
import "swiper/css";
import "swiper/css/free-mode";
import "swiper/css/pagination";
import "./styles.css";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";
import { StyledSwiperContent } from "./Styles.Swiper";

const SwiperContent = ({
  children,
  styles,
  ...props
}: Readonly<{
  children?: React.ReactNode;
  props?: SwiperProps;
  styles?: string;
}>) => {
  const isMediumDevice = useIsSmallDevice(900);
  const isSmallDevice = useIsSmallDevice(600);

  return (
    <StyledSwiperContent styles={styles}>
      <Swiper
        slidesPerView={isSmallDevice ? 1 : isMediumDevice ? 2 : 4}
        spaceBetween={10}
        freeMode={true}
        modules={[FreeMode]}
        className="skylio-swiper"
        {...(props || {})}
      >
        {children}
      </Swiper>
    </StyledSwiperContent>
  );
};

export default SwiperContent;
