"use client";

import { useState } from "react";
import { Upload, Button, message, Drawer, Spin, Typography } from "antd";
import type { UploadFile, UploadProps } from "antd/es/upload/interface";
import { CloseOutlined, InboxOutlined } from "@ant-design/icons";
import GeneralModal from "../Modal/GeneralModal/Modal";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";
import { GLOBAL_CONSTANTS } from "@/constants";
import { ButtonInlineStyles } from "@/components/common/styles.common";

const { Dragger } = Upload;

interface ImportModalProps
  extends Omit<UploadProps, "onChange" | "beforeUpload" | "fileList"> {
  open: boolean;
  onClose: () => void;
  onUpload: (files: UploadFile[]) => void | Promise<void>;
  multiple?: boolean;
  accept?: string; // e.g. ".pdf,.xls,.xlsx"
  maxSizeMB?: number; // file size limit per file
  title?: string;
}

const ImportModal: React.FC<ImportModalProps> = ({
  open,
  onClose,
  onUpload,
  multiple = false,
  accept,
  maxSizeMB = 5,
  title = "Import Files",
  ...draggerProps
}) => {
  const isMobile = useIsSmallDevice();
  const [fileList, setFileList] = useState<UploadFile[]>([]);
  const [uploading, setUploading] = useState(false);

  const beforeUpload: UploadProps["beforeUpload"] = (file) => {
    if (window.ReactNativeWebView && window.ReactNativeWebView.postMessage) {
      window.ReactNativeWebView.postMessage(
        JSON.stringify({ type: "REQUEST_UPLOAD_PERMISSION" })
      );
    }

    const isTooLarge = file.size / 1024 / 1024 > maxSizeMB;
    if (isTooLarge) {
      message.error(`${file.name} is larger than ${maxSizeMB}MB`);
      return Upload.LIST_IGNORE;
    }

    if (accept) {
      const acceptedTypes = accept
        .split(",")
        .map((ext) => ext.trim().toLowerCase());

      const fileExt = "." + file.name.split(".").pop()?.toLowerCase();
      if (!acceptedTypes.includes(fileExt)) {
        message.error(`${file.name} is not a supported file type`);
        return Upload.LIST_IGNORE;
      }
    }

    return true;
  };

  const handleUpload = async () => {
    if (fileList.length === 0) {
      message.warning("Please select at least one file");
      return;
    }
    setUploading(true);
    try {
      await onUpload(fileList);
      setFileList([]);
      onClose();
    } finally {
      setUploading(false);
    }
  };

  function getBody() {
    return (
      <Spin spinning={uploading}>
        <Dragger
          multiple={multiple}
          accept={accept}
          fileList={fileList}
          beforeUpload={beforeUpload}
          onChange={({ fileList }) => {
            if (!multiple) {
              setFileList(fileList.slice(-1));
            } else {
              setFileList(fileList);
            }
          }}
          itemRender={(originNode) => originNode}
          {...draggerProps}
        >
          <p className="ant-upload-drag-icon">
            <InboxOutlined />
          </p>
          <p className="ant-upload-text">
            Click or drag file to this area to upload
          </p>
          <p className="ant-upload-hint">
            {multiple
              ? "You can upload multiple files."
              : "Only one file can be uploaded."}
            <br />
            Max size per file: {maxSizeMB}MB
          </p>
        </Dragger>
      </Spin>
    );
  }

  if (isMobile) {
    return (
      <Drawer
        onClose={onClose}
        open={open}
        placement="bottom"
        height={"60%"}
        closable={false}
        style={{
          borderTopLeftRadius:
            GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.BORDER_RADIUS,
          borderTopRightRadius:
            GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.BORDER_RADIUS,
        }}
        footer={
          <div className="flex items-center justify-center gap-2">
            <Button style={ButtonInlineStyles} block onClick={onClose}>
              Cancel
            </Button>
            <Button
              type="primary"
              style={ButtonInlineStyles}
              block
              onClick={handleUpload}
              disabled={uploading}
              loading={uploading}
            >
              Upload
            </Button>
          </div>
        }
        title={
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Typography.Title level={5}>{title}</Typography.Title>
            </div>
            <Button onClick={onClose} shape="circle">
              <CloseOutlined />
            </Button>
          </div>
        }
      >
        {getBody()}
      </Drawer>
    );
  }

  return (
    <GeneralModal
      open={open}
      customTitle={title}
      onCancel={onClose}
      footer={[
        <Button key="cancel" onClick={onClose} disabled={uploading}>
          Cancel
        </Button>,
        <Button
          key="upload"
          type="primary"
          onClick={handleUpload}
          loading={uploading}
          disabled={uploading}
        >
          Upload
        </Button>,
      ]}
    >
      {getBody()}
    </GeneralModal>
  );
};

export default ImportModal;
