import { useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import { Badge, Button, DatePicker, Input, Popover, Spin, theme } from "antd";
import { DownOutlined } from "@ant-design/icons";
import { useNavigation } from "@/lib/context/NavigationContext";
import { StyledPopupOptions, StyledPopupOutput } from "./Styles.Filters";
import { useGlobalValues } from "@/lib/hooks/useGlobalValues";
import dayjs from 'dayjs';
import { PAYMENT_METHODS } from "@/components/home/Fee/components/RecordPayment";

const { RangePicker } = DatePicker;

const BUTTON_TYPES = {
  BRANCH: "Branch",
  STUDENT_PHONE: "Phone",
  PHONE: "Phone",
  DATE_RANGE: "Date range",
  PAYMENT_MODE: "Mode",
};

const SEARCH_PARAM_IDS = {
  BRANCH: "branchId",
  STUDENT_PHONE: "studentPhone",
  PHONE: "phone",
  DATE_RANGE: "startDate_endDate",
  PAYMENT_MODE: "mode",
};

interface OptionsTypes {
  name?: string;
  id?: string;
  label?: string;
  value?: string;
}

const PopupOptions = ({ type = "", onCancel = () => {} }) => {
  const { navigate } = useNavigation();
  const searchParams = useSearchParams();
  const { BRANCHES_OPTIONS } = useGlobalValues();
  const { token } = theme.useToken();

  const [loading, setLoading] = useState(false);
  const [options, setOptions] = useState<OptionsTypes[]>();
  const [value, setValue] = useState("");
  const [dates, setDates] = useState<{
    startDate: string | null;
    endDate: string | null;
  }>({
    startDate: null,
    endDate: null,
  });

  const onDateChange = (
    values: [dayjs.Dayjs | null, dayjs.Dayjs | null] | null,
    dateStrings: [string, string]
  ) => {
    setDates({
      startDate: dateStrings[0] || null,
      endDate: dateStrings[1] || null,
    });
  };

  async function getOptions(type = "") {
    if (type === "BRANCH") {
      try {
        setLoading(true);
        setOptions(BRANCHES_OPTIONS);
      } finally {
        setLoading(false);
      }
    }
    if (type === "PAYMENT_MODE") {
      try {
        setLoading(true);
        const options = Object?.keys(PAYMENT_METHODS || {})?.map(key => {
          return {
            value: key,
            label: key,
          }
        })
        setOptions(options);
      } finally {
        setLoading(false);
      }
    }
  }

  function handleClick(type = "", value = "", startDate?: string | null, endDate?: string | null) {
    if (type === "BRANCH") {
      const params = new URLSearchParams(searchParams.toString());
      if (
        value ===
        searchParams?.get(
          SEARCH_PARAM_IDS[type as keyof typeof SEARCH_PARAM_IDS]
        )
      ) {
        params.delete("branchId");
      } else {
        params.set("branchId", value);
      }
      navigate(`?${params.toString()}`);
    }
    if (type === "PAYMENT_MODE") {
      const params = new URLSearchParams(searchParams.toString());
      if (
        value ===
        searchParams?.get(
          SEARCH_PARAM_IDS[type as keyof typeof SEARCH_PARAM_IDS]
        )
      ) {
        params.delete("mode");
      } else {
        params.set("mode", value);
      }
      navigate(`?${params.toString()}`);
    }
    if (type === "STUDENT_PHONE") {
      const params = new URLSearchParams(searchParams.toString());
      if (
        value ===
        searchParams?.get(
          SEARCH_PARAM_IDS[type as keyof typeof SEARCH_PARAM_IDS]
        )
      ) {
        params.delete("studentPhone");
      } else {
        params.set("studentPhone", value);
      }
      navigate(`?${params.toString()}`);
      onCancel();
    }
    if (type === "PHONE") {
      const params = new URLSearchParams(searchParams.toString());
      if (
        value ===
        searchParams?.get(
          SEARCH_PARAM_IDS[type as keyof typeof SEARCH_PARAM_IDS]
        )
      ) {
        params.delete("phone");
      } else {
        params.set("phone", value);
      }
      navigate(`?${params.toString()}`);
      onCancel();
    }
    if (type === "DATE_RANGE") {
      const params = new URLSearchParams(searchParams.toString());
      if (startDate && endDate) {
        params.set("startDate", startDate);
        params.set("endDate", endDate);
      } else {
         params.delete("startDate");
         params.delete("endDate");
      }
      navigate(`?${params.toString()}`);
      onCancel();
    }
  }

  function handleClear() {
    handleClick(type, value)
    setValue("");
  }

  function handleDateClear() {
    handleClick(type, "", "", "");
    setDates({
      startDate: null,
      endDate: null,
    })
  }

  useEffect(() => {
    getOptions(type);
    setValue(searchParams?.get(SEARCH_PARAM_IDS[type as keyof typeof SEARCH_PARAM_IDS]) || "");
    setDates({startDate: searchParams?.get("startDate") || "", endDate: searchParams?.get("endDate") || ""});
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [type]);

  if (type === "STUDENT_PHONE" || type === "PHONE") {
    return (
      <StyledPopupOutput token={token}>
        <Input
          value={value}
          onChange={(e)=>setValue(e.target.value)}
          placeholder="98XXXXXXX"
        />
        <div className="popup-footer-buttons">
          <Button onClick={handleClear}>Clear</Button>
          <Button type="primary" onClick={()=>handleClick(type, value)}>Filter</Button>
        </div>
      </StyledPopupOutput>
    )
  }

  if (type === "DATE_RANGE") {
    return (
      <StyledPopupOutput token={token}>
        <RangePicker
           value={[
              dates.startDate ? dayjs(dates.startDate) : null,
              dates.endDate ? dayjs(dates.endDate) : null,
            ]}
          onChange={onDateChange}
          allowEmpty={[true, true]}
        />
        <div className="popup-footer-buttons">
          <Button onClick={handleDateClear}>Clear</Button>
          <Button type="primary" onClick={()=>handleClick(type, "", dates.startDate, dates.endDate)}>Filter</Button>
        </div>
      </StyledPopupOutput>
    )
  }

  return (
    <StyledPopupOptions>
      {loading ? (
        <Spin />
      ) : (
        options?.map((option) => {
          const isButtonHighlighted =
            searchParams?.get(
              SEARCH_PARAM_IDS[type as keyof typeof SEARCH_PARAM_IDS]
            ) === option?.value;
          return (
            <div key={option?.value} className="filter-button-option">
              <Button
                color={isButtonHighlighted ? "primary" : "default"}
                variant={isButtonHighlighted ? "filled" : "text"}
                block
                style={{
                  display: "flex",
                  justifyContent: "flex-start",
                }}
                onClick={() => handleClick(type, option?.value)}
              >
                {option?.label}
              </Button>
            </div>
          );
        })
      )}
    </StyledPopupOptions>
  );
};

const FilterButton = ({ type = "" }) => {
  const [openDropdown, setOpenDropdown] = useState(false);

  const searchParams = useSearchParams();

  const isActive = type !== "DATE_RANGE" ? !!searchParams?.get(
    SEARCH_PARAM_IDS[type as keyof typeof SEARCH_PARAM_IDS]
  ) : !!(searchParams?.get("startDate") && searchParams?.get("endDate"));

  function handleCancel() {
    setOpenDropdown(false);
  }

  if (type) {
    return (
      <Popover
        content={<PopupOptions type={type} onCancel = {handleCancel}/>}
        trigger="click"
        arrow={false}
        open={openDropdown}
        onOpenChange={setOpenDropdown}
        placement={"bottomLeft"}
      >
        <Badge dot={isActive}>
          <Button
            icon={
              <DownOutlined
                style={{ fontSize: 10 }}
                rotate={!openDropdown ? 0 : 180}
              />
            }
            color={isActive ? "primary" : "default"}
            variant={isActive ? "filled" : "outlined"}
            iconPosition="end"
          >
            {BUTTON_TYPES?.[type as keyof typeof BUTTON_TYPES]}
          </Button>
        </Badge>
      </Popover>
    );
  }
  return null;
};

export default FilterButton;
