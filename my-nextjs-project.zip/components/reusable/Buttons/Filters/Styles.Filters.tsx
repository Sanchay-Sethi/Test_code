"use client"

import styled, { css } from "styled-components";
import { StyledContextProps } from "@/types";

export const StyledPopupOptions = styled.div<StyledContextProps>`
    width: 100%;
    display: flex;
    flex-direction: column;
    gap: 5px;

    ${({ isDrawer }) => isDrawer && css`
        padding: 10px 24px 20px 0;

        .ant-picker-panels {
            display: flex;
            flex-direction: column;
        }
    `}
`;

export const StyledPopupOutput = styled.div<StyledContextProps>`
    width: 100%;
    display: flex;
    flex-direction: column;
    gap: 18px;

    ${({ isDrawer }) => isDrawer && css`
        padding: 10px 24px 20px 0;
    `}

    .popup-footer-buttons {
        display: flex;
        align-items: center;
        justify-content: flex-end;
        gap: 6px;
        padding: 8px 8px;
        border-radius: 10px;
        border: 0.5px solid ${({ token }) => token?.colorBorder};
    }
`;