"use client";

import { useEffect, useState } from "react";
import { CloseOutlined, DownOutlined } from "@ant-design/icons";
import {
  Badge,
  Button,
  DatePicker,
  Drawer,
  Input,
  Radio,
  Spin,
  Tabs,
  theme,
  Typography,
} from "antd";
import { ReadonlyURLSearchParams, useSearchParams } from "next/navigation";
import { FILTER_ICON } from "./Icons.FilterDrawer";
import { GLOBAL_CONSTANTS } from "@/constants";
import { ButtonInlineStyles } from "@/components/common/styles.common";
import { StyledFilterDrawer } from "./styles.FilterDrawer";
import { useGlobalValues } from "@/lib/hooks/useGlobalValues";
import { StyledPopupOptions } from "../../Buttons/Filters/Styles.Filters";
import { useNavigation } from "@/lib/context/NavigationContext";
import dayjs from "dayjs";
import { PAYMENT_METHODS } from "@/components/home/Fee/components/RecordPayment";

const { RangePicker } = DatePicker;

interface SavedFilterTypes {
  [key: string]: string;
}

const SEARCH_PARAM_IDS = {
  BRANCH: {
    id: "BRANCH",
    value: "branchId",
  },
  STUDENT_PHONE: {
    id: "STUDENT_PHONE",
    value: "studentPhone",
  },
  PHONE: {
    id: "PHONE",
    value: "phone",
  },
  PAYMENT_MODE: {
    id: "PAYMENT_MODE",
    value: "mode",
  },
  DATE_RANGE: {
    id: "DATE_RANGE",
    value: "startDate_endDate",
  },
};

const TYPE_LABEL = {
  BRANCH: "Branch",
  STUDENT_PHONE: "Phone",
  PHONE: "Phone",
  DATE_RANGE: "Date range",
  PAYMENT_MODE: "Mode",
};

const FilterTypeChildren = ({
  type = "",
  savedFilters = {},
  onClick,
}: {
  type: string;
  savedFilters: SavedFilterTypes;
  onClick: (
    type: string,
    value: string,
    mapVal: { [key: string]: string }
  ) => void;
}) => {
  const { BRANCHES_OPTIONS } = useGlobalValues();

  const [loading, setLoading] = useState(false);
  const [options, setOptions] = useState<OptionsTypes[]>();

  const [value, setValue] = useState("");
  const [dates, setDates] = useState<{
    startDate: string | null;
    endDate: string | null;
  }>({
    startDate: null,
    endDate: null,
  });

  async function getOptions(type = "") {
    if (type === "BRANCH") {
      try {
        setLoading(true);
        setOptions(BRANCHES_OPTIONS);
      } finally {
        setLoading(false);
      }
    }
    if (type === "PAYMENT_MODE") {
      try {
        setLoading(true);
        const options = Object?.keys(PAYMENT_METHODS || {})?.map((key) => {
          return {
            value: key,
            label: key,
          };
        });
        setOptions(options);
      } finally {
        setLoading(false);
      }
    }
  }

  function handleClick(type = "", value = "", mapVal = {}) {
    onClick(type, value, mapVal);
  }

  const onDateChange = (
    values: [dayjs.Dayjs | null, dayjs.Dayjs | null] | null,
    dateStrings: [string, string]
  ) => {
    console.log({
      dateStrings,
    });
    handleClick(type, "", {
      startDate: dateStrings[0] || null,
      endDate: dateStrings[1] || null,
    });
  };

  useEffect(() => {
    getOptions(type);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [type]);

  useEffect(() => {
    if (type === "STUDENT_PHONE" || type === "PHONE") {
      setValue(savedFilters?.[type]);
    }
    if (type === "DATE_RANGE") {
      setDates({
        startDate: savedFilters?.["startDate"],
        endDate: savedFilters?.["startDate"],
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [JSON.stringify(savedFilters), type]);

  if (type === "STUDENT_PHONE" || type === "PHONE") {
    return (
      <StyledPopupOptions isDrawer>
        <Input
          value={value}
          onChange={(e) => handleClick(type, e.target.value)}
          placeholder="98XXXXXXX"
          style={{ width: "100%" }}
        />
      </StyledPopupOptions>
    );
  }

  if (type === "DATE_RANGE") {
    return (
      <StyledPopupOptions isDrawer>
        <RangePicker
          value={[
            dates.startDate ? dayjs(dates.startDate) : null,
            dates.endDate ? dayjs(dates.endDate) : null,
          ]}
          onChange={onDateChange}
          allowEmpty={[true, true]}
        />
      </StyledPopupOptions>
    );
  }

  return (
    <StyledPopupOptions isDrawer>
      {loading ? (
        <Spin />
      ) : (
        options?.map((option) => {
          const isButtonHighlighted = savedFilters?.[type] === option?.value;

          return (
            <div key={option?.value} className="filter-button-option">
              <Radio
                checked={isButtonHighlighted}
                onClick={() =>
                  handleClick(type, isButtonHighlighted ? "" : option?.value)
                }
              >
                {option?.label}
              </Radio>
            </div>
          );
        })
      )}
    </StyledPopupOptions>
  );
};

function getIsActive(types: string[], searchParams: ReadonlyURLSearchParams) {
  let isActive = false;
  types?.forEach((type) => {
    if (type === "DATE_RANGE") {
      if (searchParams?.get("startDate") && searchParams?.get("endDate")) {
        isActive = true;
      }
    } else {
      if (
        searchParams?.get(
          SEARCH_PARAM_IDS[type as keyof typeof SEARCH_PARAM_IDS]?.value
        )
      ) {
        isActive = true;
      }
    }
  });
  return isActive;
}

const FilterDrawer = ({ types = [] }: { types: string[] }) => {
  const [openDropdown, setOpenDropdown] = useState(false);
  const [savedFilters, setSavedFilters] = useState<SavedFilterTypes>({});

  const { navigate } = useNavigation();

  const { token } = theme.useToken();
  const searchParams = useSearchParams();

  const isActive = getIsActive(types, searchParams);

  function handleDrawerOpen() {
    setOpenDropdown(true);
  }

  function handleCloseDrawer() {
    setOpenDropdown(false);
  }

  function handleFilterClick(type = "", value = "", mapVal = {}) {
    setSavedFilters((prev) => {
      return {
        ...(prev || {}),
        [type]: value,
        ...(mapVal || {}),
      };
    });
  }

  function getTabChildren(type = "") {
    return (
      <FilterTypeChildren
        type={type}
        onClick={handleFilterClick}
        savedFilters={savedFilters}
      />
    );
  }

  function getTabsItems() {
    return types?.map((type) => {
      return {
        label: TYPE_LABEL?.[type as keyof typeof TYPE_LABEL] || type,
        key: type,
        children: getTabChildren(type),
      };
    });
  }

  console.log({
    savedFilters,
  });

  function handleApply(savedFilters = {}) {
    const params = new URLSearchParams(searchParams.toString());
    Object?.keys(savedFilters)?.forEach((type) => {
      if (type === "startDate") {
        if (savedFilters?.["startDate" as keyof typeof savedFilters]) {
          params.set(
            "startDate",
            savedFilters?.["startDate" as keyof typeof savedFilters]
          );
        } else {
          params.delete("startDate");
        }
      } else if (type === "endDate") {
        if (savedFilters?.["endDate" as keyof typeof savedFilters]) {
          params.set(
            "endDate",
            savedFilters?.["endDate" as keyof typeof savedFilters]
          );
        } else {
          params.delete("endDate");
        }
      } else {
        if (savedFilters?.[type as keyof typeof savedFilters]) {
          params.set(
            SEARCH_PARAM_IDS[type as keyof typeof SEARCH_PARAM_IDS]?.value,
            savedFilters?.[type as keyof typeof savedFilters]
          );
        } else {
          params.delete(
            SEARCH_PARAM_IDS[type as keyof typeof SEARCH_PARAM_IDS]?.value
          );
        }
      }
    });
    navigate(`?${params.toString()}`);
    handleCloseDrawer();
  }

  function getResetSavedFilters() {
    let obj = {};
    Object.keys(savedFilters || {})?.forEach((key) => {
      obj = {
        ...(obj || {}),
        [key]: "",
      };
    });
    return obj;
  }

  function handleClear() {
    const resetFilters = getResetSavedFilters();
    setSavedFilters(resetFilters || {});
    handleApply(resetFilters || {});
  }

  useEffect(() => {
    const params: Record<string, string> = {};
    for (const [key, value] of searchParams?.entries()) {
      Object.values(SEARCH_PARAM_IDS || {})?.forEach((type) => {
        if (type.id === "DATE_RANGE" && value) {
          if (key === "startDate") {
            params["startDate"] = value;
          }
          if (key === "endDate") {
            params["endDate"] = value;
          }
        } else {
          if (type?.value === key && value) {
            params[type?.id] = value;
          }
        }
      });
    }
    setSavedFilters(params);
  }, [searchParams]);

  return (
    <>
      <Badge count={Object?.keys(savedFilters)?.length}>
        <Button
          color={isActive ? "primary" : "default"}
          variant={isActive ? "dashed" : "outlined"}
          onClick={handleDrawerOpen}
          icon={<FILTER_ICON />}
        >
          Filters{" "}
          <DownOutlined
            style={{ fontSize: 10 }}
            rotate={!openDropdown ? 0 : 180}
          />
        </Button>
      </Badge>
      <Drawer
        onClose={handleCloseDrawer}
        open={openDropdown}
        placement="bottom"
        height={"100%"}
        closable={false}
        style={{
          borderTopLeftRadius:
            GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.BORDER_RADIUS,
          borderTopRightRadius:
            GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.BORDER_RADIUS,
        }}
        styles={{
          body: {
            background: token?.colorGreyBgBase,
            padding: 10,
          },
        }}
        footer={
          <div className="flex items-center justify-center gap-2">
            <Button style={ButtonInlineStyles} block onClick={handleClear}>
              Clear
            </Button>
            <Button
              type="primary"
              style={ButtonInlineStyles}
              block
              onClick={() => handleApply(savedFilters)}
            >
              Apply
            </Button>
          </div>
        }
        title={
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <FILTER_ICON />
              <Typography.Title level={5}>Filter by</Typography.Title>
            </div>
            <Button onClick={handleCloseDrawer} shape="circle">
              <CloseOutlined />
            </Button>
          </div>
        }
      >
        <StyledFilterDrawer token={token}>
          <Tabs
            defaultActiveKey={types?.[0]}
            tabPosition={"left"}
            style={{
              height: "100%",
            }}
            items={getTabsItems()}
          />
        </StyledFilterDrawer>
      </Drawer>
    </>
  );
};

export default FilterDrawer;
