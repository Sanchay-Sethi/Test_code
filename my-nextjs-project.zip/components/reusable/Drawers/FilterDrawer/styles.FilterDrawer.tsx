"use client"

import styled from "styled-components"
import { StyledContextProps } from "@/types"

export const StyledFilterDrawer = styled.div<StyledContextProps>`
    height: 100%;
    background-color: ${({ token }) => token?.colorBgBase};
    border-radius: 10px;
`