"use client"

import { useState } from "react";
import { Input, Button, Drawer, Typography } from "antd";
import { AiOutlineDelete } from "react-icons/ai";
import GeneralModal from "../GeneralModal/Modal";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";
import { GLOBAL_CONSTANTS } from "@/constants";
import { ButtonInlineStyles } from "@/components/common/styles.common";
import { CloseOutlined } from "@ant-design/icons";

interface ConfirmDeleteModalProps {
  open: boolean;
  onConfirm: () => void;
  onCancel: () => void;
  title?: string;
  content?: string;
}

const ConfirmDeleteModal: React.FC<ConfirmDeleteModalProps> = ({
  open,
  onConfirm,
  onCancel,
  title = "Confirm Delete",
  content = "Type 'delete' to confirm this action.",
}) => {
  const [value, setValue] = useState("");
  const isMobile = useIsSmallDevice();

  const handleOk = () => {
    if (value.toLowerCase() === "delete") {
      onConfirm();
      setValue("");
    }
  };

  const handleCancel = () => {
    setValue("");
    onCancel();
  };

  function getBody() {
    return (
      <div className="flex flex-col gap-2">
        <Typography.Paragraph>{content}</Typography.Paragraph>
        <Input
          placeholder="Type delete"
          value={value}
          onChange={(e) => setValue(e.target.value)}
        />
      </div>
    );
  }

  if (isMobile) {
    return (
      <Drawer
        onClose={handleCancel}
        open={open}
        placement="bottom"
        height={"65%"}
        closable={false}
        style={{
          borderTopLeftRadius:
            GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.BORDER_RADIUS,
          borderTopRightRadius:
            GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.BORDER_RADIUS,
        }}
        footer={
          <div className="flex items-center justify-center gap-2">
            <Button style={ButtonInlineStyles} block onClick={handleCancel}>
              Cancel
            </Button>
            <Button
              type="primary"
              style={ButtonInlineStyles}
              block
              onClick={handleOk}
              disabled={value.toLowerCase() !== "delete"}
              danger
            >
              Delete
            </Button>
          </div>
        }
        title={
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <AiOutlineDelete />
              <Typography.Title level={5}>Confirm delete</Typography.Title>
            </div>
            <Button onClick={handleCancel} shape="circle">
              <CloseOutlined />
            </Button>
          </div>
        }
      >
        {getBody()}
      </Drawer>
    );
  }

  return (
    <GeneralModal
      customTitle={title}
      open={open}
      onCancel={handleCancel}
      footer={[
        <Button key="cancel" onClick={handleCancel}>
          Cancel
        </Button>,
        <Button
          key="confirm"
          danger
          type="primary"
          disabled={value.toLowerCase() !== "delete"}
          onClick={handleOk}
        >
          Delete
        </Button>,
      ]}
    >
      {getBody()}
    </GeneralModal>
  );
};

export default ConfirmDeleteModal;
