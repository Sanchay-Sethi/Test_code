"use client";

import { StyledContextProps } from "@/types";
import { Modal } from "antd";
import styled from "styled-components";

export const StyledGeneralModal = styled(Modal)<StyledContextProps>`
  .ant-modal-title {
    display: flex;
    align-items: center;
    gap: 10px;
  }
`;
