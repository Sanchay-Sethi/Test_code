import { ConfigProvider, ModalProps, theme } from "antd";
import { StyledGeneralModal } from "./Styles.Modal";

type FooterType = ModalProps["footer"];

const GeneralModal = ({
  customTitle,
  titleIcon,
  open = false,
  onOk = () => {},
  onCancel = () => {},
  footer = null,
  blurMask = "blur(6px)",
  children,
  ...props
}: {
  customTitle?: React.ReactNode | string;
  open?: boolean;
  blurMask?: string;
  onCancel?: () => void;
  onOk?: () => void;
  titleIcon?: React.ReactNode;
  children?: React.ReactNode;
  footer?: FooterType;
}) => {
  const { token } = theme.useToken();

  const modalStyles = {
    header: {
      padding: "16px 24px",
      marginBottom: 0,
      borderBottom: `1px solid ${token?.colorBorder}`,
      display: "flex",
      alignItems: "center",
      gap: 8,
    },
    body: {
      padding: "16px 24px",
      borderRadius: 6,
    },
    mask: {
      backdropFilter: blurMask,
    },
    footer: {
      borderTop: `1px solid ${token?.colorBorder}`,
      padding: "16px 24px",
    },
    content: {
      padding: 0,
    },
  };

  return (
    <ConfigProvider
      modal={{
        styles: modalStyles,
      }}
    >
      <StyledGeneralModal
        title={
          customTitle ? (
            <>
              {titleIcon} {customTitle}
            </>
          ) : null
        }
        open={open}
        onCancel={onCancel}
        onOk={onOk}
        token={token}
        footer={footer}
        {...(props || {})}
      >
        {children}
      </StyledGeneralModal>
    </ConfigProvider>
  );
};

export default GeneralModal;
