import React from "react";
import { StyledStudentFeeMobileCard } from "./styles.StudentFeeMobileCard";
import { Button, theme, Typography } from "antd";
import { ButtonInlineSmallStyles } from "@/components/common/styles.common";
import { CLASS_ICON } from "@/components/home/Students/Icons";

const StudentFeeMobileCard = ({
  details,
  onClick = () => {},
}: {
  details: FeeLineItems;
  onClick: (record: { studentId?: string }) => void;
}) => {
  const { token } = theme.useToken();

  function handleClick() {
    onClick({
      studentId: details?.studentId,
    });
  }

  return (
    <StyledStudentFeeMobileCard token={token} onClick={handleClick}>
      <div className="flex justify-between items-center gap-2">
        <Typography.Title
          level={5}
          style={{ fontSize: "15px", fontWeight: 600 }}
        >
          {details?.studentName}
        </Typography.Title>
        <Button
          color="primary"
          variant="outlined"
          style={ButtonInlineSmallStyles}
          onClick={handleClick}
        >
          Collect
        </Button>
      </div>
      <div className="flex justify-between items-center gap-2">
        <div className="flex flex-col gap-1">
          <Typography.Text strong type="secondary" ellipsis>
            Collected
          </Typography.Text>
          <Typography.Text type="success" strong ellipsis>
            + Rs {details?.paid?.toLocaleString()}
          </Typography.Text>
        </div>
        <div className="flex flex-col gap-1">
          <Typography.Text strong type="secondary" ellipsis>
            Amount due
          </Typography.Text>
          <Typography.Text type="danger" strong ellipsis>
            - Rs {details?.dues?.toLocaleString()}
          </Typography.Text>
        </div>
        <div className="flex flex-col gap-1">
          <Typography.Text strong type="secondary" ellipsis>
            Overdue by
          </Typography.Text>
          <Typography.Text ellipsis>
            {details?.maxOverdueDays?.toLocaleString()} days
          </Typography.Text>
        </div>
      </div>
      <div className="flex justify-between items-center gap-3 flex-wrap">
        <div className="flex items-center gap-1.5">
          <div className="icon-container-student">
            <CLASS_ICON />
          </div>
          <Typography.Paragraph style={{ fontSize: "13px" }}>
            {details?.programName}
          </Typography.Paragraph>
        </div>
        <div className="tag-admission-container">
          <Typography.Text style={{ fontSize: "12px" }}>
            {details?.admissionNumber}
          </Typography.Text>
        </div>
      </div>
    </StyledStudentFeeMobileCard>
  );
};

export default StudentFeeMobileCard;
