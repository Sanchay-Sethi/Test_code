"use client";

import { StyledContextProps } from "@/types";
import styled, { css } from "styled-components";

export const StyledStudentFeeMobileCard = styled.div<StyledContextProps>`
  width: 100%;
  padding: 16px 24px;
  display: flex;
  flex-direction: column;
  gap: 16px;
  border-radius: 8px;
  cursor: pointer;
  position: relative;
  background-color: ${({ token }) => token?.colorBgBase};
  border: 1px solid transparent;

  .tag-admission-container {
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 4px 6px;
    background-color: ${({ token }) => token?.colorCustomTag};
    border-radius: 8px;
    font-weight: 500;
  }

  .select-pay-box {
    position: absolute;
    left: 13px;
    top: 16px;
  }

  ${({ disabled }) => disabled && css`
    pointer-events: none;
    opacity: 0.3;
  `}

  ${({ isSelected, token }) => isSelected && css`
    border-color: ${token?.colorPrimary};
  `}
  
`;
