import React from "react";
import { StyledStudentFeeMobileCard } from "./styles.StudentFeeMobileCard";
import { Checkbox, theme, Typography } from "antd";
import FormattedDate from "../../Date/FormattedDate";

const StudentFeeTermCard = ({
  isSelected = false,
  isDisabled = false,
  details,
  onClick = () => {},
}: {
  isSelected: boolean;
  isDisabled: boolean;
  details: FeeLineItems;
  onClick: (record: FeeLineItems, selected: boolean) => void;
}) => {
  const { token } = theme.useToken();

  function handleClick() {
    onClick(details, !isSelected);
  }

  return (
    <StyledStudentFeeMobileCard
      token={token}
      onClick={handleClick}
      disabled={isDisabled}
      isSelected={isSelected}
    >
      <div className="select-pay-box">
        <Checkbox
          checked={isSelected}
          onChange={(e) => onClick(details, e.target.checked)}
        />
      </div>
      <div className="flex justify-between items-center gap-2">
        <Typography.Title
          level={5}
          style={{ fontSize: "14px", fontWeight: 600, marginLeft: "15px" }}
        >
          {details?.name}
        </Typography.Title>
        <Typography.Title
          level={5}
          style={{ fontSize: "14px", fontWeight: 600, marginTop: 0 }}
        >
          Rs {details?.toPay?.toLocaleString()}
        </Typography.Title>
      </div>
      <div className="flex justify-between items-center gap-2">
        <div className="flex flex-col gap-1">
          <Typography.Text strong type="secondary" ellipsis>
            Due date
          </Typography.Text>
          <Typography.Text strong ellipsis>
            <FormattedDate dateString={details?.dueDate || ""} />
          </Typography.Text>
        </div>
        <div className="flex flex-col gap-1">
          <Typography.Text strong type="secondary" ellipsis>
            Dues
          </Typography.Text>
          <Typography.Text type="danger" strong ellipsis>
            - Rs {details?.dues?.toLocaleString()}
          </Typography.Text>
        </div>
        <div className="flex flex-col gap-1">
          <Typography.Text strong type="secondary" ellipsis>
            Paid
          </Typography.Text>
          <Typography.Text type="success" strong ellipsis>
            + Rs {details?.paid?.toLocaleString()}
          </Typography.Text>
        </div>
      </div>
    </StyledStudentFeeMobileCard>
  );
};

export default StudentFeeTermCard;
