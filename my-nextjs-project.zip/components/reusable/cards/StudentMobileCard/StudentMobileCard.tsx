"use client";

import { CLASS_ICON } from "@/components/home/Students/Icons";
import { GLOBAL_CONSTANTS } from "@/constants";
import { Button, Tag, theme, Typography } from "antd";
import { StyledStudentMobileCard } from "./styles.StudentMobileCard";
import { Student } from "@/lib/context/students/studentsTypes";
import { ButtonInlineSmallStyles } from "@/components/common/styles.common";

const StudentMobileCard = ({
  details,
  onClick = () => {},
  isPayment,
}: {
  details: Student;
  onClick: (record: { id?: string }) => void;
  isPayment?: boolean;
}) => {
  const { token } = theme.useToken();

  function handleClick() {
    onClick({
      id: details?.id,
    });
  }

  return (
    <StyledStudentMobileCard token={token} onClick={handleClick}>
      <div className="flex justify-between items-center gap-3 flex-wrap">
        <Typography.Title
          level={5}
          style={{ fontSize: "15px", fontWeight: 600 }}
        >
          {details?.name}
        </Typography.Title>
        {isPayment ? (
          <Button color="primary" variant="outlined" onClick={handleClick} style={ButtonInlineSmallStyles}>
            Collect
          </Button>
        ) : (
          <Tag
            color={
              GLOBAL_CONSTANTS?.TAG_STATUS_COLOR?.[
                details?.status as keyof typeof GLOBAL_CONSTANTS.TAG_STATUS_COLOR
              ]
            }
            key={details?.status}
          >
            {details?.status}
          </Tag>
        )}
      </div>
      <div className="flex justify-between items-center gap-3 flex-wrap">
        <div className="flex items-center gap-1.5">
          <div className="icon-container-student">
            <CLASS_ICON />
          </div>
          <Typography.Paragraph style={{ fontSize: "13px" }}>
            {details?.programName}
          </Typography.Paragraph>
        </div>
        <div className="tag-admission-container">
          <Typography.Text style={{ fontSize: "12px" }}>
            {details?.admissionNumber}
          </Typography.Text>
        </div>
      </div>
    </StyledStudentMobileCard>
  );
};

export default StudentMobileCard;
