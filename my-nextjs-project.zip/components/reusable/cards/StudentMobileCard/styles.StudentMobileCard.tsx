"use client";

import { StyledContextProps } from "@/types";
import styled from "styled-components";

export const StyledStudentMobileCard = styled.div<StyledContextProps>`
  width: 100%;
  padding: 12px 20px;
  display: flex;
  flex-direction: column;
  gap: 20px;
  border-radius: 8px;
  cursor: pointer;
  background-color: ${({ token }) => token?.colorBgBase};

  .tag-admission-container {
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 4px 6px;
    background-color: ${({ token }) => token?.colorCustomTag};
    border-radius: 8px;
    font-weight: 500;
  }
`;
