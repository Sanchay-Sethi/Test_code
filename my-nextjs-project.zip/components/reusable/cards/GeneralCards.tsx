"use client";

import { TbFileDescription } from "react-icons/tb";
import {
  Badge,
  Button,
  DatePicker,
  Drawer,
  Input,
  InputNumber,
  message,
  Popconfirm,
  Tag,
  theme,
  Tooltip,
  Typography,
} from "antd";
import { CiLocationArrow1 } from "react-icons/ci";
import { BiPencil, BiTrashAlt } from "react-icons/bi";
import { HiOutlinePencil } from "react-icons/hi";
import { StyledGeneralCards, StyledPlanCards } from "./styles.cards";
import { GLOBAL_CONSTANTS } from "@/constants";
import { BRANCHES_ICON, PHONE_ICON } from "./Icons.cards";
import { CheckOutlined, CloseOutlined } from "@ant-design/icons";
import dayjs from "dayjs";
import { ButtonInlineStyles } from "@/components/common/styles.common";
import React, { useEffect, useState } from "react";
import FormattedDate from "../Date/FormattedDate";
import ConfirmDeleteModal from "../Modal/common/ConfirmDeleteModal";

export const BranchCard = ({
  data,
  branchid = "",
  onDelete = () => {},
  onEdit = () => {},
}: {
  branchid: string;
  data: SchoolBranchTypes;
  onDelete: () => void;
  onEdit: () => void;
}) => {
  const { token } = theme.useToken();

  return (
    <StyledGeneralCards token={token}>
      <div className="flex items-center justify-between gap-2">
        <Typography.Title level={5} ellipsis>
          {data?.name}
        </Typography.Title>
        <div className="flex items-center gap-2">
          <Button
            type="text"
            icon={<HiOutlinePencil />}
            color="primary"
            variant="outlined"
            onClick={onEdit}
          ></Button>
          {branchid !== data?.id && (
            <Popconfirm
              title="Delete branch"
              description="Are you sure to delete this branch?"
              onConfirm={onDelete}
              okText="Yes"
              cancelText="No"
            >
              <Button
                type="text"
                icon={<BiTrashAlt />}
                color="danger"
                variant="outlined"
              ></Button>
            </Popconfirm>
          )}
        </div>
      </div>
      <div className="flex items-center gap-1.5">
        <CiLocationArrow1 />
        <Typography.Text type="secondary" ellipsis title={data?.address}>
          {data?.address || "Not added"}
        </Typography.Text>
      </div>
    </StyledGeneralCards>
  );
};

export const PlanCard = ({
  data,
  onDelete = () => {},
  onEdit = () => {},
}: {
  data: FeePlanTypes;
  onDelete: () => void;
  onEdit: () => void;
}) => {
  const { token } = theme.useToken();

  return (
    <StyledPlanCards token={token}>
      <div className="flex items-center justify-around gap-2">
        <Typography.Title level={5} ellipsis>
          {data?.name}{" "}
        </Typography.Title>
        <Tag>{data?.type}</Tag>
        <div className="flex items-center gap-2">
          <Button
            type="text"
            icon={<HiOutlinePencil />}
            color="primary"
            variant="outlined"
            onClick={onEdit}
          ></Button>
          <Popconfirm
            title="Delete plan"
            description="Are you sure to delete this plan?"
            onConfirm={onDelete}
            okText="Yes"
            cancelText="No"
          >
            <Button
              type="text"
              icon={<BiTrashAlt />}
              color="danger"
              variant="outlined"
            ></Button>
          </Popconfirm>
        </div>
      </div>
      <div className="flex items-center gap-1.5">
        <TbFileDescription />
        <Typography.Text type="secondary" ellipsis title={data?.description}>
          {data?.description || "Not added"}
        </Typography.Text>
      </div>
    </StyledPlanCards>
  );
};

export const UserMobileCard = ({
  data,
  onDelete = () => {},
  onEdit = () => {},
}: {
  data: UsersType;
  onDelete: () => void;
  onEdit: () => void;
  isRole?: boolean;
}) => {
  const { token } = theme.useToken();

  return (
    <StyledPlanCards token={token}>
      <div className="flex items-center justify-between gap-2">
        <Typography.Title level={5} ellipsis>
          {data?.name}{" "}
        </Typography.Title>
        <div className="flex items-center gap-2">
          <Button
            type="text"
            icon={<HiOutlinePencil />}
            color="primary"
            variant="outlined"
            onClick={onEdit}
          ></Button>
          <Popconfirm
            title="Delete user"
            description="Are you sure to delete this user?"
            onConfirm={onDelete}
            okText="Yes"
            cancelText="No"
          >
            <Button
              type="text"
              icon={<BiTrashAlt />}
              color="danger"
              variant="outlined"
            ></Button>
          </Popconfirm>
        </div>
      </div>
      <div className="flex items-center justify-between gap-2">
        <div className="flex flex-col flex-1/3">
          <Typography.Text strong ellipsis type="secondary">
            Role
          </Typography.Text>
          <Typography.Text ellipsis style={{ width: 100 }}>
            {data?.role?.length > 15
              ? data?.role?.slice(0, 15) + "..."
              : data?.role}
          </Typography.Text>
        </div>
        <div className="flex flex-col flex-1/3">
          <Typography.Text strong ellipsis type="secondary">
            # branches
          </Typography.Text>
          <div className="flex items-center gap-2">
            <BRANCHES_ICON />
            <Typography.Text ellipsis>{data?.branches?.length}</Typography.Text>
          </div>
        </div>
        <div className="flex flex-col flex-1/3 items-end justify-end">
          <Typography.Text strong ellipsis type="secondary">
            Phone no.
          </Typography.Text>
          <div className="flex items-center gap-2">
            <PHONE_ICON />
            <Typography.Text ellipsis>
              {data?.mobile || "Not added"}
            </Typography.Text>
          </div>
        </div>
      </div>
    </StyledPlanCards>
  );
};

export const FeeStructureCard = ({
  data,
  onDelete = () => {},
  onEdit = () => {},
  isDiscount = false,
}: {
  data: FeeStructureData;
  onDelete: () => void;
  onEdit: () => void;
  isDiscount?: boolean;
}) => {
  const { token } = theme.useToken();

  return (
    <StyledPlanCards token={token}>
      <div className="flex items-center justify-between gap-2">
        <Typography.Title level={5} ellipsis>
          {data?.planName || data?.name}{" "}
        </Typography.Title>
        <div className="flex items-center gap-2">
          <Button
            type="text"
            icon={<HiOutlinePencil />}
            color="primary"
            variant="outlined"
            onClick={onEdit}
          ></Button>
          <Popconfirm
            title="Delete fee"
            description="Are you sure to delete this fee?"
            onConfirm={onDelete}
            okText="Yes"
            cancelText="No"
          >
            <Button
              type="text"
              icon={<BiTrashAlt />}
              color="danger"
              variant="outlined"
            ></Button>
          </Popconfirm>
        </div>
      </div>
      <div className="flex items-center justify-between gap-2">
        <div className="flex flex-col flex-1/3">
          <Typography.Text strong ellipsis type="secondary">
            # branches
          </Typography.Text>
          <div className="flex items-center gap-2">
            <BRANCHES_ICON />
            <Typography.Text ellipsis>
              {Object.keys(data?.branchIdNameMap || {})?.length}
            </Typography.Text>
          </div>
        </div>
        <div className="flex flex-col flex-1/3 items-end justify-end">
          <Typography.Text strong ellipsis type="secondary">
            {isDiscount ? "Discount" : "Annual Fee"}
          </Typography.Text>
          <div className="flex items-center gap-2">
            <Typography.Text ellipsis>
              {isDiscount
                ? `${data?.value} %`
                : `Rs. ${data?.totalAmount || "-"}`}
            </Typography.Text>
          </div>
        </div>
      </div>
    </StyledPlanCards>
  );
};

export const RoleMobileCard = ({
  data,
  onDelete = () => {},
  onEdit = () => {},
}: {
  data: RolesOptionsTypes;
  onDelete: () => void;
  onEdit: () => void;
  isRole?: boolean;
}) => {
  const { token } = theme.useToken();

  return (
    <StyledPlanCards token={token}>
      <div className="flex items-center justify-between gap-2">
        <Typography.Title level={5} ellipsis>
          {data?.name}{" "}
        </Typography.Title>
        <div className="flex items-center gap-2">
          <Button
            type="text"
            icon={<HiOutlinePencil />}
            color="primary"
            variant="outlined"
            onClick={onEdit}
          ></Button>
          <Popconfirm
            title="Delete role"
            description="Are you sure to delete this role?"
            onConfirm={onDelete}
            okText="Yes"
            cancelText="No"
          >
            <Button
              type="text"
              icon={<BiTrashAlt />}
              color="danger"
              variant="outlined"
            ></Button>
          </Popconfirm>
        </div>
      </div>
      <div className="flex items-center justify-between gap-2">
        <div className="flex flex-col flex-1 w-[90%]">
          <Typography.Text strong ellipsis type="secondary">
            {data?.description || "Not added"}
          </Typography.Text>
        </div>
      </div>
    </StyledPlanCards>
  );
};

export const ProgramMobileCard = ({
  data,
  onEdit = () => {},
}: {
  data: ProgramSectionTypes;
  onEdit: () => void;
}) => {
  const { token } = theme.useToken();

  return (
    <StyledPlanCards token={token}>
      <div className="flex items-center justify-between gap-2">
        <Typography.Title level={5} ellipsis>
          {data?.name}{" "}
        </Typography.Title>
        <div className="flex items-center gap-2">
          <Button
            type="text"
            icon={<HiOutlinePencil />}
            color="primary"
            variant="outlined"
            onClick={onEdit}
          ></Button>
        </div>
      </div>
      {data?.levelOrder && (
        <div className="flex items-center justify-between gap-2">
          <div className="flex flex-col flex-1 w-[90%]">
            <Typography.Text strong ellipsis type="secondary">
              Level {data?.levelOrder}
            </Typography.Text>
          </div>
        </div>
      )}
    </StyledPlanCards>
  );
};

export const AcademicYearCard = ({
  data,
  onMakeCurrent = () => {},
}: {
  data: AcademicYearProps;
  onMakeCurrent: () => void;
}) => {
  const { token } = theme.useToken();

  return (
    <StyledPlanCards token={token}>
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <Typography.Text ellipsis style={{ width: "90px" }}>
            {data?.name}{" "}
          </Typography.Text>
          {data?.state !== "CURRENT" && (
            <div className="flex items-center gap-2">
              <Button
                type="text"
                color="primary"
                variant="outlined"
                onClick={onMakeCurrent}
                size="small"
              >
                Make current
              </Button>
            </div>
          )}
        </div>
        <Badge
          color={
            GLOBAL_CONSTANTS?.ACADEMIC_YEAR_STATE_COLOR?.[
              // eslint-disable-next-line @typescript-eslint/ban-ts-comment
              // @ts-expect-error
              data?.state
            ]
          }
          text={
            GLOBAL_CONSTANTS?.ACADEMIC_YEAR_STATE?.[
              // eslint-disable-next-line @typescript-eslint/ban-ts-comment
              // @ts-expect-error
              data?.state
            ]
          }
        />
      </div>
    </StyledPlanCards>
  );
};

export const FeeItemCard = ({
  data,
  isEditing = false,
  onEdit = () => {},
  onSave = () => {},
  onCancel = () => {},
  onDelete = () => {},
  editableRow,
  onChange = () => {},
  errors,
}: {
  data: feeItemType;
  isEditing: boolean;
  onEdit: () => void;
  onSave: () => void;
  onCancel: () => void;
  onDelete: () => void;
  editableRow: feeItemType | null;
  onChange: (key: string, value: string | string[] | number | null) => void;
  errors: Partial<Record<keyof feeItemType, string>>;
}) => {
  const { token } = theme.useToken();

  return (
    <StyledGeneralCards token={token}>
      <div className="flex items-center justify-between gap-2">
        {!isEditing ? (
          <Typography.Title level={5} ellipsis>
            {data?.name}{" "}
          </Typography.Title>
        ) : (
          <div className="flex-col items-start w-full">
            <Input
              value={editableRow?.name}
              placeholder="eg. Term x fee"
              onChange={(e) => {
                onChange("name", e.target.value);
              }}
              status={errors?.name ? "error" : ""}
            />
            <div style={{ color: "red", fontSize: 12 }}>{errors.name}</div>
          </div>
        )}

        {isEditing ? (
          <div className="flex items-center gap-2">
            <Tooltip title="Confirm">
              <Button
                type="text"
                color="green"
                variant="outlined"
                onClick={onSave}
                icon={<CheckOutlined />}
                shape={"circle"}
                size="small"
              />
            </Tooltip>
            <Tooltip title="Cancel">
              <Button
                type="text"
                color={"danger"}
                variant="outlined"
                onClick={onCancel}
                icon={<CloseOutlined />}
                shape={"circle"}
                size="small"
              />
            </Tooltip>
          </div>
        ) : (
          <div className="flex items-center gap-2">
            <Button
              type="text"
              icon={<HiOutlinePencil />}
              color="primary"
              variant="outlined"
              onClick={onEdit}
            ></Button>
            {data?.id && (
              <Popconfirm
                title="Delete plan"
                description="Are you sure to delete this plan?"
                onConfirm={onDelete}
                okText="Yes"
                cancelText="No"
              >
                <Button
                  type="text"
                  icon={<BiTrashAlt />}
                  color="danger"
                  variant="outlined"
                ></Button>
              </Popconfirm>
            )}
          </div>
        )}
      </div>
      <div className="flex items-center justify-between gap-2">
        <div className="flex flex-col flex-1 w-[90%]">
          <Typography.Text strong ellipsis type="secondary">
            Due date
          </Typography.Text>
          {!isEditing ? (
            <Typography.Text ellipsis>{data?.dueDate} </Typography.Text>
          ) : (
            <div className="flex-col items-start w-full">
              <DatePicker
                value={
                  editableRow?.dueDate ? dayjs(editableRow?.dueDate) : undefined
                }
                format="MMM D, YYYY"
                onChange={(date, dateStr) => {
                  onChange("dueDate", dateStr);
                }}
                style={{
                  width: "100%",
                }}
                status={errors?.dueDate ? "error" : ""}
              />
              <div style={{ color: "red", fontSize: 12 }}>
                {errors?.dueDate}
              </div>
            </div>
          )}
        </div>
        <div className="flex flex-col flex-1 w-[90%] justify-end items-end">
          <Typography.Text strong ellipsis type="secondary">
            Amount
          </Typography.Text>
          {!isEditing ? (
            <Typography.Text ellipsis>
              Rs. {data?.amount?.toLocaleString()}{" "}
            </Typography.Text>
          ) : (
            <div className="flex-col items-start w-full">
              <InputNumber
                min={0}
                value={editableRow?.amount}
                placeholder="Rs. XXXX"
                onChange={(val) => {
                  onChange("amount", val);
                }}
                status={errors?.amount ? "error" : ""}
                style={{ width: "100%" }}
              />
              <div style={{ color: "red", fontSize: 12 }}>{errors?.amount}</div>
            </div>
          )}
        </div>
      </div>
    </StyledGeneralCards>
  );
};

export const SchoolCard = ({
  data,
  onDelete = () => {},
  onEdit = () => {},
  deleteShown = false,
}: {
  data: SchoolsDetailsProps;
  onDelete: () => void;
  onEdit: () => void;
  deleteShown?: boolean;
}) => {
  const { token } = theme.useToken();
  const [deleteModal, setDeleteModal] = useState(false);

  return (
    <StyledPlanCards token={token}>
      <div className="flex items-center justify-between gap-2">
        <Typography.Title level={5} ellipsis>
          {data?.name}{" "}
        </Typography.Title>
        <div className="flex items-center gap-2">
          <Button
            type="text"
            icon={<HiOutlinePencil />}
            color="primary"
            variant="outlined"
            onClick={onEdit}
          ></Button>
          {deleteShown && (
            <>
              <Button
                type="text"
                icon={<BiTrashAlt />}
                color="danger"
                variant="outlined"
                onClick={() => setDeleteModal(true)}
              ></Button>
              <ConfirmDeleteModal
                open={deleteModal}
                onConfirm={onDelete}
                onCancel={() => setDeleteModal(false)}
              />
            </>
          )}
        </div>
      </div>
      <div className="flex items-center justify-between gap-2">
        <div className="flex flex-col flex-1/3">
          <Typography.Text strong ellipsis type="secondary">
            Display Name
          </Typography.Text>
          <Typography.Text ellipsis>
            {data?.displayName || "Not added"}
          </Typography.Text>
        </div>
      </div>
    </StyledPlanCards>
  );
};

export const AdminCard = ({
  data,
  onDelete = () => {},
  onEdit = () => {},
  deleteShown = false,
}: {
  data: PodAdminProps;
  onDelete: () => void;
  onEdit: () => void;
  deleteShown?: boolean;
}) => {
  const { token } = theme.useToken();

  return (
    <StyledPlanCards token={token}>
      <div className="flex items-center justify-between gap-2">
        <Typography.Title level={5} ellipsis>
          {data?.name}{" "}
        </Typography.Title>
        <div className="flex items-center gap-2">
          <Button
            type="text"
            icon={<HiOutlinePencil />}
            color="primary"
            variant="outlined"
            onClick={onEdit}
          ></Button>
          {deleteShown && (
            <Popconfirm
              title="Delete user"
              description="Are you sure to delete this user?"
              onConfirm={onDelete}
              okText="Yes"
              cancelText="No"
            >
              <Button
                type="text"
                icon={<BiTrashAlt />}
                color="danger"
                variant="outlined"
              ></Button>
            </Popconfirm>
          )}
        </div>
      </div>
      <div className="flex items-center justify-between gap-2">
        <div className="flex flex-col flex-1/2">
          <Typography.Text strong ellipsis type="secondary">
            Email
          </Typography.Text>
          <Typography.Text ellipsis>
            {data?.email || "Not added"}
          </Typography.Text>
        </div>
        <div className="flex flex-col flex-1/2">
          <Typography.Text strong ellipsis type="secondary">
            Phone
          </Typography.Text>
          <Typography.Text ellipsis>
            {data?.mobile || "Not added"}
          </Typography.Text>
        </div>
      </div>
    </StyledPlanCards>
  );
};

export const EnrolmentCard = ({
  data,
  onEdit = () => {},
  editShown = false,
}: {
  data: EnrolmentTypes;
  onEdit: () => void;
  editShown: boolean;
}) => {
  const { token } = theme.useToken();

  return (
    <StyledGeneralCards token={token}>
      <div className="flex items-center justify-between gap-2">
        <Typography.Title level={5} ellipsis>
          {data?.className}{" "}
        </Typography.Title>
        <div className="flex items-center gap-2">
          {editShown && (
            <Button
              type="text"
              icon={<HiOutlinePencil />}
              color="primary"
              variant="outlined"
              onClick={onEdit}
            ></Button>
          )}
        </div>
      </div>
      <div className="flex items-center justify-between gap-2">
        <div className="flex flex-col flex-1/2">
          <Typography.Text strong ellipsis type="secondary">
            Academic year
          </Typography.Text>
          <Typography.Text ellipsis>
            {data?.academicYearName || "None"}
          </Typography.Text>
        </div>
      </div>
    </StyledGeneralCards>
  );
};

export const FeeCard = ({
  data,
  onClick = () => {},
  onCancel = () => {},
  onSave = () => {},
  activeId = "",
}: {
  data: StudentFeeLineItemTypes;
  onClick: () => void;
  onCancel: () => void;
  onSave: (id?: string, value?: number) => void;
  activeId: string;
}) => {
  const { token } = theme.useToken();

  const [messageApi, contextHolder] = message.useMessage();
  const [inputValue, setInputValue] = useState<number | null>(null);

  function handleSave() {
    if (inputValue == null) {
      return messageApi.open({
        type: "error",
        content: "Please provide discount value",
      });
    }
    onSave(data?.id, inputValue || 0);
  }

  function handleCancel() {
    setInputValue(null);
    onCancel();
  }

  useEffect(() => {
    setInputValue(data?.discount || 0);
  }, [data?.discount, activeId]);

  return (
    <StyledPlanCards token={token}>
      <div className="flex items-center justify-between gap-2 mb-2">
        <Typography.Title level={5} ellipsis>
          {data?.name}{" "}
        </Typography.Title>
        <div className="flex items-center gap-2">
          <Typography.Title level={5} ellipsis>
            Rs. {data?.toPay?.toLocaleString()}{" "}
          </Typography.Title>
        </div>
      </div>
      <div className="flex items-center justify-between gap-5">
        <div className="flex flex-col flex-1/3">
          <Typography.Text strong ellipsis type="secondary">
            Due date
          </Typography.Text>
          <Typography.Text ellipsis style={{ fontSize: "12px" }}>
            {data?.dueDate}{" "}
          </Typography.Text>
        </div>
        <div className="flex flex-col flex-1/3">
          <Typography.Text strong ellipsis type="secondary">
            Fees
          </Typography.Text>
          <Typography.Text ellipsis style={{ fontSize: "12px" }}>
            Rs. {data?.fee?.toLocaleString()}{" "}
          </Typography.Text>
        </div>
        <div className="flex flex-col flex-1/3 items-end">
          <Typography.Text strong ellipsis type="secondary">
            Fee due
          </Typography.Text>
          <Typography.Text ellipsis style={{ fontSize: "12px" }}>
            Rs. {data?.dues?.toLocaleString()}{" "}
          </Typography.Text>
        </div>
      </div>
      <div className="flex items-center justify-between gap-2">
        <div className="flex flex-col flex-1/2">
          <Typography.Text strong ellipsis type="secondary">
            Fees paid
          </Typography.Text>
          <Typography.Text ellipsis type="success">
            Rs. {data?.paid?.toLocaleString()}{" "}
          </Typography.Text>
        </div>
        <div className="flex flex-col flex-1/2 items-end">
          <Typography.Text strong ellipsis type="secondary">
            Discount
          </Typography.Text>
          <Typography.Text ellipsis type={"danger"}>
            - Rs. {data?.discount?.toLocaleString()}{" "}
            <Button
              shape="circle"
              color="primary"
              variant={"text"}
              icon={<BiPencil />}
              onClick={onClick}
            />
          </Typography.Text>
        </div>
      </div>
      <Drawer
        onClose={handleCancel}
        open={activeId === data?.id}
        placement="bottom"
        height={"45%"}
        closable={false}
        style={{
          borderTopLeftRadius:
            GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.BORDER_RADIUS,
          borderTopRightRadius:
            GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.BORDER_RADIUS,
        }}
        footer={
          <div className="flex items-center justify-center gap-2">
            <Button style={ButtonInlineStyles} block onClick={handleCancel}>
              Cancel
            </Button>
            <Button
              type="primary"
              style={ButtonInlineStyles}
              block
              onClick={handleSave}
            >
              Save
            </Button>
          </div>
        }
        title={
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Typography.Title level={5}>Edit discount</Typography.Title>
            </div>
            <Button onClick={handleCancel} shape="circle">
              <CloseOutlined />
            </Button>
          </div>
        }
      >
        <div className="flex items-center gap-1.5">
          {contextHolder}
          <InputNumber
            min={0}
            value={inputValue}
            placeholder="Rs. XXXX"
            onChange={(val) => setInputValue(val)}
            status={inputValue == null ? "error" : ""}
            style={{ width: "100%" }}
          />
        </div>
      </Drawer>
    </StyledPlanCards>
  );
};

export const PaymentCard = ({
  data,
  extra,
}: {
  data: PaymentTypes;
  extra?: React.ReactNode;
}) => {
  const { token } = theme.useToken();

  return (
    <StyledPlanCards token={token}>
      <div className="flex items-center justify-between gap-2 mb-2">
        <Typography.Title level={5} ellipsis>
          {data?.studentName}{" "}
        </Typography.Title>
        <div className="flex items-center gap-2">
          <Typography.Title level={5} ellipsis type="success">
            Rs. {data?.amount?.toLocaleString()}{" "}
          </Typography.Title>
          {extra}
        </div>
      </div>
      <div className="flex items-center justify-between gap-5">
        <div className="flex flex-col flex-1/2">
          <Typography.Text strong ellipsis type="secondary">
            Date
          </Typography.Text>
          <FormattedDate dateString={data?.paymentDate} />
        </div>
        <div className="flex flex-col flex-1/2 items-end">
          <Typography.Text strong ellipsis type="secondary">
            Mode
          </Typography.Text>
          <Typography.Text ellipsis style={{ fontSize: "12px" }}>
            {data?.mode}
          </Typography.Text>
        </div>
      </div>
      <div className="flex items-center justify-between gap-2">
        <div className="flex flex-col flex-1/2">
          <Typography.Text strong ellipsis type="secondary">
            Admission id
          </Typography.Text>
          <Typography.Text ellipsis>{data?.admissionNo}</Typography.Text>
        </div>
        <div className="flex flex-col flex-1/2 items-end">
          <Typography.Text strong ellipsis type="secondary">
            Class
          </Typography.Text>
          <Typography.Text ellipsis>{data?.className}</Typography.Text>
        </div>
      </div>
    </StyledPlanCards>
  );
};

export const AnnouncementCard = ({
  data,
  onDelete = () => {},
  onEdit = () => {},
  isStudent = false,
}: {
  data: AnnounceTypes;
  onDelete: () => void;
  onEdit: () => void;
  isStudent?: boolean;
}) => {
  const { token } = theme.useToken();
  console.log({
    isStudent,
  });
  return (
    <StyledPlanCards token={token} onClick={() => isStudent && onEdit()}>
      <div className="flex items-center justify-between gap-2">
        <Typography.Title level={5} ellipsis style={{ fontSize: 14 }}>
          {data?.title}{" "}
        </Typography.Title>
        {!isStudent && (
          <div className="flex items-center gap-2">
            <Button
              type="text"
              icon={<HiOutlinePencil />}
              color="primary"
              variant="outlined"
              onClick={onEdit}
            ></Button>
            <Popconfirm
              title="Delete announcement"
              description="Are you sure to delete this announcement?"
              onConfirm={onDelete}
              okText="Yes"
              cancelText="No"
            >
              <Button
                type="text"
                icon={<BiTrashAlt />}
                color="danger"
                variant="outlined"
              ></Button>
            </Popconfirm>
          </div>
        )}
      </div>
      <div className="flex items-center justify-between gap-2">
        <div className="flex flex-col flex-1/2">
          <Typography.Text strong ellipsis type="secondary">
            Date
          </Typography.Text>
          <Typography.Text ellipsis>
            <FormattedDate dateString={data?.createdAt || ""} />
          </Typography.Text>
        </div>
        {!isStudent && (
          <div className="flex flex-col flex-1/4">
            <Typography.Text strong ellipsis type="secondary">
              Audience
            </Typography.Text>
            <Typography.Text ellipsis>{data?.audienceType}</Typography.Text>
          </div>
        )}
        <div className="flex flex-col flex-1/4">
          <Typography.Text strong ellipsis type="secondary">
            Attachments
          </Typography.Text>
          <Typography.Text ellipsis>
            {Object?.keys(data?.attachments || {})?.length === 0
              ? "None"
              : Object?.keys(data?.attachments || {})?.length}
          </Typography.Text>
        </div>
      </div>
    </StyledPlanCards>
  );
};
