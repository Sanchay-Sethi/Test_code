"use client";

import { StyledContextProps } from "@/types";
import styled, { css } from "styled-components";

export const StyledGeneralCards = styled.div<StyledContextProps>`
  width: 100%;
  padding: 12px 20px;
  display: flex;
  flex-direction: column;
  gap: 10px;
  border-radius: 8px;
  cursor: pointer;
  background-color: ${({ token }) => token?.colorGreyCard};
  box-shadow: rgba(17, 17, 26, 0.1) 0px 1px 0px;

  ${({ disabled }) => disabled && css`
    opacity: 0.5;
    pointer-events: none;
  `}
`;

export const StyledPlanCards = styled.div<StyledContextProps>`
  width: 100%;
  padding: 12px 20px;
  display: flex;
  flex-direction: column;
  gap: 10px;
  border-radius: 8px;
  cursor: pointer;
  background-color: ${({ token }) => token?.colorBgBase};
`;
