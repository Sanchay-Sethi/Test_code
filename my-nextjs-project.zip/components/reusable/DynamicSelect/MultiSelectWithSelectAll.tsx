"use client";

import React, { useMemo } from "react";
import { Select, Tag } from "antd";
import type { SelectProps } from "antd";

type Option = {
  label: string;
  value: string;
};

type Props = {
  options: Option[];
  value: string[];
  onChange: (val: string[]) => void;
  placeholder?: string;
  typeName?: string;
} & Omit<SelectProps<string[]>, "options" | "value" | "onChange">;

const SELECT_ALL = "__all__";

const MultiSelectWithAll: React.FC<Props> = ({
  options,
  value,
  onChange,
  placeholder = "Select options",
  typeName = "",
  ...restProps
}) => {
  const allValues = useMemo(() => options.map((opt) => opt.value), [options]);
  const isAllSelected = value.length === allValues.length;

  const handleChange = (selected: string[]) => {
    if (selected.includes(SELECT_ALL)) {
      onChange(isAllSelected ? [] : allValues);
    } else {
      onChange(selected);
    }
  };

  const getLabel = () => {
    if (value.length === 0) return placeholder;
    if (isAllSelected) return `All ${typeName} selected`;
    return `${value.length} ${typeName} selected`;
  };

  const extendedOptions: SelectProps["options"] = useMemo(() => {
    return [
      {
        label: isAllSelected ? "Deselect All" : "Select All",
        value: SELECT_ALL,
      },
      ...options,
    ];
  }, [options, isAllSelected]);

  const customTagRender: SelectProps["tagRender"] = () => {
    return <Tag>{getLabel()}</Tag>;
  };

  return (
    <Select
      mode="multiple"
      placeholder={placeholder}
      value={value}
      onChange={handleChange}
      options={extendedOptions}
      tagRender={customTagRender}
      maxTagCount={0}
      allowClear
      {...restProps}
    />
  );
};

export default MultiSelectWithAll;
