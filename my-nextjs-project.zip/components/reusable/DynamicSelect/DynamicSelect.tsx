import { useState } from "react";
import { Select, Spin } from "antd";
import type { SelectProps } from "antd";
import apiClient from "@/lib/apiClient";

type DynamicSelectProps<T = unknown> = SelectProps & {
  url: string;
  onFormat: (data: T) => { label: string; value: string }[];
};

const DynamicSelect= <T,>({ url, onFormat, ...restProps }: DynamicSelectProps<T>) => {
  const [options, setOptions] = useState<{ label: string; value: string }[]>(
    []
  );
  const [loading, setLoading] = useState(false);
  const [hasFetched, setHasFetched] = useState(false);

  const fetchOptions = async () => {
    if (hasFetched) return;
    if (!url) return;
    setLoading(true);
    try {
      const res = await apiClient.get(url);
      const data = res?.data;
      let formatted;

      if (!!onFormat) {
        formatted = onFormat(data);
      } else if (typeof data === "object" && data !== null) {
        formatted = Object.keys(data)?.map((key: string) => ({
          label: data?.[key]?.name,
          value: data?.[key]?.id,
        }));
      } else {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        formatted = data?.map((item: any) => ({
          label: item?.name,
          value: item?.id,
        }));
      }

      setOptions(formatted);
      setHasFetched(true);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Select
      {...restProps}
      loading={loading}
      onOpenChange={(open) => {
        if (open) fetchOptions();
      }}
      placeholder="Select an option"
      showSearch
      filterOption={(input, option) =>
        (option?.label ?? "")?.toLowerCase()?.includes(input?.toLowerCase())
      }
      popupRender={(menu) => <Spin spinning={loading}>{menu}</Spin>}
      options={options}
    />
  );
};

export default DynamicSelect;
