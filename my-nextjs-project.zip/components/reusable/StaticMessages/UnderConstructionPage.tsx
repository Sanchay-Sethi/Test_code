import { Result } from "antd";
const UnderConstructionPage = () => {
  return (
    <Result
      status="403"
      title="Maintenance mode"
      subTitle="Page is under maintenance !"
    />
  );
};

export default UnderConstructionPage;
