export { default as GLOBAL_SVGS } from "./GlobalSVG";
export { default as GENERAL_COMPONENTS } from "./generalComponents";