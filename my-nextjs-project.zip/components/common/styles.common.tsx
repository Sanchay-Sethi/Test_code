"use client";

import styled, { css } from "styled-components";
import { StyledContextProps } from "@/types";
import { GLOBAL_CONSTANTS } from "@/constants";

export const ButtonInlineStyles = {
  padding: "18px 20px",
  borderRadius: "20px",
};

export const ButtonInlineSmallStyles = {
  padding: "14px",
  borderRadius: "20px",
};

export const StyledCustom404 = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 20px;

  .title-404-container {
    display: flex;
    flex-direction: column;
  }

  .anim-404-container {
    width: 300px;
  }

  @media (max-width: ${GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.RESPONSIVE_WIDTH}px) {
    flex-direction: column-reverse;

    .title-404-container {
      justify-content: center;
      align-items: center;
    }

    .anim-404-container {
      width: 70%;
    }
  }
`;

export const StyledBackButton = styled.div<StyledContextProps>`
  min-width: 25px;
  min-height: 25px;
  cursor: pointer;
  display: flex;
  justify-content: center;
  align-items: center;
  border-radius: 5px;
  box-shadow: 0px 1px 8px 0px #0000001a;
  border: 1px solid ${({ token }) => token?.colorBorder || "#DCDFE4"};

  svg {
    path {
      fill: ${({ token }) => token?.colorIcon} !important;
    }
  }
`;

export const StyledImagePlaceholder = styled.div<StyledContextProps>`
  width: 120px;
  height: 120px;
  display: flex;
  justify-content: center;
  align-items: center;
  border-radius: 50%;
  background-color: ${({ token }) => token?.colorGreyGlobal || "#F6F8FA"};

  @media (max-width: ${GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.RESPONSIVE_WIDTH}px) {
    width: 80px;
    height: 80px;
    svg {
      width: 25px;
      height: 25px;
    }
  }
`;

export const StyledCommonContainer = styled.div`
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 20px;

  @media (max-width: ${GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.RESPONSIVE_WIDTH}px) {
    gap: 12px;
  }
`;

export const StyledListingTable = styled.div<StyledContextProps>`
  .ant-pagination {
    position: sticky;
    bottom: 0px;
    background-color: ${({ token }) => token?.colorBgBase};
    padding: 12px 20px;
    margin: 0px;
  }

  .ant-table-thead > tr > th {
    background: ${({ token }) => token?.colorBgBase};
    font-weight: 500;
    text-transform: uppercase;
  }

  .ant-table-tbody > tr > td,
  .ant-table-wrapper tfoot > tr > td {
    padding: 8px 16px;
  }
`;

export const commonContainerMobileExtraStyles = css`
  @media (max-width: ${GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.RESPONSIVE_WIDTH}px) {
    gap: 12px;
    padding-bottom: ${GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES
      .GENERAL_PADDING_MOBILE.VERTICAL}px;
  }
`;

export const AddInlineMobilePadding = css`
  @media (max-width: ${GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.RESPONSIVE_WIDTH}px) {
    padding-inline: ${GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES
      .GENERAL_PADDING_MOBILE.INLINE}px;
  }
`;

export const AddVerticalMobilePadding = css`
  @media (max-width: ${GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.RESPONSIVE_WIDTH}px) {
    padding-top: ${GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.GENERAL_PADDING_MOBILE
      .VERTICAL}px;
    padding-bottom: ${GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES
      .GENERAL_PADDING_MOBILE.VERTICAL}px;
  }
`;

export const mobileNavbarExtraStyles = css<StyledContextProps>`
  @media (max-width: ${GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.RESPONSIVE_WIDTH}px) {
    ${AddVerticalMobilePadding};
    ${AddInlineMobilePadding};
    background-color: ${({ token }) => token?.colorBgBase};
    border-bottom-left-radius: ${GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.BORDER_RADIUS}px;
    border-bottom-right-radius: ${GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.BORDER_RADIUS}px;
  }
`;

export const StyledMobileSpacedContainer = styled.div`
  ${AddInlineMobilePadding};
`;

export const StyledMobileSpacedFancyContainer = styled.div<StyledContextProps>`
  @media (max-width: ${GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.RESPONSIVE_WIDTH}px) {
    ${AddInlineMobilePadding};
    ${AddVerticalMobilePadding};
    background-color: ${({ token }) => token?.colorBgBase};
    border-top-left-radius: ${GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.BORDER_RADIUS}px;
    border-top-right-radius: ${GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.BORDER_RADIUS}px;
    ${({ height }) => height && css`
      height: ${height ? `${height}` : "0px"};
    `}
  }
`;

export const StyledFloatButton = styled.div`
  position: fixed;
  right: 14px;
  bottom: 14px;
  z-index: 1000;
`;

export const StyledCommonNavbar = styled.div<StyledContextProps>`
  display: flex;
  justify-content: space-between;
  flex-wrap: wrap;
  gap: 20px;

  ${mobileNavbarExtraStyles};
`;
