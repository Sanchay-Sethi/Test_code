"use client";

import { useEffect, useRef } from "react";
import { redirect, useParams, useRouter } from "next/navigation";
import { Button, theme, Tooltip, Typography } from "antd";
import Lottie from "lottie-react";
import NotFoundAnimation from "@/public/animations/lottie/404.json";
import {
  StyledBackButton,
  StyledCustom404,
  StyledImagePlaceholder,
} from "./styles.common";
import { GLOBAL_SVGS } from ".";
import { useNavigation } from "@/lib/context/NavigationContext";
import { useGlobalContext } from "@/lib/context/GlobalContext";
import HELPERS from "@/lib/helpers";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";

const Error404 = () => {
  const { state } = useGlobalContext();
  const { orgid = "", branchid = "" } = useParams();

  function handleClick() {
    const URL = HELPERS.getDefaultPath(state?.user?.accessMap, `${orgid}`, `${branchid}`)
    redirect(URL);
  }

  return (
    <StyledCustom404>
      <div className="title-404-container">
        <Typography.Title level={1}>Oops !</Typography.Title>
        <Typography.Text>
          Page you are trying to open is not found.
        </Typography.Text>
        <Typography.Paragraph>Error code - 404</Typography.Paragraph>
        <Button onClick={handleClick} type="primary">
          Navigate to Home
        </Button>
      </div>
      <div className="anim-404-container">
        <Lottie animationData={NotFoundAnimation} loop={true} />
      </div>
    </StyledCustom404>
  );
};

const BackButton = ({ backUrl = "" }: { backUrl?: string }) => {
  const { token } = theme.useToken();
  const { navigate } = useNavigation();
  const router = useRouter();
  const hasHistory = useRef(false);

  const isMobile = useIsSmallDevice();

  useEffect(() => {
    hasHistory.current = window.history.length > 1;
  }, []);

  const handleClick = () => {
    if (backUrl) {
      navigate(backUrl);
    } else {
      if (hasHistory?.current) {
        router.back();
      } else {
        navigate("/home");
      }
    }
  };

  if (isMobile) {
    return (
      <StyledBackButton onClick={handleClick} token={token}>
        <GLOBAL_SVGS.BackArrow />
      </StyledBackButton>
    )
  }

  return (
    <Tooltip title="Go back">
      <StyledBackButton onClick={handleClick} token={token}>
        <GLOBAL_SVGS.BackArrow />
      </StyledBackButton>
    </Tooltip>
  );
};

const ImagePlaceholder = () => {
  const { token } = theme.useToken();
  return (
    <StyledImagePlaceholder token={token}>
      <GLOBAL_SVGS.UserPlaceholder />
    </StyledImagePlaceholder>
  );
};

const NoResult = () => {
  return (
    <div className="w-full pt-[50px] flex justify-center items-center">
      <div className="w-[200px] flex flex-col justify-center items-center">
        <Lottie width={200} animationData={NotFoundAnimation} loop={true} />
        <Typography.Paragraph>No result found !</Typography.Paragraph>
      </div>
    </div>
  )
}

const GENERAL_COMPONENTS = {
  Error404,
  BackButton,
  ImagePlaceholder,
  NoResult,
};

export default GENERAL_COMPONENTS;
