"use client";

import { StyledContextProps } from "@/types";
import styled from "styled-components";

export const StyledMobileNavbar = styled.div<StyledContextProps>`
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 10px;
  padding: 6px 10px;
  background: ${({ token }) => token?.colorBgBase};

  .mobile-nav-logo-container {
    display: flex;
    align-items: center;
    gap: 10px;
  }

  .ant-select-selector {
    border-radius: 20px;
    padding-inline: 20px !important;
  }

`;
