"use client";

import { HiOutlineMenuAlt2 } from "react-icons/hi";
import { useGlobalContext } from "@/lib/context/GlobalContext";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";
import { Button, Select, theme, Typography } from "antd";
import { StyledMobileNavbar } from "./styles.MobileNavbar";
import { GLOBAL_SVGS } from "@/components/common";
import { getOrgBranchDetail } from "../Sidebar/Helpers.Sidebar";
import { StudentAccessMapProps } from "@/types";

const MobileNavbar = () => {
  const isMobile = useIsSmallDevice();
  const { updateState } = useGlobalContext();
  const { token } = theme.useToken();
  const { state } = useGlobalContext();

  const isStudent = state?.user?.accessMap?.ROLE === "STUDENT";
  const isSingleUser = (state?.user?.accessMap?.students || [])?.length <= 1;

  const orgBranchDetails = getOrgBranchDetail(
    state?.user?.accessMap as StudentAccessMapProps
  );

  function handleOpen() {
    updateState({
      sidebar: {
        mobile: {
          open: true,
        },
      },
    });
  }

  function handleClick(id = "") {
    if (!id) return;
    const url = new URL(window.location.href);
    url.searchParams.set("studentId", id);
    window.location.href = url.toString();
  }

  function getOptions() {
    return (state?.user?.accessMap?.students || [])?.map((option) => {
      return {
        label: option?.name,
        value: option?.id,
      };
    });
  }

  if (!isMobile) return null;

  return (
    <StyledMobileNavbar token={token}>
      <div className="mobile-nav-logo-container">
        <Button
          icon={
            <HiOutlineMenuAlt2 size={25} style={{ color: token?.colorIcon }} />
          }
          shape="circle"
          type="text"
          onClick={handleOpen}
        />
        <Typography.Title
          level={4}
          style={{ color: token?.colorPrimary, fontWeight: 700 }}
          className="flex items-center gap-2"
        >
          {orgBranchDetails?.org?.orgName}
        </Typography.Title>
      </div>
      {isStudent && !isSingleUser && (
        <Select
          value={state?.user?.accessMap?.selectedStudent?.id}
          onChange={(val) => handleClick(val)}
          prefix={GLOBAL_SVGS.NavUser()}
          options={[
            {
              label: <span>Switch to</span>,
              title: "Switch to",
              options: getOptions(),
            },
          ]}
        />
      )}
    </StyledMobileNavbar>
  );
};

export default MobileNavbar;
