"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { usePathname } from "next/navigation";
import { cloneDeep } from "lodash";
import { Menu, theme } from "antd";
import { useGlobalContext } from "@/lib/context/GlobalContext";
import { useThemeContext } from "@/lib/context/ThemeContext";
import { useNavigation } from "@/lib/context/NavigationContext";
import HELPERS from "@/lib/helpers";
import { getMenuItems } from "../Helpers.Sidebar";
import { StudentAccessMapProps } from "@/types";
import { StyledSideMenu } from "../Styles.Sidebar";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";

const SideMenu = () => {
  const { token } = theme.useToken();
  const isMobile = useIsSmallDevice();
  
  const { state, updateState } = useGlobalContext();
  const { mode } = useThemeContext();
  
  const { navigate } = useNavigation();
  const pathname = usePathname();
  
  const menuRef = useRef<HTMLDivElement>(null);

  const [openKeys, setOpenKeys] = useState<string[]>([]);
  const [selectedKey, setSelectedKey] = useState<string>("");

  const collapsed = state?.sidebar?.collapsed || false;

  const MENU_ITEMS = useMemo(() => {
    return getMenuItems(
      token?.colorPrimary,
      selectedKey,
      state?.user?.accessMap as StudentAccessMapProps
    );
  }, [token?.colorPrimary, selectedKey, state?.user?.accessMap]);

  useEffect(() => {
    if (!pathname) return;

    const relativePath = HELPERS.getRelativePath(pathname);

    const allItems =
      cloneDeep(
        getMenuItems(
          token?.colorPrimary,
          selectedKey,
          state?.user?.accessMap as StudentAccessMapProps
        )
      ) || [];
    const flatKeys = allItems?.flatMap((item) =>
      item?.children ? item?.children?.map((child) => child?.key) : [item?.key]
    );

    const bestMatch = flatKeys
      ?.filter((key) => relativePath?.startsWith(key))
      ?.sort((a, b) => b?.length - a?.length)?.[0];

    setSelectedKey(bestMatch || relativePath);

    if (!collapsed) {
      const parent = allItems?.find((item) =>
        item?.children?.some((child) => relativePath?.startsWith(child?.key))
      );

      if (parent) {
        setOpenKeys([parent.key]);
      } else {
        setOpenKeys([]);
      }
    } else {
      setOpenKeys([]);
    }

    const selectedElement = document.querySelector(`.ant-menu-item-selected`);
    selectedElement?.scrollIntoView({ block: "center", behavior: "smooth" });
  }, [
    pathname,
    collapsed,
    token?.colorPrimary,
    selectedKey,
    state?.user?.accessMap,
  ]);

  function handleCloseDrawerMobile() {
    updateState({
      sidebar: {
        mobile: {
          open: false,
        },
      },
    });
  }

  const onMenuClick = ({ key }: { key: string }) => {
    setSelectedKey(key);
    navigate(key);
    handleCloseDrawerMobile();
  };

  const handleOpenChange = (keys: string[]) => {
    // Only one submenu open at a time
    const latestOpenKey = keys.find((key) => openKeys.indexOf(key) === -1);
    if (MENU_ITEMS?.some((item) => item.key === latestOpenKey)) {
      setOpenKeys(latestOpenKey ? [latestOpenKey] : []);
    } else {
      setOpenKeys(keys);
    }
  };

  return (
    <StyledSideMenu ref={menuRef} token={token} iscollapsed={collapsed}>
      <Menu
        selectedKeys={[selectedKey]}
        openKeys={openKeys}
        onOpenChange={handleOpenChange}
        onClick={onMenuClick}
        style={{ borderRight: 0, backgroundColor: "transparent" }}
        mode="inline"
        theme={mode}
        inlineCollapsed={isMobile ? false : collapsed}
      >
        {MENU_ITEMS?.map((item) =>
          item.children ? (
            <Menu.SubMenu key={item.key} icon={item.icon} title={item.label}>
              {item.children.map((subItem) => (
                <Menu.Item style={{ paddingLeft: 35 }} key={subItem.key}>
                  {subItem.label}
                </Menu.Item>
              ))}
            </Menu.SubMenu>
          ) : (
            <Menu.Item
              style={{ paddingLeft: 12 }}
              key={item.key}
              icon={item.icon}
            >
              {item.label}
            </Menu.Item>
          )
        )}
      </Menu>
    </StyledSideMenu>
  );
};

export default SideMenu;
