"use client";

import { useState } from "react";
import { Divider, Menu, Popover, Switch, theme, Typography } from "antd";
import { useGlobalContext } from "@/lib/context/GlobalContext";
import { useThemeContext } from "@/lib/context/ThemeContext";
import { SideMenuIcons } from "../Icons";
import {
  DownOutlined,
  LogoutOutlined,
  MoonOutlined,
  // ProfileOutlined,
  SunOutlined,
} from "@ant-design/icons";
import { GLOBAL_APIS } from "@/lib";
import {
  StyledBottomMenu,
  StyledProfileMenu,
  StyledSwitchUser,
  StyledUserName,
  StyledUserSwitchContent,
} from "../Styles.Sidebar";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";

const UserName = ({ user = "" }) => {
  return (
    <StyledUserName>
      {SideMenuIcons.USER(user ? user?.split("")?.[0] : "")}
      <Typography.Text
        style={{
          textTransform: "capitalize",
        }}
        ellipsis
      >
        {user || "User"}
      </Typography.Text>
    </StyledUserName>
  );
};

const UserSwitchContent = () => {
  const { state } = useGlobalContext();

  function handleClick(id = "") {
    if (!id) return;
    const url = new URL(window.location.href);
    url.searchParams.set("studentId", id);
    window.location.href = url.toString();
  }
  return (
    <StyledUserSwitchContent>
      <Typography.Paragraph style={{ fontSize: 12, fontWeight: 500 }}>
        Switch to
      </Typography.Paragraph>
      <Divider style={{ margin: 0 }} />
      <div className="user-content">
        {(state?.user?.accessMap?.students || [])
          ?.filter(
            (student) =>
              student?.id !== state?.user?.accessMap?.selectedStudent?.id
          )
          ?.map((student) => {
            return (
              <div
                key={student?.id}
                onClick={() => handleClick(student?.id)}
                className="single-user-name"
              >
                <UserName user={student?.name} />
              </div>
            );
          })}
      </div>
    </StyledUserSwitchContent>
  );
};

const SwitchUser = () => {
  const [open, setOpen] = useState(false);
  const { token } = theme.useToken();
  const { state } = useGlobalContext();
  const isMobile = useIsSmallDevice();

  const userName = state?.user?.accessMap?.userName || "";
  const isSingleUser = (state?.user?.accessMap?.students || [])?.length <= 1;

  if (state?.user?.accessMap?.ROLE === "STUDENT") {
    if (isSingleUser || isMobile) {
      return (
        <StyledSwitchUser token={token} nonHovered = {isSingleUser}>
          <UserName user={userName || ""} />
        </StyledSwitchUser>
      )
    }
    return (
      <Popover
        content={<UserSwitchContent />}
        open={open}
        onOpenChange={setOpen}
        placement={"right"}
      >
        <StyledSwitchUser token={token}>
          <UserName user={userName || ""} />
          <div className="right-icon">
            <DownOutlined
              style={{ fontSize: "12px" }}
              rotate={open ? -90 : 0}
            />
          </div>
        </StyledSwitchUser>
      </Popover>
    );
  }
  return <UserName user={userName} />;
};

const ProfileMenu = () => {
  const { token } = theme.useToken();
  const { toggleTheme, mode } = useThemeContext();

  function logout() {
    GLOBAL_APIS.handleLogout();
  }

  return (
    <StyledProfileMenu token={token}>
      <SwitchUser />
      <div className="profile-menu-items">
        <div className="profile-item" onClick={toggleTheme}>
          <Switch
            checkedChildren={<SunOutlined />}
            unCheckedChildren={<MoonOutlined />}
            onClick={(_, e) => {
              e.stopPropagation();
              toggleTheme();
            }}
            checked={mode === "dark"}
          />
          <Typography.Text>
            {mode === "light"
              ? "Switch to dark theme"
              : "Switch to light theme"}
          </Typography.Text>
        </div>
        {/* <div className="profile-item">
          <ProfileOutlined />
          <Typography.Text>Account</Typography.Text>
        </div> */}
        <div className="profile-item" onClick={logout}>
          <LogoutOutlined />
          <Typography.Text>Logout</Typography.Text>
        </div>
      </div>
    </StyledProfileMenu>
  );
};

const BottomMenu = () => {
  const { token } = theme.useToken();
  const { state } = useGlobalContext();
  const { mode } = useThemeContext();
  const isMobile = useIsSmallDevice();

  const userName = state?.user?.accessMap?.userName || "";

  const displayName =
    userName?.length > 20 ? userName?.slice(0, 20) + "..." : userName;

  const collapsed = state?.sidebar?.collapsed || false;

  const iscollapsed = isMobile ? false : collapsed;

  const menuItems = [
    {
      label: "View as teacher",
      key: "role",
      icon: SideMenuIcons.ROLE(),
    },
  ];

  const onMenuClick = ({ key }: { key: string }) => {
    if (key === "role") {
      // TODO: Set on permission changes
    }
  };

  return (
    <StyledBottomMenu token={token} iscollapsed={iscollapsed}>
      <Menu
        onClick={onMenuClick}
        style={{ borderRight: 0, backgroundColor: "transparent" }}
        mode="inline"
        theme={mode}
        inlineCollapsed={isMobile ? false : iscollapsed}
        items={menuItems}
        hidden
      />
      <Popover
        trigger={"click"}
        arrow={false}
        content={<ProfileMenu />}
        placement={isMobile ? "topLeft" : iscollapsed ? "rightTop" : "top"}
      >
        <div className="user-profile-menu">
          {SideMenuIcons.USER(userName ? userName?.split("")?.[0] : "")}
          {!iscollapsed && <p title={userName}>{displayName || "Profile"}</p>}
        </div>
      </Popover>
    </StyledBottomMenu>
  );
};

export default BottomMenu;
