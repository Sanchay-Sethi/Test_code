"use client";

import { useState } from "react";
import {
  Button,
  Input,
  Popover,
  Select,
  Skeleton,
  theme,
  Typography,
} from "antd";
import { MdWorkspacesFilled } from "react-icons/md";
import { DownOutlined } from "@ant-design/icons";
import { useGlobalContext } from "@/lib/context/GlobalContext";
import { SchoolBranchIcon } from "../Icons";
import {
  StyledSchoolBranchSelector,
  StyledSchoolBranchSelectorPopup,
} from "../Styles.Sidebar";
import { getOrgBranchDetail } from "../Helpers.Sidebar";
import { StudentAccessMapProps } from "@/types";
import {
  useParams,
  usePathname,
  useRouter,
  useSearchParams,
} from "next/navigation";
import { useGlobalValues } from "@/lib/hooks/useGlobalValues";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";

const { Title, Text } = Typography;

const SchoolBranchSelectorPopup = ({}) => {
  const { BRANCHES_OPTIONS, ORG_OPTIONS } = useGlobalValues();
  const { token } = theme.useToken();

  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  const { orgid, branchid } = useParams();

  function getURL(value = "", index = 2) {
    const parts = pathname?.split("/");
    parts[index] = value;
    const newPath = parts.join("/");
    const queryString = searchParams.toString();
    return queryString ? `${newPath}?${queryString}` : newPath;
  }

  function handleOrgChange(val = "") {
    if (val === orgid) return;
    const URL = getURL(val, 2);
    router.push(URL);
  }

  function handleBranchChange(val = "") {
    if (val === orgid) return;
    const URL = getURL(val, 3);
    window.location.href = URL;
  }

  const isOrgReadonly = ORG_OPTIONS?.length === 1;
  const isBranchReadonly = BRANCHES_OPTIONS?.length === 1;

  return (
    <StyledSchoolBranchSelectorPopup token={token}>
      <div className="workspace-title">
        <MdWorkspacesFilled /> Workspace
      </div>
      <div className="workspace-content">
        <div className="workspace-content-detail">
          <Typography.Paragraph ellipsis>School</Typography.Paragraph>
          {isOrgReadonly ? (
            <Input
              value={`${ORG_OPTIONS?.[0]?.label}`}
              readOnly
              style={{ border: "none" }}
            />
          ) : (
            <Select
              value={`${orgid}`}
              options={ORG_OPTIONS}
              style={{
                width: "100%",
              }}
              onChange={handleOrgChange}
            />
          )}
        </div>
        <div className="workspace-content-detail">
          <Typography.Paragraph ellipsis>Branch</Typography.Paragraph>
          {isBranchReadonly ? (
            <Input
              value={`${BRANCHES_OPTIONS?.[0]?.label}`}
              readOnly
              style={{ border: "none" }}
            />
          ) : (
            <Select
              value={`${branchid}`}
              options={BRANCHES_OPTIONS}
              style={{
                width: "100%",
              }}
              onChange={handleBranchChange}
            />
          )}
        </div>
      </div>
    </StyledSchoolBranchSelectorPopup>
  );
};

const SchoolBranchSelector = () => {
  const isMobile = useIsSmallDevice();
  const { token } = theme.useToken();
  const { state } = useGlobalContext();

  const [openDropdown, setOpenDropdown] = useState(false);

  const collapsed = state?.sidebar?.collapsed || false;

  const orgBranchDetails = getOrgBranchDetail(
    state?.user?.accessMap as StudentAccessMapProps
  );

  const IS_STUDENT = state?.user?.accessMap?.ROLE === "STUDENT";

  const iscollapsed = isMobile ? false : collapsed;

  if (IS_STUDENT) {
    return (
      <StyledSchoolBranchSelector iscollapsed={iscollapsed} token={token} nonHovered = {IS_STUDENT}>
        <div className="title-container">
          <div className="title-container-icon">
            <SchoolBranchIcon />
          </div>
          {!iscollapsed && (
            <div className="title-container-text">
              <Title
                title={""}
                ellipsis
                level={5}
                style={{ marginBottom: 0, fontSize: 15 }}
              >
                {orgBranchDetails?.org?.orgName ? (
                  orgBranchDetails?.org?.orgName
                ) : (
                  <Skeleton.Input active size={"small"} />
                )}
              </Title>
              <Text ellipsis style={{ fontSize: 12 }}>
                {orgBranchDetails?.branch?.branchName ? (
                  orgBranchDetails?.branch?.branchName
                ) : (
                  <Skeleton.Input
                    active
                    size={"small"}
                    style={{ marginTop: "5px" }}
                  />
                )}
              </Text>
            </div>
          )}
        </div>
      </StyledSchoolBranchSelector>
    );
  }

  return (
    <Popover
      content={<SchoolBranchSelectorPopup />}
      trigger="click"
      placement={isMobile ? "bottom" : "right"}
      open={openDropdown}
      onOpenChange={setOpenDropdown}
      styles={{
        body: {
          padding: 0,
        },
      }}
    >
      <StyledSchoolBranchSelector iscollapsed={iscollapsed} token={token}>
        <div className="title-container">
          <div className="title-container-icon">
            <SchoolBranchIcon />
          </div>
          {!iscollapsed && (
            <div className="title-container-text">
              <Title
                title={""}
                ellipsis
                level={5}
                style={{ marginBottom: 0, fontSize: 15 }}
              >
                {orgBranchDetails?.org?.orgName ? (
                  orgBranchDetails?.org?.orgName
                ) : (
                  <Skeleton.Input active size={"small"} />
                )}
              </Title>
              <Text ellipsis style={{ fontSize: 12 }}>
                {orgBranchDetails?.branch?.branchName ? (
                  orgBranchDetails?.branch?.branchName
                ) : (
                  <Skeleton.Input
                    active
                    size={"small"}
                    style={{ marginTop: "5px" }}
                  />
                )}
              </Text>
            </div>
          )}
        </div>
        {!iscollapsed && (
          <Button
            icon={
              <DownOutlined
                style={{
                  transition: "transform 0.3s ease",
                  transform: openDropdown ? `rotate(${isMobile ? "180" : "-90"}deg)` : `rotate(0deg)`,
                  cursor: "pointer",
                }}
              />
            }
            type="text"
            shape="circle"
          />
        )}
      </StyledSchoolBranchSelector>
    </Popover>
  );
};

export default SchoolBranchSelector;
