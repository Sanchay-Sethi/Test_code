"use client";

import { Button, Drawer, Layout, theme, Tooltip, Typography } from "antd";
import { DoubleLeftOutlined } from "@ant-design/icons";
import { useGlobalContext } from "@/lib/context/GlobalContext";
import { useThemeContext } from "@/lib/context/ThemeContext";
import { GLOBAL_CONSTANTS } from "@/constants";
import SchoolBranchSelector from "./components/SchoolBranchSelector";
import SideMenu from "./components/SideMenu";
import BottomMenu from "./components/BottomMenu";
import { StyledSidebar } from "./Styles.Sidebar";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";
import { getOrgBranchDetail } from "./Helpers.Sidebar";
import { StudentAccessMapProps } from "@/types";

const { Sider } = Layout;

const Sidebar = () => {
  const { token } = theme.useToken();
  const { state, updateState } = useGlobalContext();
  const { mode } = useThemeContext();
  const isMobile = useIsSmallDevice();

  const collapsed = isMobile ? false : state?.sidebar?.collapsed || false;
  const isMobileOpen = state?.sidebar?.mobile?.open || false;

  const orgBranchDetails = getOrgBranchDetail(
    state?.user?.accessMap as StudentAccessMapProps
  );

  function handleCloseDrawerMobile() {
    updateState({
      sidebar: {
        mobile: {
          open: false,
        },
      },
    });
  }

  function handleToggleCollapse() {
    if (isMobileOpen) {
      handleCloseDrawerMobile();
    } else {
      updateState({
        sidebar: {
          collapsed: !collapsed,
        },
      });
    }
  }

  function handleOpenDrawerMobile() {
    updateState({
      sidebar: {
        collapsed: false,
      },
    });
  }

  function getSideBarComponent() {
    return (
      <StyledSidebar iscollapsed={collapsed}>
        <div className="logo-container">
          {!collapsed && (
            <>
              <Typography.Title
                level={3}
                style={{ color: token?.colorPrimary, fontWeight: 700 }}
                className="flex items-center gap-2"
              >
                {orgBranchDetails?.org?.orgName}
              </Typography.Title>
            </>
          )}
          <Tooltip
            title={isMobile ? "" : collapsed ? "Expand" : "Collapse"}
            placement={"right"}
          >
            <Button
              type="text"
              onClick={handleToggleCollapse}
              icon={
                <DoubleLeftOutlined
                  style={{
                    color: token.colorCollapseIcon,
                  }}
                  rotate={collapsed ? 180 : 0}
                />
              }
              shape={!collapsed ? "circle" : "default"}
            />
          </Tooltip>
        </div>
        <div className="school-branch-selection-container">
          <SchoolBranchSelector />
        </div>
        <div className="side-menu">
          <SideMenu />
        </div>
        <div className="bottom-menu">
          <BottomMenu />
        </div>
      </StyledSidebar>
    );
  }

  if (isMobile) {
    return (
      <Drawer
        placement={"left"}
        closable={false}
        onClose={handleCloseDrawerMobile}
        afterOpenChange={handleOpenDrawerMobile}
        open={isMobileOpen}
        key={"SIDEBAR_MOBILE"}
        styles={{
          body: {
            padding: 0,
          },
        }}
        width={320}
      >
        {getSideBarComponent()}
      </Drawer>
    );
  }

  return (
    <Sider
      trigger={null}
      theme={mode}
      breakpoint="lg"
      onCollapse={handleToggleCollapse}
      collapsible
      width={GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.SIDEBAR.WIDTH}
      collapsed={collapsed}
    >
      {getSideBarComponent()}
    </Sider>
  );
};

export default Sidebar;
