import { LabelValueProps } from "@/types"

interface OrgBranchProps {
    org: {
        orgId: string,
        orgName: string,
        orgIdNameMap: {
            [key: string]: string,
        },
        orgListHash?: LabelValueProps[],
    },
    branch: {
        branchId: string,
        branchName: string,
        branchListHash?: LabelValueProps[],
    },
}