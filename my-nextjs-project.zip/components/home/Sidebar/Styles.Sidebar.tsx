"use client";

import styled, { css } from "styled-components";
import { StyledContextProps } from "@/types";
import { GLOBAL_CONSTANTS } from "@/constants";

export const StyledSidebar = styled.div<StyledContextProps>`
  height: 100vh;
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 25px;
  padding: 24px 12px;
  position: relative;

  .logo-container {
    width: 100%;
    display: flex;
    align-items: center;
    padding-inline: 6px;
    justify-content: ${({ iscollapsed }) =>
      iscollapsed ? "center" : "space-between"};
  }

  .bottom-menu {
    height: 100%;
    display: flex;
    flex-direction: column;
    justify-content: flex-end;
  }
`;

export const StyledSchoolBranchSelector = styled.div<StyledContextProps>`
  width: 100%;
  display: flex;
  align-items: center;
  border-radius: 6px;
  padding: 5px 3px;
  cursor: ${({ nonHovered }) => nonHovered ? "default" : "pointer"};
  justify-content: ${({ iscollapsed }) =>
    iscollapsed ? "center" : "space-between"};

  .title-container {
    display: flex;
    align-items: center;
    gap: 8px;

    .title-container-icon {
      width: 32px;
      height: 32px;
      border-radius: 50%;
      display: flex;
      justify-content: center;
      align-items: center;
      box-shadow: 0px 1px 1px 0px #0000001f;
      background-color: ${({ token }) => token?.colorBgBase || "#fff"};
    }

    .title-container-text {
      display: flex;
      flex-direction: column;
      width: ${GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.SIDEBAR.WIDTH - 120}px;
    }
  }

  &:hover {
    background-color: ${({ token, nonHovered }) => nonHovered ? "" : token?.colorBgTextHover};
  }
`;

export const StyledSideMenu = styled.div<StyledContextProps>`
  height: calc(100vh - 248px);
  overflow: auto;

  .ant-menu-inline.ant-menu-root .ant-menu-submenu-title {
    padding-left: 12px !important;
  }

  .ant-menu-light.ant-menu-inline .ant-menu-sub.ant-menu-inline {
    background-color: transparent;
    border-radius: 12px;
  }

  .ant-menu-item-selected {
    font-weight: 600;
  }

  ${({ iscollapsed }) =>
    iscollapsed &&
    css`
      .ant-menu-item {
        padding-left: 15px !important;
      }
    `}
`;

export const StyledBottomMenu = styled.div<StyledContextProps>`
  width: 100%;

  .ant-menu-inline.ant-menu-root .ant-menu-item {
    padding-left: 12px !important;
  }

  .ant-avatar.ant-avatar-icon {
    font-size: 12px;
  }

  .ant-avatar {
    width: 28px;
    height: 28px;
  }

  .user-profile-menu {
    display: flex;
    align-items: center;
    gap: 8px;
    cursor: pointer;
    padding: 4px 8px;
    border-radius: 6px;

    ${({ iscollapsed }) =>
      iscollapsed &&
      css`
        width: 100%;
        justify-content: center;
      `}

    p {
      color: ${({ token }) => token?.colorText};
    }

    &:hover {
      background: ${({ token }) => token?.colorBgTextHover};
    }
  }
`;

export const StyledUserName = styled.div`
  width: 100%;
  display: flex;
  align-items: center;
  gap: 10px;
`;

export const StyledProfileMenu = styled.div<StyledContextProps>`
  width: 100%;
  display: flex;
  padding: 5px 8px;
  flex-direction: column;
  gap: 12px;

  .profile-title {
    width: 100%;
    display: flex;
    align-items: center;
    gap: 10px;
  }

  .profile-menu-items {
    width: 100%;
    display: flex;
    gap: 12px;
    padding: 7px 0px;
    flex-direction: column;
    border-top: 0.2px solid ${({ token }) => token?.colorBorder};

    .profile-item {
      display: flex;
      align-items: center;
      gap: 10px;
      border-radius: 6px;
      padding: 4px 6px;
      cursor: pointer;

      &:hover {
        background: ${({ token }) => token?.colorBgTextHover};
      }
    }
  }
`;

export const StyledSchoolBranchSelectorPopup = styled.div<StyledContextProps>`
  width: 100%;
  display: flex;
  flex-direction: column;

  .workspace-title {
    display: flex;
    align-items: center;
    gap: 5px;
    padding: 10px;
    border-bottom: 0.5px solid ${({ token }) => token?.colorBorder};
    font-weight: 600;
  }

  .workspace-content {
    display: flex;
    flex-direction: column;
    /* padding: 16px 12px; */
    gap: 15px;
    border: 0.5px solid ${({ token }) => token?.colorBorder};
    margin: 16px;
    border-radius: 8px;
    padding: 10px;
  }

  .workspace-content-detail {
    display: flex;
    align-items: center;
    gap: 20px;

    .ant-typography {
      white-space: nowrap;
      width: 70px;
      font-size: 13px;
    }
  }
`;

export const StyledSwitchUser = styled.div<StyledContextProps>`
  padding: 4px 5px;
  border-radius: 4px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 10px;
  cursor: ${({ nonHovered }) => nonHovered ? "default" : "pointer"};
  transition: 0.3s all ease;

  .right-icon {
    display: flex;
    justify-content: center;
    align-items: center;
  }

  &:hover {
    background-color: ${({ token, nonHovered }) => !nonHovered && token?.colorBgTextHover};
  }
`;

export const StyledUserSwitchContent = styled.div`
  width: 200px;
  display: flex;
  flex-direction: column;
  gap: 8px;

  .user-content {
    display: flex;
    flex-direction: column;
    gap: 5px;
  }

  .single-user-name {
    cursor: pointer;
  }
`;
