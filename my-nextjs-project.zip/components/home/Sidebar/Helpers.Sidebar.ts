import { StudentAccessMapProps } from "@/types";
import { SideMenuIcons } from "./Icons";
import { cloneDeep } from "lodash";

type MenuItem = {
    label: string;
    key: string;
    icon: React.ReactElement;
    children?: { label: string; key: string }[];
};

export function getOrgBranchDetail(accessMap: StudentAccessMapProps) {
    const obj = {
        org: {
            orgId: `${accessMap?.orgId}`,
            orgName: accessMap?.orgIdNameMap?.[accessMap?.orgId],
        },
        branch: {
            branchId: accessMap?.branchId,
            branchName: accessMap?.branchesHash?.find(branch => branch?.id === accessMap?.branchId)?.name,
        },
    }
    return obj;
}

export const getMenuItems = (color = "", selectedKey = "", accessMap: StudentAccessMapProps): MenuItem[] => {
    const POD_MENUS = [
        // {
        //     label: "Dashboard",
        //     key: "/dashboard",
        //     icon: SideMenuIcons.DASHBOARD(
        //         selectedKey?.includes("dashboard") ? color : ""
        //     ),
        // },
        {
            label: "Students",
            key: "/students",
            icon: SideMenuIcons.STUDENTS(
                selectedKey?.includes("students") ? color : ""
            ),
        },
        {
            label: "Calender",
            key: "/calender",
            icon: SideMenuIcons.CALENDER(
                selectedKey?.includes("calender") ? color : ""
            ),
        },
        {
            label: "Announcements",
            key: "/announcements",
            icon: SideMenuIcons.ANNOUNCEMENTS(
                selectedKey?.includes("announcements") ? color : ""
            ),
        },
        // {
        //     label: "Programs",
        //     key: "/programs",
        //     icon: SideMenuIcons.PROGRAMS(
        //         selectedKey?.includes("programs") ? color : ""
        //     ),
        // },
        {
            label: "Fee",
            key: "/fees",
            icon: SideMenuIcons.FEES(selectedKey?.includes("fees") ? color : ""),
        },
        {
            label: "Payments",
            key: "/payments",
            icon: SideMenuIcons.PAYMENTS(
                selectedKey?.includes("payments") ? color : ""
            ),
        },
        {
            label: "Settings",
            key: "settings",
            icon: SideMenuIcons.SETTINGS(
                selectedKey?.includes("settings") ? color : ""
            ),
            children: [
                {
                    label: "School & branches",
                    key: "/settings/school",
                },
                {
                    label: "Users & roles",
                    key: "/settings/users-roles",
                },
                {
                    label: "Payment gateway",
                    key: "/settings/payment-gateway",
                },
                {
                    label: "Academic year",
                    key: "/settings/academic-year",
                },
                {
                    label: "Program & sections",
                    key: "/settings/program",
                },
                {
                    label: "Fee structures",
                    key: "/settings/fee-structures",
                },
                {
                    label: "Fee plans",
                    key: "/settings/fee-plans",
                },
            ],
        },
        {
            label: "Pod",
            key: "pod",
            icon: SideMenuIcons.POD(selectedKey?.includes("pod") ? color : ""),
            children: [
                {
                    label: "Schools",
                    key: "/pod/schools",
                },
                {
                    label: "Admins",
                    key: "/pod/admins",
                },
            ],
        },
    ];

    const STUDENT_MENU = [
        {
            label: "Profile",
            key: "/student-view/profile",
            icon: SideMenuIcons.STUDENTS(selectedKey?.includes("profile") ? color : ""),
        },
        {
            label: "Calender",
            key: "/student-view/calender",
            icon: SideMenuIcons.CALENDER(
                selectedKey?.includes("calender") ? color : ""
            ),
        },
        {
            label: "Announcements",
            key: "/student-view/announcement",
            icon: SideMenuIcons.ANNOUNCEMENTS(
                selectedKey?.includes("announcements") ? color : ""
            ),
        },
        {
            label: "Fee",
            key: "/student-view/fees",
            icon: SideMenuIcons.FEES(selectedKey?.includes("fees") ? color : ""),
        },
    ]

    if (accessMap?.podAdmin === true) {
        return POD_MENUS || [];
    }

    if (!!accessMap?.staff) {
        let menu = cloneDeep(POD_MENUS) || [];
        menu = menu?.filter(item => item?.key !== "pod");

        if (accessMap?.staff?.schoolAdmin === true) {
            return menu || [];
        } else {
            // TODO: WILL CHANGE WITH PERMISSIONS
            return menu?.filter(item => !["settings", "payments"]?.includes(item?.key)) || [];
        }
    }

    if (!!accessMap?.students && accessMap?.students?.length > 0) {
        return STUDENT_MENU || []
    }

    return [];
}