"use client";

import { useGlobalContext } from "@/lib/context/GlobalContext";
import React, { useEffect, useState } from "react";
import Overview from "../../Students/Student/components/StudentDetailsTabs/components/Overview";
import apiClient from "@/lib/apiClient";
import GeneralSkeleton from "@/components/reusable/Loader/Skeleton/GeneralSkeleton";
import Navbar from "./components/Navbar";
import { StyledCommonContainer, StyledMobileSpacedContainer, StyledMobileSpacedFancyContainer } from "@/components/common/styles.common";
import { theme } from "antd";

const Profile = () => {
  const { state } = useGlobalContext();
  const { token } = theme.useToken();

  const [details, setDetails] = useState<StudentDetailsTypes>({
    profile: {},
    enrolment: {},
  });
  const [loading, setLoading] = useState(false);
  const [profileImage, setProfileImage] = useState("");

  const id = state.user?.accessMap?.selectedStudent?.id;

  async function getStudentDetails() {
    if (id) {
      try {
        setLoading(true);
        const res = await apiClient.get(`/student/${id}`);
        setDetails(res?.data || {});
        if (res?.data?.profile?.id) {
          const imgRes = await apiClient.get(
            `/student/photo/${res?.data?.profile?.id}`,
            {
              responseType: "blob",
            }
          );
          if (imgRes?.status === 204 && imgRes?.statusText === "No Content") {
            setProfileImage("");
          } else {
            const url = URL.createObjectURL(imgRes?.data);
            setProfileImage(url);
          }
        }
      } finally {
        setLoading(false);
      }
    }
  }

  useEffect(() => {
    getStudentDetails();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  if (loading) {
    return <StyledMobileSpacedContainer><GeneralSkeleton countSmall={2} countLarge={3} isLargeWrapped /></StyledMobileSpacedContainer>
  }

  return (
    <StyledCommonContainer>
      <Navbar
        name={details?.profile?.name || ""}
        admissionId={details?.profile?.admissionNumber || ""}
      />
      <StyledMobileSpacedFancyContainer token = {token}>
        <Overview details={details || {}} profileImage={profileImage} alterHeight = "calc(100vh - 132px)"/>
      </StyledMobileSpacedFancyContainer>
    </StyledCommonContainer>
  );
};

export default Profile;
