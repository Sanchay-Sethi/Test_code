"use client";

import styled from "styled-components";
import { StyledContextProps } from "@/types";
import { GLOBAL_CONSTANTS } from "@/constants";
import { mobileNavbarExtraStyles } from "@/components/common/styles.common";

export const StyledNavbar = styled.div<StyledContextProps>`
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 15px;
  flex-wrap: wrap;

  .nav-studentlist-header {
    display: flex;
    align-items: center;
    gap: 15px;
    flex-wrap: wrap;
  }

  .nav-studentlist-dropdown {
    display: flex;
    align-items: center;
    gap: 10px;
    cursor: pointer;
  }

  .nav-studentlist-actions {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 10px;
  }

  .tag-container {
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 4px 6px;
    background-color: ${({ token }) => token?.colorCustomTag};
    border-radius: 8px;
    font-weight: 500;
  }

  @media (max-width: ${GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.RESPONSIVE_WIDTH}px) {
    ${mobileNavbarExtraStyles}
  }
`;
