"use client"

import { theme, Typography } from "antd";
import { StyledNavbar } from "../styles.profile";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";

const Navbar = ({ name = "", admissionId = "" }) => {
  const { token } = theme.useToken();
  const isMobile = useIsSmallDevice();
  return (
    <StyledNavbar token={token}>
      <div className="nav-studentlist-header">
        <div className="nav-studentlist-dropdown">
          <Typography.Title level={isMobile ? 5 : 3} style={{ marginBottom: 0 }}>
            {name}
          </Typography.Title>
        </div>
        {admissionId && (
          <div className="tag-container">
            <Typography.Text style={isMobile ? {fontSize : "12px"} : {}}>{admissionId}</Typography.Text>
          </div>
        )}
      </div>
      <div className="nav-studentlist-actions"></div>
    </StyledNavbar>
  );
};

export default Navbar;
