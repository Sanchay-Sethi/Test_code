"use client";
import StudentFee from "../../Fee/StudentFee";
import { useGlobalContext } from "@/lib/context/GlobalContext";

const Fees = () => {
  const { state } = useGlobalContext();
  return (
    <StudentFee
      id={state?.user?.accessMap?.selectedStudent?.id}
      isStudentPage
    />
  );
};

export default Fees;
