interface StudentDetailsTypes {
    branchName?: string,
    className?: string,
    hostelPlanName?: string,
    transportPlanName?: string,
    profile: {
        id?: string,
        branchId?: string,
        status?: string,
        name?: string,
        phoneNumber?: string,
        secondaryPhoneNumber?: string,
        email?: string,
        dateOfBirth?: string,
        gender?: string,
        admissionNumber?: string,
        admissionYear?: string,
        address?: string,
        fatherName?: string,
        motherName?: string,
        createdAt?: string,
        updatedAt?: string,
        image?: string,
    },
    enrolment: {
        id?: string,
        studentId?: string,
        academicYearId?: string,
        classId?: string,
        newAdmission?: boolean,
        transportPlanId?: string,
        hostelPlanId?: string,
        discountIds?: Array[],
        previousDues?: BigInteger,
        createdAt?: string,
        updatedAt?: string,
    }
}

interface StudentDetailsInitialTypes {
    branchId?: string,
    status?: string,
    name?: string,
    phoneNumber?: string,
    secondaryPhoneNumber?: string,
    email?: string,
    dateOfBirth?: string,
    gender?: string,
    admissionNumber?: string,
    admissionYear?: string,
    address?: string,
    fatherName?: string,
    motherName?: string,
    classId?: string,
    transportPlanId?: string,
    hostelPlanId?: string,
}

interface StudentFeeLineItemTypes {
    key?: string,
    name?: string,
    type?: string,
    dueDate?: string,
    overdueDays?: number,
    dues?: number,
    paid?: number,
    toPay?: number,
    fee?: number,
    discount?: number,
    id?: string,
}

interface EnrolmentTypes {
    id?: string,
    studentId?: string,
    academicYearId?: string,
    classId?: string,
    newAdmission?: boolean,
    transportPlanId?: string,
    hostelPlanId?: string,
    discountIds?: {
        [key: string]: string
    },
    previousDues?: number,
    createdAt?: string,
    updatedAt?: string,
}

interface StudentFeeTypes {
    totalDues?: number,
    totalPaid?: number,
    totalToPay?: number,
    totalOverdue?: number,
    maxOverdueDays?: number,
    items?: StudentFeeLineItemTypes[]
}

interface StudentStateFeeTypes {
    totalDues?: number,
    feeDetailsMap?: Partial<Record<FeeType, StudentFeeLineItemTypes[]>>
}

interface EnrolmentTypes {
    id?: string;
    studentId?: string;
    academicYearId?: string;
    academicYearName?: string;
    className?: string;
    transportPlanName?: string;
    hostelPlanName?: string;
}

type FeeType = 'PROGRAM' | 'ADMISSION' | 'TRANSPORT' | 'HOSTEL';