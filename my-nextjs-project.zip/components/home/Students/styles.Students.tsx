"use client";

import styled, { css } from "styled-components";
import { CommonStylesProps, StyledContextProps } from "@/types";
import {
  AddInlineMobilePadding,
  AddVerticalMobilePadding,
  commonContainerMobileExtraStyles,
  mobileNavbarExtraStyles,
} from "@/components/common/styles.common";
import { GLOBAL_CONSTANTS } from "@/constants";

export const StyledStudents = styled.div<StyledContextProps>`
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  gap: 20px;

  .ant-table-thead > tr > th {
    background: transparent;
    font-weight: 500;
    text-transform: uppercase;
  }

  .ant-table-tbody > tr > td,
  .ant-table-wrapper tfoot > tr > td {
    padding: 15px 16px;
  }

  .sort-icon {
    opacity: 0;
    transition: opacity 0.2s ease-in-out;
  }

  .sortable-column:hover .sort-icon {
    opacity: 1;
  }

  .student-clickable-row {
    cursor: pointer;
    transition: color 0.4s ease;
  }

  .student-clickable-row:hover td {
    color: ${({ token }) => token?.colorLink};
  }

  .ant-table-wrapper {
    height: calc(100vh - 165px);
    overflow: auto;

    .ant-pagination {
      position: sticky;
      bottom: 0px;
      background-color: ${({ token }) => token?.colorBgBase};
      padding: 12px 20px;
      margin: 0px;
    }
  }

  ${commonContainerMobileExtraStyles}
`;

export const StyledNavbar = styled.div<StyledContextProps>`
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 15px;
  flex-wrap: wrap;

  .nav-studentlist-header {
    display: flex;
    align-items: center;
    gap: 15px;
    flex-wrap: wrap;
  }

  .nav-studentlist-title {
    display: flex;
    align-items: center;
    gap: 10px;
  }

  .nav-studentlist-dropdown {
    display: flex;
    align-items: center;
    gap: 10px;
    cursor: pointer;
  }

  @media (max-width: ${GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.RESPONSIVE_WIDTH}px) {
    .nav-studentlist-dropdown {
      border-radius: 20px;
      padding: 2px 12px;
      border: 1px solid ${({ token }) => token?.colorBorder};
    }
  }

  .nav-studentlist-actions {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 10px;
  }

  .tag-container {
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 4px 6px;
    background-color: ${({ token }) => token?.colorCustomTag};
    border-radius: 8px;
    font-weight: 500;
  }

  ${mobileNavbarExtraStyles}
`;

export const StyledFilters = styled.div`
  display: flex;
  align-items: center;
  gap: 20px;
  /* flex-wrap: wrap; */

  .filter-container {
    display: flex;
    align-items: center;
    gap: 15px;
    flex-wrap: wrap;
  }

  .search-input {
    .ant-input-prefix {
      svg {
        color: #697386;
      }
    }
  }

  ${AddInlineMobilePadding}
`;

export const StyledStatus = styled.div`
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 10px;
`;

export const StyledStudentForm = styled.div`
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 30px;

  @media (max-width: ${GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.RESPONSIVE_WIDTH}px) {
    gap: 12px;
  }
`;

export const StyledStudent = styled.div`
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 30px;

  @media (max-width: ${GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.RESPONSIVE_WIDTH}px) {
    gap: 12px;
  }
`;

export const StyledStudentDetailsForm = styled.div<StyledContextProps>`
  width: 100%;
  position: relative;

  .form-footer-container {
    position: fixed;
    bottom: 10px;
    right: 28px;
    /* padding: 5px 0px; */
    border-radius: 20px;
    background-color: ${({ token }) => token?.colorBgBase};
    display: flex;
    justify-content: flex-end;
    align-items: center;
    gap: 12px;
  }

  .student-details-form {
    width: 100%;
    overflow: auto;
    display: flex;
    align-items: stretch;
    justify-content: stretch;
    flex-wrap: wrap;
    gap: 10px;
    column-gap: 50px;
    padding-bottom: 20px;
  }

  .student-form-field {
    flex: 1 1 calc(50% - 50px);
    height: fit-content;
  }

  .form-items-spaned-container {
    width: 100%;
    display: flex;
    gap: 12px;
  }

  .form-item-half-container {
    flex: 1;
  }

  .width-half {
    flex: unset;
    width: 50%;
  }

  .ant-form-item {
    margin-bottom: 18px;
  }

  .ant-image-mask {
    border-radius: 50%;
  }

  .upload-image-container {
    display: flex;
    align-items: center;
    width: 100%;
    gap: 16px;
    flex-wrap: wrap;

    .photo-uploader {
      display: flex;
      gap: 5px;
      flex-direction: column;

      .upload-button-container {
        display: flex;
        align-items: center;
        gap: 3px;
      }
    }
  }

  @media (max-width: ${GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.RESPONSIVE_WIDTH}px) {
    ${AddInlineMobilePadding};
    ${AddVerticalMobilePadding};
    background-color: ${({ token }) => token?.colorBgBase};
    border-top-right-radius: ${GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.BORDER_RADIUS}px;
    border-top-left-radius: ${GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.BORDER_RADIUS}px;
    
    .student-details-form {
      flex-wrap: nowrap;
      flex-direction: column;
      overflow-y: auto;
    }

    .student-form-field {
      width: 100%;
      flex: 0 0 auto;
      height: fit-content;
    }

    .form-items-spaned-container {
      flex-direction: column;
    }

    .form-item-half-container {
      width: 100%;
    }
  }
`;

export const StyledStudentDetailsTabs = styled.div<StyledContextProps>`
  width: 100%;
  ${AddInlineMobilePadding};

  @media (max-width: ${GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.RESPONSIVE_WIDTH}px) {
    border-top-right-radius: ${GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.BORDER_RADIUS}px;
    border-top-left-radius: ${GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.BORDER_RADIUS}px;
    background-color: ${({ token }) => token?.colorBgBase};
    padding-top: 14px;
  }
`;

export const StyledStudentDetails = styled.div<CommonStylesProps>`
  width: 100%;
  height: calc(100vh - 185px);
  overflow: auto;

  @media (max-width: ${GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.RESPONSIVE_WIDTH}px) {
    ${({ alterHeight }) => alterHeight && css`
      height: ${alterHeight ? alterHeight : "100px"};
    `}
  }

  ${({ styles }) => styles || ""}
`;

export const StyledOverview = styled.div<StyledContextProps>`
  width: 90%;
  height: 100%;
  display: flex;
  align-items: stretch;
  /* flex-wrap: wrap; */
  gap: 20px;

  .ant-image-mask {
    border-radius: 50%;
  }

  .ant-typography {
    margin-bottom: 0;
  }

  .overview-card {
    width: 100%;
    height: 100%;
    overflow: auto;
    padding: 16px;
    border: 1px solid ${({ token }) => token?.colorBorder};
    border-radius: 4px;
    display: flex;
    flex-direction: column;
    gap: 16px;

    .image-container {
      width: 100%;
      display: flex;
      justify-content: center;
      align-items: center;
      flex-direction: column;
      gap: 5px;
      padding-bottom: 15px;

      .student-status {
        width: 100%;
        display: flex;
      }
    }

    .overview-details {
      width: 100%;
      display: flex;
      flex-direction: column;
      gap: 20px;

      .information-title {
        font-weight: 600;
        color: ${({ token }) => token?.colorGreyPrimary};
      }

      .basic-information {
        width: 100%;
        display: flex;
        flex-direction: column;
        gap: 18px;

        .information-student {
          display: flex;
          align-items: center;
          gap: 8px;

          .icon-container-student {
            width: 30px;
            display: flex;
            justify-content: center;
            align-items: center;
          }

          span {
            color: ${({ token }) => token?.colorGreyPrimary};
          }
        }
      }
    }

     @media (max-width: ${GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.RESPONSIVE_WIDTH}px) {
      overflow: visible;
     }
  }

  .personal-information-content {
    width: 100%;
    display: flex;
    align-items: center;

    .info-title {
      width: 40%;
      display: flex;
    }

    .info-desc {
      width: 60%;
      display: flex;
    }

    span {
      color: ${({ token }) => token?.colorGreyPrimary};
    }
  }

  .coming-soon-container {
    width: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
    border-radius: 6px;
    padding: 30px;
    background-color: ${({ token }) => token?.colorGreyCard};

    .coming-soon-content {
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 2px 16px;
      gap: 8px;
      background-color: ${({ token }) => token?.colorBgBase};
      border-radius: 4px;
    }
  }

  .personal-information-wrapper {
    width: 45%;
    display: flex;
    display: flex;
    flex-direction: column;
    gap: 20px;
  }

  .basic-information-wrapper {
    width: 45%;
  }

  @media (max-width: ${GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.RESPONSIVE_WIDTH}px) {
    width: 100%;
    flex-direction: column;

    .personal-information-wrapper {
      width: 100%;
    }

    .basic-information-wrapper {
      width: 100%;
    }
  }
`;

export const StyledFeeView = styled.div<StyledContextProps>`
  width: 100%;
  overflow: auto;
  /* padding: 20px 0; */
  display: flex;
  flex-direction: column;
  gap: 20px;

  .fee-container-view {
    height: calc(100vh - 225px);
    overflow: auto;
    position: relative;
  }

  .ant-typography {
    margin-bottom: 0px;
  }

  .fee-title-container {
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 20px;
    margin-top: 40px;

    .total-fee-container {
      display: flex;
      flex-direction: column;

      .fee-title {
        display: flex;
        align-items: center;
        gap: 10px;
        color: ${({ token }) => token?.colorGreySecondary};
        font-size: 13px;
      }

      .fee-dues {
        color: ${({ token }) => token?.colorText};
        font-size: 24px;
        font-weight: 700;
      }
    }

    .acedemic-year-container {
      display: flex;
      align-items: center;
      gap: 16px;
      flex-wrap: wrap;
    }
  }

  @media (max-width: ${GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.RESPONSIVE_WIDTH}px) {
    .fee-title-container {
      margin-top: 0;

      .total-fee-container {
        background-color: ${({token}) => token?.colorBgBase};
        border-radius: 14px;
        width: 100%;
        padding: 12px 20px;
      }
    }
    .fee-container-view {
      height: calc(100vh - 198px);
    }
  }

`;

export const StyledFeeTables = styled.div`
  width: 100%;
  display: flex;
  flex-direction: column;
  padding: 30px 0;
  gap: 50px;

  .ant-table-thead > tr > th {
    background: transparent;
    font-weight: 400;
    text-transform: uppercase;
  }

  .ant-table-tbody > tr > td,
  .ant-table-wrapper tfoot > tr > td {
    padding: 10px 16px;
  }

  .fee-table-container {
    display: flex;
    flex-direction: column;
    gap: 10px;
  }
`;

export const StyledEnrolment = styled.div`
    margin: 20px 0;
    .ant-table-thead > tr > th {
      background: transparent;
      font-weight: 400;
      text-transform: uppercase;
    }

    .ant-table-tbody > tr > td,
    .ant-table-wrapper tfoot > tr > td {
      padding: 10px 16px;
    }
`;
