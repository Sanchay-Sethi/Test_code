"use client";

import { useEffect } from "react";
import { useParams, useSearchParams } from "next/navigation";
import Navbar from "./components/Navbar";
import StudentsListing from "./components/StudentsListing";
import Filters from "./components/Filters";
import { useStudents } from "@/lib/context/students/StudentsContext";
import { StyledStudents } from "./styles.Students";
import { theme } from "antd";

const Students = () => {
  const { actions } = useStudents();
  const { token } = theme.useToken();
  const searchParams = useSearchParams();
  const {branchid} = useParams();

  useEffect(() => {
    // This Effect calls when any change in params
    const params: Record<string, string> = {};
    for (const [key, value] of searchParams?.entries()) {
      params[key] = value;
    }
    if (Object?.keys(params)?.length > 0) {
      actions?.fetchStudents(branchid as string, params);
    } else {
      actions?.fetchStudents(branchid as string);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchParams]);

  return (
    <StyledStudents token = {token}>
      <Navbar statusInit={searchParams.get("status") || ""} />
      <Filters nameSearchInit={searchParams.get("nameSearch") || ""} />
      <StudentsListing
        offsetInit={searchParams.get("offset") || ""}
        limitInit={searchParams.get("limit") || ""}
        sortInit={searchParams.get("sort") || ""}
        orderInit={searchParams.get("order") || ""}
      />
    </StyledStudents>
  );
};

export default Students;
