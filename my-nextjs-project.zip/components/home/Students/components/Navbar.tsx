"use client";

import { useEffect, useState } from "react";
import { Badge, Button, Popover, theme, Typography } from "antd";
import { useSearchParams } from "next/navigation";
import { CaretDownOutlined } from "@ant-design/icons";
import { GLOBAL_CONSTANTS } from "@/constants";
import { PLUS_ICON, USER_ICON } from "../Icons";
import { StyledNavbar, StyledStatus } from "../styles.Students";
import { useNavigation } from "@/lib/context/NavigationContext";
import { SideMenuIcons } from "../../Sidebar/Icons";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";
import {
  ButtonInlineStyles,
  StyledFloatButton,
} from "@/components/common/styles.common";

const { Title } = Typography;

// eslint-disable-next-line @typescript-eslint/no-unused-vars
const Status = ({ handleClick = (status?: string) => {} }) => {
  return (
    <StyledStatus>
      {Object.keys(GLOBAL_CONSTANTS.STUDENT_STATUS)?.map((status) => {
        return (
          <Button
            key={status}
            type="text"
            style={{
              justifyContent: "flex-start",
            }}
            onClick={() => handleClick(status)}
            icon={
              <Badge
                color={
                  GLOBAL_CONSTANTS.TAG_STATUS_COLOR?.[
                    status as keyof typeof GLOBAL_CONSTANTS.STUDENT_STATUS
                  ]
                }
              />
            }
          >
            {
              GLOBAL_CONSTANTS.STUDENT_STATUS?.[
                status as keyof typeof GLOBAL_CONSTANTS.STUDENT_STATUS
              ]
            }{" "}
            students
          </Button>
        );
      })}
    </StyledStatus>
  );
};

const Navbar = ({ statusInit = "" }: { statusInit: string }) => {
  const { token } = theme.useToken();
  const { navigate } = useNavigation();
  const searchParams = useSearchParams();
  const isMobile = useIsSmallDevice();

  const [openDropdown, setOpenDropdown] = useState(false);
  const [status, setStatus] = useState(statusInit);

  function handleOpenChange(newOpen = false) {
    setOpenDropdown(newOpen);
  }

  function handleStatusDropdownOptionChange(status: string = "") {
    if (status === "ALL") {
      setStatus("");
    } else {
      setStatus(status);
    }
    setOpenDropdown(false);
  }

  useEffect(() => {
    const params = new URLSearchParams(searchParams.toString());
    if (status) {
      params.set("status", status?.trim());
    } else {
      params.delete("status");
    }
    navigate(`?${params.toString()}`);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [status]);

  function handleClick() {
    navigate("/students/student");
  }

  return (
    <StyledNavbar token={token}>
      <div className={isMobile ? "flex gap-4 flex-wrap" : "flex-col gap-1.5"}>
        <div className="flex items-center gap-1.5">
          {SideMenuIcons.STUDENTS()}
          <Typography.Paragraph>Students</Typography.Paragraph>
        </div>
        <div className="nav-studentlist-header">
          <Popover
            content={<Status handleClick={handleStatusDropdownOptionChange} />}
            trigger="click"
            arrow={false}
            open={openDropdown}
            onOpenChange={handleOpenChange}
          >
            <div className="nav-studentlist-dropdown">
              {isMobile ? (
                <Typography.Paragraph>
                  {!status
                    ? "All"
                    : GLOBAL_CONSTANTS.STUDENT_STATUS?.[
                        status as keyof typeof GLOBAL_CONSTANTS.STUDENT_STATUS
                      ]}{" "}
                  students
                </Typography.Paragraph>
              ) : (
                <Title level={3} style={{ marginBottom: 0 }}>
                  {!status
                    ? "All"
                    : GLOBAL_CONSTANTS.STUDENT_STATUS?.[
                        status as keyof typeof GLOBAL_CONSTANTS.STUDENT_STATUS
                      ]}{" "}
                  students
                </Title>
              )}
              <CaretDownOutlined
                rotate={openDropdown ? 180 : 0}
                style={{
                  color: token?.colorIcon,
                  fontSize: isMobile ? "10px" : "16px",
                }}
              />
            </div>
          </Popover>
        </div>
      </div>
      {!isMobile ? (
        <div className="nav-studentlist-actions">
          <Button icon={<USER_ICON />}>Bulk upload</Button>
          <Button type="primary" icon={<PLUS_ICON />} onClick={handleClick}>
            Add student
          </Button>
        </div>
      ) : (
        <StyledFloatButton>
          <Button
            type="primary"
            icon={<PLUS_ICON />}
            onClick={handleClick}
            style={ButtonInlineStyles}
          >
            Add student
          </Button>
        </StyledFloatButton>
      )}
    </StyledNavbar>
  );
};

export default Navbar;
