"use client";

import { useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import { Button, Input } from "antd";
import { SearchOutlined } from "@ant-design/icons";
import { useDebounce } from "@/lib/hooks/useDebounce";
import { FILTER_ICON } from "../Icons";
import { StyledFilters } from "../styles.Students";
import { useNavigation } from "@/lib/context/NavigationContext";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";

const Filters = ({ nameSearchInit }: { nameSearchInit: string }) => {
  const { navigate } = useNavigation();
  const searchParams = useSearchParams();
  const isMobile = useIsSmallDevice();

  const [nameSearch, setNameSearch] = useState(nameSearchInit);
  const debouncedSearch = useDebounce(nameSearch, 500);

  function handleChange(key = "", value = "") {
    if (key === "nameSearch") {
      setNameSearch(value);
    }
  }

  useEffect(() => {
    const params = new URLSearchParams(searchParams.toString());
    if (debouncedSearch) {
      params.set("nameSearch", debouncedSearch?.trim());
    } else {
      params.delete("nameSearch");
    }

    navigate(`?${params.toString()}`);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debouncedSearch]);

  return (
    <StyledFilters>
      <div className="filter-search">
        <Input
          type="text"
          prefix={<SearchOutlined />}
          placeholder="Search by name..."
          className="search-input"
          value={nameSearch}
          size={isMobile ? "small" : "middle"}
          style={
            isMobile
              ? { borderRadius: "8px", padding: "2px 15px", fontSize: 14 }
              : {}
          }
          onChange={(e) => handleChange("nameSearch", e.target.value)}
        />
      </div>
      {isMobile ? null : (
        <div className="filter-container">
          <Button
            icon={<FILTER_ICON />}
            shape="circle"
            className="filter-mock-button"
          />
          {/* <Button
          icon={<DownOutlined style={{ fontSize: 10 }} />}
          iconPosition="end"
        >
          Branch
        </Button> */}
          {/* <Button
          icon={<DownOutlined style={{ fontSize: 10 }} />}
          iconPosition="end"
        >
          Status
        </Button> */}
          {/* <Button
          icon={<DownOutlined style={{ fontSize: 10 }} />}
          iconPosition="end"
        >
          Order
        </Button> */}
        </div>
      )}
    </StyledFilters>
  );
};

export default Filters;
