"use client";

import { useMemo } from "react";
import { useSearchParams } from "next/navigation";
import { PaginationProps, Table, Tag } from "antd";
import { CaretDownOutlined, CaretUpOutlined } from "@ant-design/icons";
import { FilterRestProps } from "antd/es/table/interface";
import { useStudents } from "@/lib/context/students/StudentsContext";
import { GLOBAL_CONSTANTS } from "@/constants";
import { useNavigation } from "@/lib/context/NavigationContext";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";
import StudentMobileCard from "@/components/reusable/cards/StudentMobileCard/StudentMobileCard";
import { StyledMobileSpacedContainer } from "@/components/common/styles.common";
import { GENERAL_COMPONENTS } from "@/components/common";
import GeneralSkeleton from "@/components/reusable/Loader/Skeleton/GeneralSkeleton";
import VirtualSwiper from "@/components/reusable/Swiper/virtual/VirtualVerticalSwiper";

const SORT_COLUMN_NAME = {
  name: "NAME",
  admissionNumber: "ADMISSION_NUMBER",
  programName: "PROGRAM_NAME",
  sectionName: "SECTION_NAME",
  status: "STATUS",
};

const SORT_ORDER = {
  ASC: "ascend",
  DESC: "descend",
};

type OrderType = {
  sortOrder?: "ascend" | "descend" | null | undefined;
};

type SortOrder = "ascend" | "descend" | null;

function getSortIcon(order: OrderType) {
  if (order?.sortOrder === "ascend") return <CaretUpOutlined />;
  if (order?.sortOrder === "descend") return <CaretDownOutlined />;
  return null;
}

const StudentsListing = ({
  // offsetInit = "",
  // limitInit = "",
  sortInit = "",
  orderInit = "",
}: {
  offsetInit: string;
  limitInit: string;
  sortInit: string;
  orderInit: string;
}) => {
  const { state } = useStudents();
  const searchParams = useSearchParams();
  const isMobile = useIsSmallDevice();
  const { navigate } = useNavigation();

  const columns = useMemo(
    () => [
      {
        key: "ADMISSION_NUMBER",
        title: "Admission Id",
        dataIndex: "admissionNumber",
        ellipsis: true,
        sorter: true,
        width: 150,
        sortIcon: (sortOrder: OrderType) => getSortIcon(sortOrder),
        sortOrder:
          sortInit === "ADMISSION_NUMBER"
            ? (SORT_ORDER?.[orderInit as keyof typeof SORT_ORDER] as SortOrder)
            : null,
      },
      {
        key: "NAME",
        title: "Name",
        dataIndex: "name",
        ellipsis: true,
        sorter: true,
        width: 150,
        sortIcon: (sortOrder: OrderType) => getSortIcon(sortOrder),
        sortOrder:
          sortInit === "NAME"
            ? (SORT_ORDER?.[orderInit as keyof typeof SORT_ORDER] as SortOrder)
            : null,
      },
      {
        key: "PROGRAM_NAME",
        title: "Program",
        dataIndex: "programName",
        ellipsis: true,
        sorter: true,
        width: 150,
        sortIcon: (sortOrder: OrderType) => getSortIcon(sortOrder),
        sortOrder:
          sortInit === "PROGRAM_NAME"
            ? (SORT_ORDER?.[orderInit as keyof typeof SORT_ORDER] as SortOrder)
            : null,
      },
      {
        key: "SECTION_NAME",
        title: "Section",
        dataIndex: "sectionName",
        ellipsis: true,
        sorter: true,
        width: 150,
        sortIcon: (sortOrder: OrderType) => getSortIcon(sortOrder),
        sortOrder:
          sortInit === "SECTION_NAME"
            ? (SORT_ORDER?.[orderInit as keyof typeof SORT_ORDER] as SortOrder)
            : null,
      },
      {
        key: "STATUS",
        title: "Status",
        dataIndex: "status",
        ellipsis: true,
        sorter: true,
        width: 150,
        sortIcon: (sortOrder: OrderType) => getSortIcon(sortOrder),
        sortOrder:
          sortInit === "STATUS"
            ? (SORT_ORDER?.[orderInit as keyof typeof SORT_ORDER] as SortOrder)
            : null,
        render: (tag: null | undefined) => {
          return (
            <Tag
              color={GLOBAL_CONSTANTS?.TAG_STATUS_COLOR?.[tag || "ACTIVE"]}
              key={tag}
            >
              {tag}
            </Tag>
          );
        },
      },
    ],
    [sortInit, orderInit]
  );

  async function onChange(
    pagination: PaginationProps,
    filters: FilterRestProps,
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    sorter: any,
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    extra: any
  ) {
    const params = new URLSearchParams(searchParams.toString());

    // Handle SORT
    if (extra?.action === "sort") {
      params.set(
        "sort",
        SORT_COLUMN_NAME[sorter?.field as keyof typeof SORT_COLUMN_NAME]
      );
      if (sorter?.order === "ascend") {
        params.set("order", "ASC");
      } else if (sorter?.order === "descend") {
        params.set("order", "DESC");
      } else if (!sorter?.order) {
        params.delete("sort");
        params.delete("order");
      }
    } else if (extra?.action === "paginate") {
      // TODO: WILL ADD THIS IF NEEDED
      // Handle Pagination
      // if (pagination?.current === 1) {
      //   params.delete("offset");
      // } else if (pagination?.current !== 1) {
      //   params.set("offset", `${(pagination?.current ?? 1) - 1}`);
      // }
      // if (pagination?.pageSize === 10) {
      //   params.delete("limit");
      // } else if (pagination?.pageSize !== 10) {
      //   params.set("limit", `${pagination?.pageSize}`);
      // }
    }
    navigate(`?${params.toString()}`);
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const handleRowClick = (record: any) => {
    if (record?.id) {
      navigate(`/students/student/${record?.id}`);
    }
  };

  if (isMobile) {
    return (
      <StyledMobileSpacedContainer>
        {state.loading ? (
          <GeneralSkeleton
            countSmall={0}
            countLarge={10}
            isLargeWrapped
            largeBoxHeight={100}
          />
        ) : state?.studentsListing?.length === 0 && !state?.loading ? (
          <GENERAL_COMPONENTS.NoResult />
        ) : (
          <VirtualSwiper
            items={state?.studentsListing || []}
            getKey={(student) => student.id || ""}
            renderItem={(data) => (
              <StudentMobileCard details={data} onClick={handleRowClick} />
            )}
          />
        )}
      </StyledMobileSpacedContainer>
    );
  }

  return (
    <Table
      loading={state?.loading}
      columns={columns}
      dataSource={state?.studentsListing || []}
      onChange={onChange}
      sticky={true}
      // virtual={true}
      tableLayout={"fixed"}
      onRow={(record) => ({
        onClick: () => handleRowClick(record),
      })}
      rowClassName={() => "student-clickable-row"}
      scroll={{ x: "max-content" }}
      pagination={{
        position: ["bottomRight"],
        total: (state?.studentsListing || [])?.length,
        showTotal: (total) => `Total ${total} items`,
        showSizeChanger: true,
        // showQuickJumper: true,
        // defaultCurrent: offsetInit ? parseInt(offsetInit) : 1,
        // defaultPageSize: limitInit ? parseInt(limitInit) : 10,
        // hideOnSinglePage: true,
        align: "center",
      }}
    />
  );
};

export default StudentsListing;
