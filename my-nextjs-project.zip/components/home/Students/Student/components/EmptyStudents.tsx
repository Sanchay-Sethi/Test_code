import { useNavigation } from "@/lib/context/NavigationContext";
import { Button, Result } from "antd";
import { useRouter } from "next/navigation";
import { useEffect, useRef } from "react";

const EmptyStudents = ({ id = "" }: { id?: string }) => {
  const router = useRouter();
  const { navigate } = useNavigation();

  const hasHistory = useRef(false);

  useEffect(() => {
    hasHistory.current = window.history.length > 1;
  }, []);

  const handleClick = () => {
    if (hasHistory?.current) {
      router.back();
    } else {
      navigate("/home");
    }
  };
  return (
    <Result
      status="error"
      title="No student found !"
      subTitle={`Not able to find student with id - ${id}`}
      extra={[
        <Button type="primary" key="back" onClick={handleClick}>
          Go back
        </Button>,
      ]}
    ></Result>
  );
};

export default EmptyStudents;
