"use client";

import {
  Button,
  DatePicker,
  Form,
  Image,
  Input,
  Radio,
  Select,
  theme,
  Tooltip,
  Typography,
  Upload,
  UploadFile,
} from "antd";
import { StyledStudentDetailsForm } from "../../styles.Students";
import { GLOBAL_CONSTANTS } from "@/constants";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";
import { useEffect, useState } from "react";
import {
  CheckOutlined,
  DeleteOutlined,
  UploadOutlined,
} from "@ant-design/icons";
import { RcFile } from "antd/es/upload";
import { GENERAL_COMPONENTS } from "@/components/common";
import { ButtonInlineStyles } from "@/components/common/styles.common";
import {
  getInitialValues,
  getPayload,
  getRequiredFormOptions,
} from "../Helpers.Student";
import apiClient from "@/lib/apiClient";
import HELPERS from "@/lib/helpers";
import { useNavigation } from "@/lib/context/NavigationContext";

const { TextArea } = Input;

interface OptionItem {
  label: string;
  value: string;
}

interface OptionsType {
  branch: OptionItem[];
  transport: OptionItem[];
  hostel: OptionItem[];
  classOption: OptionItem[];
}

const StudentDetailsForm = ({
  mode,
  details = {
    profile: {},
    enrolment: {},
  },
  callBack = () => {},
}: {
  mode?: string;
  details?: StudentDetailsTypes;
  callBack?: () => void;
}) => {
  const [imageFile, setImageFile] = useState<UploadFile | null>(null);
  const [image, setImage] = useState("");
  const formData = new FormData();

  const [options, setOptions] = useState<OptionsType>({
    branch: [],
    transport: [],
    hostel: [],
    classOption: [],
  });

  const [form] = Form.useForm();
  const { token } = theme.useToken();
  const { navigate } = useNavigation();
  const isSmallDevice = useIsSmallDevice(786);

  const isCreateMode = !mode;

  useEffect(() => {
    form.setFieldsValue(getInitialValues(details));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [details]);

  useEffect(() => {
    (async () => {
      try {
        const formattedData = await getRequiredFormOptions();
        if (details?.profile?.id) {
          const imgRes = await apiClient.get(
            `/student/photo/${details?.profile?.id}`,
            {
              responseType: "blob",
            }
          );
          if (imgRes?.status === 204 && imgRes?.statusText === "No Content") {
            setImage("");
          } else {
            const url = URL.createObjectURL(imgRes?.data);
            setImage(url);
          }
        }
        setOptions(formattedData);
      } catch {}
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleBeforeUpload = (file: File) => {
    if (window.ReactNativeWebView && window.ReactNativeWebView.postMessage) {
      window.ReactNativeWebView.postMessage(
        JSON.stringify({ type: "REQUEST_UPLOAD_PERMISSION" })
      );
    }

    const rcFile = Object.assign(file, {
      uid: String(Date.now()),
    }) as RcFile;

    const uploadFile: UploadFile = {
      uid: rcFile.uid,
      name: rcFile.name,
      status: "done",
      url: URL.createObjectURL(file),
      originFileObj: rcFile,
    };

    setImageFile(uploadFile);
    return false; // prevent auto upload
  };

  const handleRemoveImage = () => {
    setImageFile(null);
  };

  function handleCancel() {
    if (!mode) {
      navigate("/students");
    } else {
      navigate(`/students/student/${details?.profile?.id}`);
    }
  }

  async function onFinish(values: StudentDetailsInitialTypes = {}) {
    const body = getPayload(values, details);
    try {
      const res =
        mode === "EDIT_STUDENT"
          ? await apiClient.put("/student", body)
          : await apiClient.post("/student", body);
      HELPERS.messageAlert({
        success:
          mode === "EDIT_STUDENT"
            ? "Updated successfully"
            : "Created successfully",
      });
      if (imageFile) {
        formData.append("file", imageFile?.originFileObj || "");
        await apiClient.put(
          `/student/photo/${res?.data?.profile?.id}`,
          formData
        );
      }
      if (isCreateMode && res?.data?.profile?.id) {
        navigate(
          `/students/student/${res?.data?.profile?.id}?mode=EDIT_STUDENT`
        );
      } else {
        callBack();
      }
    } catch {}
  }

  function getStatusOptions() {
    const optionsMap: { [key: string]: string } =
      GLOBAL_CONSTANTS.STUDENT_STATUS || {};
    delete optionsMap?.["ALL"];
    return Object.keys(optionsMap).map((key) => {
      return {
        label: optionsMap?.[key as keyof typeof optionsMap],
        value: key,
      };
    });
  }

  return (
    <StyledStudentDetailsForm token={token}>
      <Form
        form={form}
        layout="vertical"
        autoComplete="off"
        scrollToFirstError={{
          behavior: "smooth",
          block: "center",
          inline: "center",
        }}
        onFinish={onFinish}
      >
        {!isSmallDevice ? (
          <div className="student-details-form">
            <div className="student-form-field">
              <Form.Item name="profilePhoto">
                <div className="upload-image-container">
                  {imageFile || image ? (
                    <Image
                      width={120}
                      height={120}
                      src={imageFile?.url || image || ""}
                      alt="Profile Picture"
                      style={{ borderRadius: "50%", objectFit: "cover" }}
                    />
                  ) : (
                    <GENERAL_COMPONENTS.ImagePlaceholder />
                  )}
                  <div className="photo-uploader">
                    <Typography.Text>Profile photo</Typography.Text>
                    <div className="upload-button-container">
                      <Upload
                        beforeUpload={handleBeforeUpload}
                        showUploadList={false}
                        accept="image/*"
                      >
                        <Button
                          icon={<UploadOutlined />}
                          //   color="primary"
                          //   variant="outlined"
                        >
                          {imageFile?.url || image ? "Update image" : "Upload"}
                        </Button>
                      </Upload>
                      {/* {imageFile && (
                        <Tooltip title={"Delete the image"}>
                          <Button
                            type="text"
                            shape="circle"
                            danger
                            onClick={handleRemoveImage}
                          >
                            <DeleteOutlined />
                          </Button>
                        </Tooltip>
                      )} */}
                    </div>
                  </div>
                </div>
              </Form.Item>
            </div>
            <div className="student-form-field">
              <div className="form-items-spaned-container">
                <div className="form-item-half-container">
                  <Form.Item name="fatherName" label="Father name">
                    <Input placeholder="Dan altman" />
                  </Form.Item>
                </div>
                <div className="form-item-half-container">
                  <Form.Item name="motherName" label="Mother name">
                    <Input placeholder="Mary altman" />
                  </Form.Item>
                </div>
              </div>
              <Form.Item
                name="phoneNumber"
                label="Primary phone"
                rules={[
                  {
                    required: true,
                  },
                ]}
              >
                <Input placeholder="+91 987xxxx321" />
              </Form.Item>
            </div>
            <div className="student-form-field">
              <Form.Item
                name="name"
                label="Full name"
                rules={[
                  {
                    required: true,
                  },
                ]}
              >
                <Input placeholder="Eg. Sam altman" />
              </Form.Item>
            </div>
            <div className="student-form-field">
              <Form.Item name="secondaryPhoneNumber" label="Secondary phone">
                <Input placeholder="+91 987xxxx321" />
              </Form.Item>
            </div>
            <div className="student-form-field">
              <div className="form-items-spaned-container">
                <div className="form-item-half-container width-half">
                  <Form.Item
                    name="admissionNumber"
                    label="Admission id"
                    rules={[
                      {
                        required: true,
                      },
                    ]}
                  >
                    <Input placeholder="1001" />
                  </Form.Item>
                </div>
                <div className="form-item-half-container width-half">
                  <Form.Item
                    name="classId"
                    label="Class"
                    rules={[
                      {
                        required: true,
                      },
                    ]}
                  >
                    <Select
                      placeholder="Select"
                      options={options?.classOption}
                    />
                  </Form.Item>
                </div>
              </div>
            </div>
            <div className="student-form-field">
              <Form.Item name="email" label="Email">
                <Input placeholder="sam@company.com" />
              </Form.Item>
            </div>
            <div className="student-form-field">
              <div className="form-items-spaned-container">
                <div className="form-item-half-container">
                  <Form.Item
                    name="branchId"
                    label="Branch"
                    rules={[
                      {
                        required: true,
                      },
                    ]}
                  >
                    <Select placeholder="Select" options={options?.branch} />
                  </Form.Item>
                </div>
                {!isCreateMode && (
                  <div className="form-item-half-container">
                    <Form.Item
                      name="status"
                      label="Status"
                      rules={[
                        {
                          required: true,
                        },
                      ]}
                    >
                      <Select
                        placeholder="Select"
                        options={getStatusOptions()}
                      />
                    </Form.Item>
                  </div>
                )}
              </div>
            </div>
            <div className="student-form-field">
              <div className="form-items-spaned-container">
                <div className="form-item-half-container">
                  <Form.Item name="transportPlanId" label="Transport plan">
                    <Select placeholder="Select" options={options?.transport} />
                  </Form.Item>
                </div>
                <div className="form-item-half-container">
                  <Form.Item name="hostelPlanId" label="Hostel plan">
                    <Select placeholder="Select" options={options?.hostel} />
                  </Form.Item>
                </div>
              </div>
            </div>
            <div className="student-form-field">
              <Form.Item name="gender" label="Gender">
                <Radio.Group>
                  <Radio value="MALE">Male</Radio>
                  <Radio value="FEMALE">Female</Radio>
                  <Radio value="OTHER">Other</Radio>
                </Radio.Group>
              </Form.Item>
              <div className="form-items-spaned-container">
                <div className="form-item-half-container">
                  <Form.Item name="dateOfBirth" label="Date of birth">
                    <DatePicker
                      style={{ width: "100%" }}
                      format="YYYY-MM-DD"
                      placeholder="YYYY-MM-DD"
                    />
                  </Form.Item>
                </div>
                <div className="form-item-half-container">
                  <Form.Item name="admissionYear" label="Admission year">
                    <DatePicker
                      style={{ width: "100%" }}
                      picker="year"
                      placeholder="YYYY"
                    />
                  </Form.Item>
                </div>
              </div>
            </div>
            <div className="student-form-field">
              <Form.Item name="address" label="Address">
                <TextArea
                  rows={5}
                  placeholder="House/Flat no., Area, Pin code, City etc"
                />
              </Form.Item>
            </div>
          </div>
        ) : (
          <div className="student-details-form">
            <div className="student-form-field">
              <Form.Item name="profilePhoto">
                <div className="upload-image-container">
                  {imageFile ? (
                    <Image
                      width={100}
                      height={100}
                      src={imageFile?.url}
                      alt="Profile Picture"
                      style={{ borderRadius: "50%", objectFit: "cover" }}
                    />
                  ) : (
                    <GENERAL_COMPONENTS.ImagePlaceholder />
                  )}
                  <div className="photo-uploader">
                    <Typography.Text>Profile photo</Typography.Text>
                    <div className="upload-button-container">
                      <Upload
                        beforeUpload={handleBeforeUpload}
                        showUploadList={false}
                        accept="image/*"
                      >
                        <Button
                          icon={<UploadOutlined />}
                          //   color="primary"
                          //   variant="outlined"
                        >
                          {imageFile ? "Update image" : "Upload"}
                        </Button>
                      </Upload>
                      {imageFile && (
                        <Tooltip title={"Delete the image"}>
                          <Button
                            type="text"
                            shape="circle"
                            danger
                            onClick={handleRemoveImage}
                          >
                            <DeleteOutlined />
                          </Button>
                        </Tooltip>
                      )}
                    </div>
                  </div>
                </div>
              </Form.Item>
            </div>
            <div className="student-form-field">
              <Form.Item
                name="name"
                label="Full name"
                rules={[
                  {
                    required: true,
                  },
                ]}
              >
                <Input placeholder="Eg. Sam altman" />
              </Form.Item>
            </div>

            <div className="student-form-field">
              <Form.Item
                name="admissionNumber"
                label="Admission id"
                rules={[
                  {
                    required: true,
                  },
                ]}
              >
                <Input placeholder="1001" />
              </Form.Item>
              <Form.Item
                name="classId"
                label="Class"
                rules={[
                  {
                    required: true,
                  },
                ]}
              >
                <Select placeholder="Select" options={options?.classOption} />
              </Form.Item>
            </div>
            <div className="student-form-field">
              <div className="form-items-spaned-container">
                <div className="form-item-half-container">
                  <Form.Item
                    name="branchId"
                    label="Branch"
                    rules={[
                      {
                        required: true,
                      },
                    ]}
                  >
                    <Select placeholder="Select" options={options?.branch} />
                  </Form.Item>
                </div>
                {!isCreateMode && (
                  <div className="form-item-half-container">
                    <Form.Item
                      name="status"
                      label="Status"
                      rules={[
                        {
                          required: true,
                        },
                      ]}
                    >
                      <Select
                        placeholder="Select"
                        options={getStatusOptions()}
                      />
                    </Form.Item>
                  </div>
                )}
              </div>
            </div>
            <div className="student-form-field">
              <Form.Item name="gender" label="Gender">
                <Radio.Group>
                  <Radio value="MALE">Male</Radio>
                  <Radio value="FEMALE">Female</Radio>
                  <Radio value="OTHER">Other</Radio>
                </Radio.Group>
              </Form.Item>
              <div className="form-items-spaned-container">
                <div className="form-item-half-container">
                  <Form.Item name="dateOfBirth" label="Date of birth">
                    <DatePicker
                      style={{ width: "100%" }}
                      placeholder="YYYY-MM-DD"
                    />
                  </Form.Item>
                </div>
                <div className="form-item-half-container">
                  <Form.Item name="admissionYear" label="Admission year">
                    <DatePicker
                      style={{ width: "100%" }}
                      picker="year"
                      placeholder="YYYY"
                    />
                  </Form.Item>
                </div>
              </div>
            </div>
            <div className="student-form-field">
              <Form.Item name="transportPlanId" label="Transport plan">
                <Select placeholder="Select" options={options?.transport} />
              </Form.Item>
              <Form.Item name="hostelPlanId" label="Hostel plan">
                <Select placeholder="Select" options={options?.hostel} />
              </Form.Item>
            </div>
            <div className="student-form-field">
              <Form.Item name="fatherName" label="Father name">
                <Input placeholder="Dan altman" />
              </Form.Item>
              <Form.Item name="motherName" label="Mother name">
                <Input placeholder="Mary altman" />
              </Form.Item>
            </div>
            <div className="student-form-field">
              <Form.Item
                name="phoneNumber"
                label="Primary phone"
                rules={[
                  {
                    required: true,
                  },
                ]}
              >
                <Input placeholder="+91 987xxxx321" />
              </Form.Item>
            </div>
            <div className="student-form-field">
              <Form.Item name="secondaryPhoneNumber" label="Secondary phone">
                <Input placeholder="+91 987xxxx321" />
              </Form.Item>
            </div>
            <div className="student-form-field">
              <Form.Item name="email" label="Email">
                <Input placeholder="sam@company.com" />
              </Form.Item>
            </div>
            <div className="student-form-field">
              <Form.Item name="address" label="Address">
                <TextArea
                  rows={5}
                  placeholder="House/Flat no., Area, Pin code, City etc"
                />
              </Form.Item>
            </div>
          </div>
        )}
        <div className="form-footer-container">
          <Button style={ButtonInlineStyles} onClick={handleCancel}>
            Cancel
          </Button>
          <Button
            style={ButtonInlineStyles}
            icon={<CheckOutlined />}
            htmlType="submit"
            type="primary"
          >
            {mode === "EDIT_STUDENT" ? "Edit" : "Add"} student
          </Button>
        </div>
      </Form>
    </StyledStudentDetailsForm>
  );
};

export default StudentDetailsForm;
