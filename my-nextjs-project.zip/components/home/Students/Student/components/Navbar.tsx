"use client";

import { Button, theme, Typography } from "antd";
import { StyledNavbar } from "../../styles.Students";
import { PENCIL_ICON } from "../../Icons";
import { GENERAL_COMPONENTS } from "@/components/common";
import { useNavigation } from "@/lib/context/NavigationContext";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";
import { ButtonInlineStyles, StyledFloatButton } from "@/components/common/styles.common";

const { Title } = Typography;

const Navbar = ({
  id = "",
  name = "",
  mode = "",
  admissionId = "",
  backUrl = "",
}: {
  id?: string;
  name?: string;
  mode?: string | null;
  admissionId?: string;
  backUrl?: string;
}) => {
  const { navigate } = useNavigation();
  const { token } = theme.useToken();
  const isMobile = useIsSmallDevice();
  const isView = mode === "VIEW_STUDENT" || !mode;

  function handleClick() {
    if (id) {
      navigate(`/students/student/${id}?mode=EDIT_STUDENT`);
    }
  }

  return (
    <StyledNavbar token={token}>
      <div className="nav-studentlist-header">
        <GENERAL_COMPONENTS.BackButton backUrl={backUrl} />
        <div className="nav-studentlist-title">
          <Title level={isMobile ? 5 : 3} style={{ marginBottom: 0 }}>
            {!id ? (
              "Add student"
            ) : (
              <>
                {mode === "EDIT_STUDENT" && "Edit student"}
                {mode === "EDIT_STUDENT" && name && `- ${name}`}
                {mode !== "EDIT_STUDENT" && name}
              </>
            )}
          </Title>
        </div>
        {admissionId && (
          <div className="tag-container">
            <Typography.Text style={isMobile ? { fontSize: 12 } : {}}>
              {admissionId}
            </Typography.Text>
          </div>
        )}
      </div>
      <div className="nav-studentlist-actions">
        {isView &&
          id &&
          (!isMobile ? (
            <Button type="primary" icon={<PENCIL_ICON />} onClick={handleClick}>
              Edit student details
            </Button>
          ) : (
            <StyledFloatButton>
              <Button
                type="primary"
                icon={<PENCIL_ICON />}
                onClick={handleClick}
                style={ButtonInlineStyles}
              >
                Edit student details
              </Button>
            </StyledFloatButton>
          ))}
      </div>
    </StyledNavbar>
  );
};

export default Navbar;
