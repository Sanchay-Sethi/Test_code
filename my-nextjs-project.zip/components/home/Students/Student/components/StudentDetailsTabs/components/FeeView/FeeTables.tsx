import { useEffect, useMemo, useState } from "react";
import { BiPencil } from "react-icons/bi";
import {
  Button,
  Collapse,
  Drawer,
  InputNumber,
  message,
  Select,
  Skeleton,
  Table,
  theme,
  Tooltip,
  Typography,
} from "antd";
import HELPERS from "@/lib/helpers";
import { StyledFeeTables } from "@/components/home/Students/styles.Students";
import { CheckOutlined, CloseOutlined } from "@ant-design/icons";
import apiClient from "@/lib/apiClient";
import { useSearchParams } from "next/navigation";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";
import { GLOBAL_CONSTANTS } from "@/constants";
import { ButtonInlineStyles } from "@/components/common/styles.common";
import GeneralSkeleton from "@/components/reusable/Loader/Skeleton/GeneralSkeleton";
import { GENERAL_COMPONENTS } from "@/components/common";
import VirtualSwiper from "@/components/reusable/Swiper/virtual/VirtualVerticalSwiper";
import { FeeCard } from "@/components/reusable/cards/GeneralCards";

function getOptions(options: OptionsTypes[]) {
  return options?.map((option) => {
    return {
      label: option?.name || option?.label,
      value: option?.id || option?.value,
      _original: option,
    };
  });
}

function InputDiscount({
  value = 0,
  id = "",
  onSave,
  onCancel,
}: {
  value: number;
  id: string;
  onSave: (id?: string, value?: number) => void;
  onCancel: () => void;
}) {
  const [messageApi, contextHolder] = message.useMessage();
  const [inputValue, setInputValue] = useState<number | null>(null);

  function handleSave() {
    if (inputValue == null) {
      return messageApi.open({
        type: "error",
        content: "Please provide discount value",
      });
    }
    onSave(id, inputValue || 0);
  }

  function handleCancel() {
    setInputValue(null);
    onCancel();
  }

  useEffect(() => {
    setInputValue(value);
  }, [value]);

  return (
    <div className="flex items-center gap-1.5">
      {contextHolder}
      <InputNumber
        min={0}
        value={inputValue}
        placeholder="Rs. XXXX"
        onChange={(val) => setInputValue(val)}
        status={inputValue == null ? "error" : ""}
        style={{ width: "100%" }}
      />
      <div className="flex items-center gap-1">
        <Tooltip title="Confirm">
          <Button
            type="text"
            color="green"
            variant="outlined"
            onClick={handleSave}
            icon={<CheckOutlined />}
            shape={"circle"}
            size="small"
          />
        </Tooltip>
        <Tooltip title="Cancel">
          <Button
            type="text"
            color={"danger"}
            variant="outlined"
            onClick={handleCancel}
            icon={<CloseOutlined />}
            shape={"circle"}
            size="small"
          />
        </Tooltip>
      </div>
    </div>
  );
}

const FeeTable = ({
  feeDetail = [],
  enrolment,
  loading = false,
  mainLoader = false,
  onUpdateFeeTables = () => {},
}: {
  feeDetail?: StudentFeeLineItemTypes[];
  enrolment?: EnrolmentTypes;
  loading?: boolean;
  mainLoader?: boolean;
  onUpdateFeeTables?: () => void;
}) => {
  const [activeId, setActiveId] = useState("");

  const isMobile = useIsSmallDevice();

  function handleCancel() {
    setActiveId("");
  }

  async function handleDiscountSave(id = "", value = 0) {
    const body = {
      ...(enrolment || {}),
      discountIds: {
        ...(enrolment?.discountIds || {}),
        [id]: value,
      },
    };
    try {
      await apiClient.put("/student/enrolment", body);
      onUpdateFeeTables();
      handleCancel();
    } finally {
    }
  }

  const columns = useMemo(
    () => [
      {
        key: "INSTALLMENTS",
        title: "Installment",
        dataIndex: "name",
        ellipsis: true,
        width: 150,
      },
      {
        key: "DUE_DATES",
        title: "Due date",
        dataIndex: "dueDate",
        ellipsis: true,
        width: 150,
      },
      {
        key: "FEES",
        title: "FEES",
        dataIndex: "fee",
        ellipsis: true,
        width: 150,
        render: (fee: number) => {
          return `Rs. ${fee?.toLocaleString()}`;
        },
      },
      {
        key: "discount",
        title: "DISCOUNT",
        dataIndex: "discount",
        ellipsis: true,
        width: 200,
        render: (discount: number, data: StudentFeeLineItemTypes) => {
          if (activeId === data?.id) {
            return (
              <InputDiscount
                value={discount}
                id={data?.id}
                onSave={handleDiscountSave}
                onCancel={handleCancel}
              />
            );
          }
          return (
            <div className="flex items-center gap-2">
              Rs. {discount?.toLocaleString()}
              <Tooltip title="Edit">
                <Button
                  shape="circle"
                  color="primary"
                  variant={"text"}
                  icon={<BiPencil />}
                  onClick={() => setActiveId(data?.id || "")}
                />
              </Tooltip>
            </div>
          );
        },
      },
      {
        key: "DUES",
        title: "Fee due",
        dataIndex: "dues",
        ellipsis: true,
        width: 150,
        render: (dues: number) => {
          return `Rs. ${dues?.toLocaleString()}`;
        },
      },
      {
        key: "PAID",
        title: "Fee paid",
        dataIndex: "paid",
        ellipsis: true,
        width: 150,
        render: (paid: number) => {
          return `Rs. ${paid?.toLocaleString()}`;
        },
      },
      {
        key: "TO_PAY",
        title: "Paying amount",
        dataIndex: "toPay",
        ellipsis: true,
        width: 150,
        render: (toPay: number) => {
          return `Rs. ${toPay?.toLocaleString()}`;
        },
      },
    ],
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [activeId]
  );


  if (isMobile) {
    return (
      <>
        {loading ? (
          <GeneralSkeleton
            countSmall={0}
            countLarge={10}
            isLargeWrapped
            largeBoxHeight={100}
          />
        ) : feeDetail?.length === 0 && !loading ? (
          <GENERAL_COMPONENTS.NoResult />
        ) : (
          <VirtualSwiper
            items={feeDetail || []}
            getKey={(fee) => fee?.id || ""}
            cardEstimateWidth={180}
            containerHeight="calc(100vh - 424px)"
            renderItem={(fee) => (
              <FeeCard
                data={fee}
                activeId={activeId}
                onClick={() => setActiveId(fee?.id || "")}
                onSave={handleDiscountSave}
                onCancel={handleCancel}
              />
            )}
          />
        )}
      </>
    );
  }

  return (
    <Table
      dataSource={feeDetail || []}
      columns={columns}
      loading={loading || mainLoader}
      scroll={{ x: "max-content", y: 55 * 5 }}
      pagination={{
        position: ["bottomRight"],
        total: (feeDetail || [])?.length,
        showTotal: (total) => `Total ${total} items`,
        showSizeChanger: true,
        showQuickJumper: true,
        hideOnSinglePage: true,
        align: "center",
      }}
      summary={(pageData) => {
        let totalFees = 0;
        let totalDiscount = 0;
        let totalDues = 0;
        let totalPaid = 0;
        let totalToPay = 0;

        pageData?.forEach(({ dues, paid, toPay, fee, discount }) => {
          totalFees += fee || 0;
          totalDiscount += discount || 0;
          totalDues += dues || 0;
          totalPaid += paid || 0;
          totalToPay += toPay || 0;
        });

        if (feeDetail?.length <= 1) return null;

        return (
          <Table.Summary.Row>
            <Table.Summary.Cell index={0} colSpan={2}>
              <strong>Total</strong>
            </Table.Summary.Cell>
            <Table.Summary.Cell index={3}>
              <strong>Rs {totalFees?.toLocaleString()}</strong>
            </Table.Summary.Cell>
            <Table.Summary.Cell index={3}>
              <strong>- Rs {totalDiscount?.toLocaleString()}</strong>
            </Table.Summary.Cell>
            <Table.Summary.Cell index={3}>
              <strong>Rs {totalDues.toLocaleString()}</strong>
            </Table.Summary.Cell>
            <Table.Summary.Cell index={4}>
              <strong>Rs {totalPaid.toLocaleString()}</strong>
            </Table.Summary.Cell>
            <Table.Summary.Cell index={5}>
              <strong>Rs {totalToPay.toLocaleString()}</strong>
            </Table.Summary.Cell>
          </Table.Summary.Row>
        );
      }}
    />
  );
};

function EditPlanType({
  feeType = "",
  enrolment,
  onUpdateFeeTables = () => {},
}: {
  feeType: string;
  enrolment?: EnrolmentTypes;
  onUpdateFeeTables?: () => void;
}) {
  const isMobile = useIsSmallDevice();

  const [options, setOptions] = useState<OptionsTypes[]>([]);
  const [loading, setLoading] = useState(false);
  const [isEdit, setIsEdit] = useState(false);
  const [feeTypeValue, setFeeTypeValue] = useState("");

  const PLAN_ID_KEY = {
    TRANSPORT: "transportPlanId",
    HOSTEL: "hostelPlanId",
  };

  function getPlanTypeValue(feeType = "", enrolment?: EnrolmentTypes) {
    if (feeType === "TRANSPORT") return enrolment?.transportPlanId || "";
    if (feeType === "HOSTEL") return enrolment?.hostelPlanId || "";
  }

  async function getFeeTypesOptions(type = "") {
    if (feeType !== "PROGRAM") {
      try {
        setLoading(true);
        const res = await apiClient.get(`/fee/plan?feeType=${type}`);
        setOptions(getOptions(res?.data));
      } finally {
        setLoading(false);
      }
    }
  }

  function handleCancel() {
    setIsEdit(false);
    const value = getPlanTypeValue(feeType, enrolment);
    setFeeTypeValue(value || "");
  }

  async function handleSave() {
    const key = PLAN_ID_KEY?.[feeType as keyof typeof PLAN_ID_KEY];
    if (!key) return;
    const body = {
      ...(enrolment || {}),
      [key]: feeTypeValue,
    };
    try {
      await apiClient.put("/student/enrolment", body);
      onUpdateFeeTables();
      setIsEdit(false);
    } finally {
    }
  }

  useEffect(() => {
    if (feeType) {
      getFeeTypesOptions(feeType);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [feeType]);

  useEffect(() => {
    if (enrolment && feeType) {
      const value = getPlanTypeValue(feeType, enrolment);
      setFeeTypeValue(value || "");
    }
  }, [feeType, enrolment]);

  function getBody() {
    console.log({
      feeTypeValue,
    });
    return (
      <div className="flex items-center gap-3">
        {!isMobile && (
          <Typography.Paragraph>
            {HELPERS.capitalizeFirst(feeType)} plan:{" "}
          </Typography.Paragraph>
        )}
        {loading ? (
          <Skeleton.Node style={{ height: "20px" }} active />
        ) : (
          <Select
            value={feeTypeValue || "None"}
            options={options}
            loading={loading}
            allowClear
            placeholder="None"
            variant={isEdit ? "outlined" : "borderless"}
            onChange={(val) => setFeeTypeValue(val)}
            style={
              isMobile
                ? {
                    width: "100%",
                  }
                : !isEdit
                ? {
                    pointerEvents: "none",
                  }
                : {}
            }
            {...{
              ...(!isEdit ? { open: false, suffixIcon: null } : {}),
            }}
          />
        )}
        {isEdit && !isMobile ? (
          <div className="flex items-center gap-1">
            <Button
              onClick={(e) => {
                e?.stopPropagation();
                handleCancel();
              }}
            >
              Cancel
            </Button>
            <Button
              type="primary"
              onClick={(e) => {
                e?.stopPropagation();
                handleSave();
              }}
            >
              Save
            </Button>
          </div>
        ) : (
          !isMobile && (
            <Tooltip title="Edit">
              <Button
                shape="circle"
                color={"primary"}
                variant={"text"}
                icon={<BiPencil />}
                onClick={() => setIsEdit(true)}
              />
            </Tooltip>
          )
        )}
      </div>
    );
  }

  if (isMobile) {
    if (feeType !== "PROGRAM") {
      return (
        <>
          {loading ? (
            <Skeleton.Node style={{ height: "20px" }} active />
          ) : (
            <Select
              value={feeTypeValue || "None"}
              options={options}
              loading={loading}
              placeholder="None"
              variant={"borderless"}
              open={false}
              suffixIcon={false}
            />
          )}
          {!isEdit && (
            <Button
              shape="circle"
              // color={"primary"}
              variant={"text"}
              icon={<BiPencil />}
              onClick={(e) => {
                e?.stopPropagation();
                setIsEdit(true);
              }}
            />
          )}
          <Drawer
            onClose={(e) => {
              e.stopPropagation();
              handleCancel();
            }}
            open={isEdit}
            placement="bottom"
            height={"45%"}
            closable={false}
            onClick={(e) => e.stopPropagation()}
            style={{
              borderTopLeftRadius:
                GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.BORDER_RADIUS,
              borderTopRightRadius:
                GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.BORDER_RADIUS,
            }}
            styles={{
              header: {
                alignItems: "center",
              },
            }}
            footer={
              <div className="flex items-center justify-center gap-2">
                <Button style={ButtonInlineStyles} block onClick={handleCancel}>
                  Cancel
                </Button>
                <Button
                  type="primary"
                  style={ButtonInlineStyles}
                  block
                  onClick={handleSave}
                  disabled={loading}
                >
                  Save
                </Button>
              </div>
            }
            title={
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Typography.Title level={5}>
                    Edit {HELPERS.capitalizeFirst(feeType)} plan
                  </Typography.Title>
                </div>
                <Button onClick={handleCancel} shape="circle">
                  <CloseOutlined />
                </Button>
              </div>
            }
          >
            {getBody()}
          </Drawer>
        </>
      );
    }
  }

  if (feeType !== "PROGRAM") {
    return getBody();
  }
  return null;
}

const FeeTables = ({
  studentFeeDetails = {},
  onUpdateFeeTables = () => {},
  mainLoader = false,
}: {
  studentFeeDetails?: StudentStateFeeTypes;
  onUpdateFeeTables?: () => void;
  mainLoader?: boolean;
}) => {
  const [enrolment, setEnrolment] = useState<EnrolmentTypes>();
  const [loading, setLoading] = useState(false);

  const { token } = theme.useToken();

  const searchParams = useSearchParams();

  const isMobile = useIsSmallDevice();

  const enrolmentId: string | null | undefined =
    searchParams.get("enrolmentId");

  async function getEnrolment(id = "") {
    try {
      setLoading(true);
      const res = await apiClient.get(`/student/enrolment/${id}`);
      setEnrolment(res?.data);
    } finally {
      setLoading(false);
    }
  }

  function handleUpdateFeeTables() {
    if (enrolmentId) {
      getEnrolment(enrolmentId);
    }
    onUpdateFeeTables();
  }

  function getAccordianItems() {
    let objMap = {};
    Object.keys(studentFeeDetails?.feeDetailsMap || {})?.forEach((key) => {
      objMap = {
        ...(objMap || {}),
        [key]: studentFeeDetails?.feeDetailsMap?.[key as FeeType],
      };
    });
    return Object.keys(objMap || {})?.map((key) => {
      const detail = objMap?.[key as keyof typeof objMap] || [];
      const feeType = key || "";
      return {
        key: key,
        label: `${HELPERS.capitalizeFirst(feeType)} Fee`,
        children: (
          <FeeTable
            feeDetail={detail}
            enrolment={enrolment}
            loading={loading}
            onUpdateFeeTables={handleUpdateFeeTables}
            mainLoader={mainLoader}
          />
        ),
        extra: (
          <EditPlanType
            feeType={feeType}
            enrolment={enrolment}
            onUpdateFeeTables={handleUpdateFeeTables}
          />
        ),
        style: {
          background: token.colorBgBase,
        },
        styles: {
          body: {
            background: token.colorGreyGlobal
          }
        },
      };
    });
  }

  useEffect(() => {
    if (enrolmentId) {
      getEnrolment(enrolmentId);
    }
  }, [enrolmentId]);

  if (isMobile) {
    return (
      <div className="mt-5">
        <Collapse
          defaultActiveKey={"PROGRAM"}
          accordion
          items={getAccordianItems()}
        />
      </div>
    );
  }

  return (
    <StyledFeeTables>
      {Object.keys(studentFeeDetails?.feeDetailsMap || {})?.map((key) => {
        const detail = studentFeeDetails?.feeDetailsMap?.[key as FeeType];
        // if (detail?.length === 0) return null;
        const feeType = key || "";
        return (
          <div className="fee-table-container" key={feeType}>
            <Typography.Title level={5}>
              {HELPERS.capitalizeFirst(feeType)} Fee
            </Typography.Title>
            <EditPlanType
              feeType={feeType}
              enrolment={enrolment}
              onUpdateFeeTables={handleUpdateFeeTables}
            />
            <div className="fee-detail-container mt-2">
              <FeeTable
                feeDetail={detail}
                enrolment={enrolment}
                loading={loading}
                onUpdateFeeTables={handleUpdateFeeTables}
                mainLoader={mainLoader}
              />
            </div>
          </div>
        );
      })}
    </StyledFeeTables>
  );
};

export default FeeTables;
