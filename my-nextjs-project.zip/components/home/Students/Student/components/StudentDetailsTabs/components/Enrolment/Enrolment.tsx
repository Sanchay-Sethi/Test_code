import { BiPencil } from "react-icons/bi";
import { StyledEnrolment } from "@/components/home/Students/styles.Students";
import apiClient from "@/lib/apiClient";
import { Button, Table } from "antd";
import { useEffect, useMemo, useState } from "react";
import { useGlobalValues } from "@/lib/hooks/useGlobalValues";
import { useNavigation } from "@/lib/context/NavigationContext";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";
import GeneralSkeleton from "@/components/reusable/Loader/Skeleton/GeneralSkeleton";
import { GENERAL_COMPONENTS } from "@/components/common";
import VirtualSwiper from "@/components/reusable/Swiper/virtual/VirtualVerticalSwiper";
import { EnrolmentCard } from "@/components/reusable/cards/GeneralCards";

const Enrolment = ({ id = "" }: { id: string }) => {
  const [enrolmentTable, setEnrolmentTable] = useState<EnrolmentTypes[]>([]);
  const [loading, setLoading] = useState(false);
  
  const isMobile = useIsSmallDevice();

  const { CURRENT_ACADEMIC_YEAR } = useGlobalValues();

  const {navigate} = useNavigation();

  async function getEnrolmentList() {
    try {
      setLoading(true);
      const res = await apiClient.get(`/student/enrolment/list/${id}`);
      setEnrolmentTable(res?.data || []);
    } finally {
      setLoading(false);
    }
  }

  function handleEdit(enrolmentId: string) {
    navigate(`/students/student/${id}?mode=FEES&enrolmentId=${enrolmentId}`)
  }

  useEffect(() => {
    getEnrolmentList();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const columns = useMemo(() => {
    return [
      {
        key: "className",
        title: "Class name",
        dataIndex: "className",
        ellipsis: true,
      },
      {
        key: "academicYearName",
        title: "Academic year",
        dataIndex: "academicYearName",
        ellipsis: true,
      },
      {
        key: "Edit",
        title: "",
        dataIndex: "id",
        ellipsis: true,
        render: (id: string, data: EnrolmentTypes) => {
          if (CURRENT_ACADEMIC_YEAR !== data?.academicYearId) return null;
          return (
            <Button
              color="primary"
              variant="filled"
              onClick={() => handleEdit(id)}
              icon={<BiPencil />}
            >
              Edit
            </Button>
          );
        },
      },
    ];
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [enrolmentTable]);

  if (isMobile) {
    return (
      <>
        {loading ? (
          <GeneralSkeleton
            countSmall={0}
            countLarge={10}
            isLargeWrapped
            largeBoxHeight={100}
          />
        ) : enrolmentTable?.length === 0 && !loading ? (
          <GENERAL_COMPONENTS.NoResult />
        ) : (
          <VirtualSwiper
            items={enrolmentTable}
            getKey={(data) => data?.id || ""}
            containerHeight="calc(100vh - 184px)"
            cardEstimateWidth={125}
            renderItem={(data) => (
              <EnrolmentCard
                data={data}
                onEdit={() => handleEdit(data?.id || "")}
                editShown={CURRENT_ACADEMIC_YEAR === data?.academicYearId}
              />
            )}
          />
        )}
      </>
    );
  }

  return (
    <StyledEnrolment>
      <Table
        dataSource={enrolmentTable}
        columns={columns}
        loading={loading}
        scroll={{ y: 100 * 5 }}
      />
    </StyledEnrolment>
  );
};

export default Enrolment;
