import { FEE_ICON } from "@/components/home/Students/Icons";
import { StyledFeeView } from "@/components/home/Students/styles.Students";
import apiClient from "@/lib/apiClient";
import { Select, Skeleton, theme, Typography } from "antd";
import { useEffect, useState } from "react";
import { getStudentFeeDetails } from "../../../../Helpers.Student";
import FeeTables from "./FeeTables";
import Navbar from "../../../Navbar";
import { StyledMobileSpacedContainer } from "@/components/common/styles.common";

interface AcademicYearListTypes {
  label?: string;
  value?: string;
}

const FeeView = ({
  id = "",
  enrolmentId = "",
  studentName = "",
  admissionNumber = "",
}: {
  id?: string;
  enrolmentId?: string;
  studentName?: string;
  admissionNumber?: string;
}) => {
  const [academicYear, setAcademicYear] = useState("");
  const [loading, setLoading] = useState(false);
  const [studentFeeDetails, setStudentFeeDetails] =
    useState<StudentStateFeeTypes>();
  const [academicYearList, setAcademicYearList] =
    useState<AcademicYearListTypes[]>();

  const { token } = theme.useToken();

  async function getFeeDetails(selectedYear = "") {
    try {
      let currentAcademicYear;
      setLoading(true);
      if (!selectedYear) {
        currentAcademicYear = await apiClient.get("/ay");
      }
      const studentFee = await apiClient.get(
        `/fee/calc/student/${
          selectedYear || currentAcademicYear?.data?.id
        }/${id}`
      );
      setStudentFeeDetails(getStudentFeeDetails(studentFee?.data));
      if (!selectedYear) {
        const academicYearList = await apiClient.get("/ay/list");
        const academicYearOptions = academicYearList?.data?.map(
          (data: { name?: string; id?: string }) => {
            return {
              label: data?.name,
              value: data?.id,
            };
          }
        );
        setAcademicYearList(academicYearOptions);
      }
      setAcademicYear(selectedYear || currentAcademicYear?.data?.id);
      setLoading(false);
    } finally {
      setLoading(false);
    }
  }

  function handleAcadmicYearChange(id = "") {
    getFeeDetails(id);
  }

  useEffect(() => {
    getFeeDetails();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <StyledFeeView token={token}>
      <Navbar
        id={id}
        name={studentName || ""}
        mode="FEES"
        admissionId={admissionNumber}
        backUrl={`/students/student/${id}?mode=ENROLMENT`}
      />
      <StyledMobileSpacedContainer>
        <div className="fee-title-container">
          <div className="total-fee-container">
            <p className="fee-title">
              <FEE_ICON /> TOTAL ANNUAL FEE
            </p>
            <p className="fee-dues">
              {loading ? (
                <Skeleton.Node style={{ height: "20px" }} active />
              ) : (
                `Rs ${studentFeeDetails?.totalDues?.toLocaleString()}`
              )}
            </p>
          </div>
          {!enrolmentId && (
            <div className="acedemic-year-container">
              <Typography.Paragraph>Academic year</Typography.Paragraph>
              <Select
                style={{ width: 120 }}
                value={academicYear}
                onChange={handleAcadmicYearChange}
                options={academicYearList}
              />
            </div>
          )}
        </div>
        <div className="fee-container-view">
          <FeeTables
            studentFeeDetails={studentFeeDetails}
            onUpdateFeeTables={getFeeDetails}
            mainLoader={loading}
          />
        </div>
      </StyledMobileSpacedContainer>
    </StyledFeeView>
  );
};

export default FeeView;
