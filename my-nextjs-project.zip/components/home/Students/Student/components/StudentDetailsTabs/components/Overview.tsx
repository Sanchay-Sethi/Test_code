"use client";

import { Divider, Image, Tag, theme, Typography } from "antd";
import { GENERAL_COMPONENTS } from "@/components/common";
import { GLOBAL_CONSTANTS } from "@/constants";
import {
  StyledOverview,
  StyledStudentDetails,
} from "@/components/home/Students/styles.Students";
import {
  BRANCH_ICON,
  CLASS_ICON,
  DATE_ICON,
  FEMALE_ICON,
  MALE_ICON,
  NAME_ICON,
  OTHER_GENDER_ICON,
} from "@/components/home/Students/Icons";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";

const Overview = ({
  details = {
    profile: {},
    enrolment: {},
  },
  profileImage = "",
  alterHeight = "",
}: {
  details?: StudentDetailsTypes;
  profileImage?: string;
  alterHeight?: string;
}) => {
  const { token } = theme.useToken();

  const isMobile = useIsSmallDevice();

  return (
    <StyledStudentDetails alterHeight = {alterHeight}>
      <StyledOverview token={token}>
        <div className="basic-information-wrapper">
          <div className="overview-card">
            <div className="image-container">
              <div className="student-status">
                <Tag
                  color={
                    GLOBAL_CONSTANTS?.TAG_STATUS_COLOR?.[
                      (details?.profile?.status as keyof typeof GLOBAL_CONSTANTS.TAG_STATUS_COLOR) ||
                        "ACTIVE"
                    ]
                  }
                  key={details?.profile?.status}
                >
                  {details?.profile?.status}
                </Tag>
              </div>
              {profileImage ? (
                <Image
                  width={120}
                  height={120}
                  src={profileImage}
                  alt="Profile Picture"
                  style={{ borderRadius: "50%", objectFit: "cover" }}
                />
              ) : (
                <GENERAL_COMPONENTS.ImagePlaceholder />
              )}
            </div>
            <Divider style={{ margin: 0 }} />
            <div className="overview-details">
              <p className="information-title">BASIC INFORMATION</p>
              <div className="basic-information">
                <div className="information-student">
                  <div className="icon-container-student">
                    <NAME_ICON />
                  </div>
                  <Typography.Paragraph>{details?.profile?.name}</Typography.Paragraph>
                </div>
                <div className="information-student">
                  <div className="icon-container-student">
                    {details?.profile?.gender === "MALE" ? (
                      <MALE_ICON />
                    ) : details?.profile?.gender === "FEMALE" ? (
                      <FEMALE_ICON />
                    ) : (
                      <OTHER_GENDER_ICON />
                    )}
                  </div>
                  <Typography.Paragraph>
                    {details?.profile?.gender || <span>Not added</span>}
                  </Typography.Paragraph>
                </div>
                <div className="information-student">
                  <div className="icon-container-student">
                    <DATE_ICON />
                  </div>
                  <Typography.Paragraph>
                    {details?.profile?.admissionYear || <span>Not added</span>}{" "}
                    <span>(Admission year)</span>
                  </Typography.Paragraph>
                </div>
                <div className="information-student">
                  <div className="icon-container-student">
                    <BRANCH_ICON />
                  </div>
                  <Typography.Paragraph>
                    {details?.branchName || <span>No branch added</span>}
                  </Typography.Paragraph>
                </div>
                <div className="information-student">
                  <div className="icon-container-student">
                    <CLASS_ICON />
                  </div>
                  <Typography.Paragraph>
                    {details?.className || <span>No class added</span>}{" "}
                    <span>(Class name)</span>
                  </Typography.Paragraph>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="personal-information-wrapper">
          <div className="overview-card flex-1/2">
            <div className="overview-details">
              <p className="information-title">PERSONAL INFORMATION</p>
              <div className="basic-information">
                <div className="personal-information-content">
                  <div className="info-title">
                    <p className="information-title">Date of birth</p>
                  </div>
                  <div className="info-desc">
                    <Typography.Paragraph>
                      {details?.profile?.dateOfBirth || <span>Not added</span>}
                    </Typography.Paragraph>
                  </div>
                </div>
                <div className="personal-information-content">
                  <div className="info-title">
                    <p className="information-title">Father&apos;s name</p>
                  </div>
                  <div className="info-desc">
                    <Typography.Paragraph>
                      {details?.profile?.fatherName || <span>Not added</span>}
                    </Typography.Paragraph>
                  </div>
                </div>
                <div className="personal-information-content">
                  <div className="info-title">
                    <p className="information-title">Mother&apos;s name</p>
                  </div>
                  <div className="info-desc">
                    <Typography.Paragraph>
                      {details?.profile?.motherName || <span>Not added</span>}
                    </Typography.Paragraph>
                  </div>
                </div>
                <div className="personal-information-content">
                  <div className="info-title">
                    <p className="information-title">Address</p>
                  </div>
                  <div className="info-desc">
                    <Typography.Paragraph>
                      {details?.profile?.address || <span>Not added</span>}
                    </Typography.Paragraph>
                  </div>
                </div>
              </div>
            </div>
            <Divider style={{ margin: 0 }} />
            <div className="overview-details">
              <p className="information-title">COMMUNICATION</p>
              <div className="basic-information">
                <div className="personal-information-content">
                  <div className="info-title">
                    <p className="information-title">Primary phone</p>
                  </div>
                  <div className="info-desc">
                    <Typography.Paragraph>
                      {details?.profile?.phoneNumber || <span>Not added</span>}
                    </Typography.Paragraph>
                  </div>
                </div>
                <div className="personal-information-content">
                  <div className="info-title">
                    <p className="information-title">Secondary phone</p>
                  </div>
                  <div className="info-desc">
                    <Typography.Paragraph>
                      {details?.profile?.secondaryPhoneNumber || <span>Not added</span>}
                    </Typography.Paragraph>
                  </div>
                </div>
                <div className="personal-information-content">
                  <div className="info-title">
                    <p className="information-title">Email</p>
                  </div>
                  <div className="info-desc">
                    <Typography.Paragraph>
                      {details?.profile?.email || <span>Not added</span>}
                    </Typography.Paragraph>
                  </div>
                </div>
              </div>
            </div>
          </div>
          {
            isMobile &&
            <div className="w-full h-[60px]">
            </div>
          }
        </div>
      </StyledOverview>
    </StyledStudentDetails>
  );
};

export default Overview;
