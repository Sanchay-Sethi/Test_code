"use client";

import { Tabs, theme } from "antd";
import { StyledStudentDetailsTabs } from "../../../styles.Students";
import { useEffect, useMemo, useState } from "react";
import { useSearchParams } from "next/navigation";
import Overview from "./components/Overview";
// import UnderConstructionPage from "@/components/reusable/StaticMessages/UnderConstructionPage";
import { useNavigation } from "@/lib/context/NavigationContext";
import Enrolment from "./components/Enrolment/Enrolment";

const TAB_KEYS = ["OVERVIEW", "FEES", "STATEMENT", "ENROLMENT"];

const StudentDetailsTabs = ({
  details = {
    profile: {},
    enrolment: {},
  },
  profileImage = "",
}: {
  details?: StudentDetailsTypes;
  profileImage?: string;
}) => {
  const searchParams = useSearchParams();
  const { navigate } = useNavigation();
  const { token } = theme.useToken();

  const mode = searchParams.get("mode");

  const [activeTab, setActiveTab] = useState("OVERVIEW");

  useEffect(() => {
    if (mode && TAB_KEYS?.includes(mode)) {
      setActiveTab(mode);
    } else {
      setActiveTab("OVERVIEW");
    }
  }, [mode]);

  const handleTabChange = (key: string) => {
    setActiveTab(key);
    const params = new URLSearchParams(searchParams.toString());
    if (key === "OVERVIEW") {
      params.delete("mode");
    } else {
      params.set("mode", key?.trim());
    }
    navigate(`?${params.toString()}`);
  };

  console.log({
    details
  })

  const items = useMemo(
    () => [
      {
        key: "OVERVIEW",
        label: "Overview",
        children: <Overview details={details} profileImage={profileImage} />,
      },
      {
        key: "ENROLMENT",
        label: "Enrolments",
        children: <Enrolment id={details?.profile?.id || ""} />,
      },
      // {
      //   key: "STATEMENT",
      //   label: "Statement",
      //   children: <UnderConstructionPage />,
      // },
      // {
      //   key: "ENROLMENT",
      //   label: "Enrolment history",
      //   children: <UnderConstructionPage />,
      // },
    ],
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [details]
  );

  return (
    <StyledStudentDetailsTabs token = {token}>
      <Tabs activeKey={activeTab} items={items} onChange={handleTabChange} />
    </StyledStudentDetailsTabs>
  );
};

export default StudentDetailsTabs;
