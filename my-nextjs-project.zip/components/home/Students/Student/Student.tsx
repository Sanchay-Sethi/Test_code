"use client";

import { useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import StudentForm from "./StudentForm";
import apiClient from "@/lib/apiClient";
import Navbar from "./components/Navbar";
import { StyledStudent } from "../styles.Students";
import StudentDetailsTabs from "./components/StudentDetailsTabs/StudentDetailsTabs";
import { usePreviousUrl } from "@/lib/hooks/usePreviousUrl";
import EmptyStudents from "./components/EmptyStudents";
import GeneralSkeleton from "@/components/reusable/Loader/Skeleton/GeneralSkeleton";
import { StyledMobileSpacedContainer } from "@/components/common/styles.common";
import FeeView from "./components/StudentDetailsTabs/components/FeeView/FeeView";

const Student = ({ id }: { id?: string }) => {
  const [details, setDetails] = useState<StudentDetailsTypes>({
    profile: {},
    enrolment: {},
  });
  const [loading, setLoading] = useState(false);
  const [profileImage, setProfileImage] = useState("");

  const searchParams = useSearchParams();
  const previousUrl = usePreviousUrl();

  const mode: string | null | undefined = searchParams.get("mode");
  const enrolmentId: string | null | undefined =
    searchParams.get("enrolmentId");

  async function getStudentDetails() {
    if (id) {
      try {
        setLoading(true);
        const res = await apiClient.get(`/student/${id}`);
        setDetails(res?.data || {});
        if (res?.data?.profile?.id) {
          const imgRes = await apiClient.get(
            `/student/photo/${res?.data?.profile?.id}`,
            {
              responseType: "blob",
            }
          );
          if (imgRes?.status === 204 && imgRes?.statusText === "No Content") {
            setProfileImage("");
          } else {
            const url = URL.createObjectURL(imgRes?.data);
            setProfileImage(url);
          }
        }
      } finally {
        setLoading(false);
      }
    }
  }

  function getComponent() {
    if (loading === true) {
      return (
        <StyledMobileSpacedContainer>
          <GeneralSkeleton countSmall={2} countLarge={3} isLargeWrapped />;
        </StyledMobileSpacedContainer>
      );
    }
    if (Object.keys(details)?.length === 0) {
      return (
        <StyledMobileSpacedContainer>
          <EmptyStudents id={id} />;
        </StyledMobileSpacedContainer>
      );
    }
    return (
      <>
        <Navbar
          id={id}
          name={details?.profile?.name || ""}
          admissionId={details?.profile?.admissionNumber || ""}
          mode={mode}
          backUrl={"/students"}
        />
        <StudentDetailsTabs details={details} profileImage={profileImage} />
      </>
    );
  }

  useEffect(() => {
    getStudentDetails();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (previousUrl?.includes("EDIT_STUDENT")) {
      getStudentDetails();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [previousUrl]);

  if (mode === "EDIT_STUDENT" && id) {
    return <StudentForm id={id} mode={mode} />;
  }

  if (mode === "FEES" && enrolmentId && id) {
    return (
      <FeeView
        id={id || ""}
        enrolmentId={enrolmentId}
        studentName={details?.profile?.name}
        admissionNumber={details?.profile?.admissionNumber}
      />
    );
  }

  return <StyledStudent>{getComponent()}</StyledStudent>;
};

export default Student;
