"use client";

import Navbar from "./components/Navbar";
import StudentDetailsForm from "./components/StudentDetailsForm";
import { StyledStudentForm } from "../styles.Students";
import { useEffect, useState } from "react";
import apiClient from "@/lib/apiClient";
import EmptyStudents from "./components/EmptyStudents";
import GeneralSkeleton from "@/components/reusable/Loader/Skeleton/GeneralSkeleton";
import { StyledMobileSpacedContainer } from "@/components/common/styles.common";

const StudentForm = ({ id, mode }: { id?: string; mode?: string }) => {
  const [details, setDetails] = useState<StudentDetailsTypes>({
    profile: {},
    enrolment: {},
  });
  const [loading, setLoading] = useState(false);

  async function getStudentDetails() {
    if (id) {
      try {
        setLoading(true);
        const res = await apiClient.get(`/student/${id}`);
        setDetails(res?.data || {});
      } finally {
        setLoading(false);
      }
    }
  }

  function getComponent() {
    if (loading === true) {
      return <StyledMobileSpacedContainer><GeneralSkeleton countSmall={2} countLarge={3}/></StyledMobileSpacedContainer>;
    }
    if (mode === "EDIT_STUDENT" && Object.keys(details)?.length === 0) {
      return <StyledMobileSpacedContainer><EmptyStudents id={id} /></StyledMobileSpacedContainer>;
    }
    return (
      <>
        <Navbar
          id={id}
          name={details?.profile?.name || ""}
          mode={mode}
          backUrl={
            !mode && !id ? "/students" : `/students/student/${id}`
          }
        />
        <StudentDetailsForm
          mode={mode}
          details={details}
          callBack={getStudentDetails}
        />
      </>
    );
  }

  useEffect(() => {
    getStudentDetails();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return <StyledStudentForm>{getComponent()}</StyledStudentForm>;
};

export default StudentForm;
