"use client";

import dayjs from 'dayjs';
import weekday from 'dayjs/plugin/weekday';
import localeData from 'dayjs/plugin/localeData';
import apiClient from '@/lib/apiClient';

dayjs.extend(weekday);
dayjs.extend(localeData);

export const getPayload = (values: StudentDetailsInitialTypes, details: StudentDetailsTypes) => {
    let profile = {
        branchId: values?.branchId,
        status: values?.status,
        name: values?.name,
        phoneNumber: values?.phoneNumber,
        secondaryPhoneNumber: values?.secondaryPhoneNumber,
        email: values?.email,
        dateOfBirth: values?.dateOfBirth && dayjs(values?.dateOfBirth)?.format('YYYY-MM-DD'),
        gender: values?.gender,
        admissionNumber: values?.admissionNumber,
        admissionYear: values?.admissionYear ? dayjs(values?.admissionYear)?.year()?.toString() : undefined,
        address: values?.address,
        fatherName: values?.fatherName,
        motherName: values?.motherName,
    }

    let enrolment = {
        classId: values?.classId,
        transportPlanId: values?.transportPlanId,
        hostelPlanId: values?.hostelPlanId,
    }

    if (!!details && Object.keys(details?.profile)?.length !== 0) {
        profile = {
            ...(details?.profile || {}),
            ...(profile || {}),
        }
    }

    if (!!details && Object.keys(details?.enrolment)?.length !== 0) {
        enrolment = {
            ...(details?.enrolment || {}),
            ...(enrolment || {}),
        }
    }

    return {
        profile, enrolment
    }
}

export const getInitialValues = (details: StudentDetailsTypes = {
    profile: {},
    enrolment: {},
}) => {
    return {
        branchId: details?.profile?.branchId,
        status: details?.profile?.status,
        name: details?.profile?.name,
        phoneNumber: details?.profile?.phoneNumber,
        secondaryPhoneNumber: details?.profile?.secondaryPhoneNumber,
        email: details?.profile?.email,
        dateOfBirth: details?.profile?.dateOfBirth && dayjs(details?.profile?.dateOfBirth),
        gender: details?.profile?.gender,
        admissionNumber: details?.profile?.admissionNumber,
        admissionYear: details?.profile?.admissionYear && dayjs(details?.profile?.admissionYear, 'YYYY'),
        address: details?.profile?.address,
        fatherName: details?.profile?.fatherName,
        motherName: details?.profile?.motherName,
        classId: details?.enrolment?.classId,
        transportPlanId: details?.enrolment?.transportPlanId,
        hostelPlanId: details?.enrolment?.hostelPlanId,
    }
}

export async function getRequiredFormOptions() {
    try {
        const [branchRes, transportPlanRes, hostelPlanRes, classRes] = await Promise.all([
            apiClient.get("/org/branch/listbyid"),
            apiClient.get("/fee/plan?feeType=TRANSPORT"),
            apiClient.get("/fee/plan?feeType=HOSTEL"),
            apiClient.get("/program/class"),
        ]);

        const branchResponse = Object.keys(branchRes?.data || {})?.map((key) => ({
            label: branchRes?.data?.[key].name,
            value: branchRes?.data?.[key].id,
        }));
        const transportPlanResponse = transportPlanRes?.data?.map((val: { name: string; id: string; }) => ({
            label: val?.name,
            value: val?.id,
        }));
        const hostelPlanResResponse = hostelPlanRes?.data?.map((val: { name: string; id: string; }) => ({
            label: val?.name,
            value: val?.id,
        }));
        const classResResponse = classRes?.data?.map((val: { programName: string; sectionName: string; id: string; }) => ({
            label: `${val?.programName} ${val?.sectionName}`,
            value: val?.id,
        }));

        return {
            branch: branchResponse || [],
            transport: transportPlanResponse || [],
            hostel: hostelPlanResResponse || [],
            classOption: classResResponse || [],
        }

    } catch (error) {
        throw error;
    }
}

export const decodeImageStringToBlob = (str: string, mimeType = 'image/jpeg') => {
    const byteNumbers = new Array(str.length);
    for (let i = 0; i < str.length; i++) {
        byteNumbers[i] = str.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);
    return new Blob([byteArray], { type: mimeType });
};

export function getStudentFeeDetails(studentFee: StudentFeeTypes) {
    const feeDetailsMap: Partial<Record<FeeType, StudentFeeLineItemTypes[]>> = {
        PROGRAM: [],
        // ADMISSION: [],
        TRANSPORT: [],
        HOSTEL: [],
    };
    (studentFee?.items || [])?.forEach((item) => {
        if (item?.type) {
            feeDetailsMap?.[item?.type as keyof typeof feeDetailsMap]?.push(item);
        }
    });
    return {
        feeDetailsMap,
        totalDues: studentFee?.totalDues,
    }
}