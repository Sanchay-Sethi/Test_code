"use client";

import { useEffect, useState } from "react";
import { StyledAcademicYear } from "./Styles.AcademicYear";
import Navbar from "./components/Navbar";
import AcademicYearListingTable from "./components/AcademicYearListingTable";
import apiClient from "@/lib/apiClient";
import { useGlobalContext } from "@/lib/context/GlobalContext";

const AcademicYear = () => {
  const { updateAcademicYearList } = useGlobalContext();

  const [academicYearList, setAcademicYearList] =
    useState<AcademicYearProps[]>();
  const [loading, setLoading] = useState(false);
  const [nextAy, setNextAy] = useState("");

  async function getAcademicYearList() {
    try {
      setLoading(true);
      const res = await apiClient.get("/ay/list");
      const resNextAy = await apiClient.get("/ay/next");
      setAcademicYearList(res?.data);
      setNextAy(resNextAy?.data);
      updateAcademicYearList(res?.data);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    getAcademicYearList();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <StyledAcademicYear>
      <Navbar getAcademicYearList={getAcademicYearList} nextAy={nextAy} />
      <AcademicYearListingTable
        loading={loading}
        getAcademicYearList={getAcademicYearList}
        academicYearList={academicYearList || []}
      />
    </StyledAcademicYear>
  );
};

export default AcademicYear;
