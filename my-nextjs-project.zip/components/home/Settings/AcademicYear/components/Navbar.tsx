"use client";

import { useState } from "react";
import { Alert, Button, Drawer, Input, theme, Typography } from "antd";
import { AiOutlinePlus } from "react-icons/ai";
import { StyledAcademicYearModal, StyledNavbar } from "../Styles.AcademicYear";
import GeneralModal from "@/components/reusable/Modal/GeneralModal/Modal";
import { CALENDER_ICON } from "../Icons.AcademicYear";
import HELPERS from "@/lib/helpers";
import apiClient from "@/lib/apiClient";
import { SideMenuIcons } from "@/components/home/Sidebar/Icons";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";
import { GLOBAL_CONSTANTS } from "@/constants";
import { ButtonInlineStyles } from "@/components/common/styles.common";
import { CloseOutlined } from "@ant-design/icons";

const Navbar = ({
  nextAy = "",
  getAcademicYearList = () => {},
}: {
  nextAy?: string;
  getAcademicYearList?: () => void;
}) => {
  const { token } = theme.useToken();
  const [loading, setLoading] = useState(false);
  const [openModal, setOpenModal] = useState(false);

  const isMobile = useIsSmallDevice();

  function handleCancel() {
    setOpenModal(false);
  }

  async function handleCreate() {
    try {
      setLoading(true);
      await apiClient.post("/ay");
      HELPERS.messageAlert({ success: "Added Successfully" });
      setOpenModal(false);
      getAcademicYearList();
    } finally {
      setLoading(false);
    }
  }

  return (
    <StyledNavbar token={token}>
      <div className="flex-col gap-1.5">
        <div className="flex items-center gap-1.5">
          {SideMenuIcons.SETTINGS()}
          <Typography.Paragraph>Settings</Typography.Paragraph>
        </div>
        <Typography.Title level={isMobile ? 5 : 3}>
          Academic years
        </Typography.Title>
      </div>
      <Button
        type="primary"
        icon={<AiOutlinePlus />}
        onClick={() => setOpenModal(true)}
      >
        Add
      </Button>
      {isMobile ? (
        <Drawer
          onClose={handleCancel}
          open={openModal}
          placement="bottom"
          height={"55%"}
          closable={false}
          style={{
            borderTopLeftRadius:
              GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.BORDER_RADIUS,
            borderTopRightRadius:
              GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.BORDER_RADIUS,
          }}
          footer={
            <div className="flex items-center justify-center gap-2">
              <Button style={ButtonInlineStyles} block onClick={handleCancel}>
                Cancel
              </Button>
              <Button
                type="primary"
                style={ButtonInlineStyles}
                block
                onClick={handleCreate}
                disabled={loading}
              >
                Create
              </Button>
            </div>
          }
          title={
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <CALENDER_ICON />
                <Typography.Title level={5}>New academic year</Typography.Title>
              </div>
              <Button onClick={handleCancel} shape="circle">
                <CloseOutlined />
              </Button>
            </div>
          }
        >
          <StyledAcademicYearModal>
            <div className="academic-year-modal-inputs">
              <Typography.Text className="modal-academic-title" ellipsis>
                Period
              </Typography.Text>
              <Input value={nextAy} readOnly />
            </div>
            <Alert
              description="Adding an academic year, will clone fee structure from the current academic year. You will be able to modify it in the Fee Structure menu later."
              type="info"
              showIcon
            />
          </StyledAcademicYearModal>
        </Drawer>
      ) : (
        <GeneralModal
          open={openModal}
          onCancel={handleCancel}
          customTitle="New academic year"
          titleIcon={<CALENDER_ICON />}
          footer={[
            <Button key="cancel" onClick={handleCancel}>
              Cancel
            </Button>,
            <Button
              type="primary"
              key="create"
              onClick={handleCreate}
              disabled={loading}
            >
              Create
            </Button>,
          ]}
        >
          <StyledAcademicYearModal>
            <div className="academic-year-modal-inputs">
              <Typography.Text className="modal-academic-title" ellipsis>
                Period
              </Typography.Text>
              <Input value={nextAy} readOnly />
            </div>
            <Alert
              description="Adding an academic year, will clone fee structure from the current academic year. You will be able to modify it in the Fee Structure menu later."
              type="info"
              showIcon
            />
          </StyledAcademicYearModal>
        </GeneralModal>
      )}
    </StyledNavbar>
  );
};

export default Navbar;
