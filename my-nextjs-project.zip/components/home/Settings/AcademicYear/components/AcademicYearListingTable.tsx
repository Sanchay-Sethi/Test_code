import { useMemo, useState } from "react";
import { Button, Table, Tag, theme } from "antd";
import { GLOBAL_CONSTANTS } from "@/constants";
import { StyledAcademicYearListingTable } from "../Styles.AcademicYear";
import apiClient from "@/lib/apiClient";
import HELPERS from "@/lib/helpers";
import { useGlobalContext } from "@/lib/context/GlobalContext";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";
import { StyledMobileSpacedContainer } from "@/components/common/styles.common";
import GeneralSkeleton from "@/components/reusable/Loader/Skeleton/GeneralSkeleton";
import { GENERAL_COMPONENTS } from "@/components/common";
import VirtualSwiper from "@/components/reusable/Swiper/virtual/VirtualVerticalSwiper";
import { AcademicYearCard } from "@/components/reusable/cards/GeneralCards";

const AcademicYearListingTable = ({
  loading = false,
  academicYearList = [],
  getAcademicYearList = () => {},
}: {
  loading?: boolean;
  academicYearList?: AcademicYearProps[];
  getAcademicYearList?: () => void;
}) => {
  const { token } = theme.useToken();
  const { updateCurrentAcademicYear } = useGlobalContext();

  const isMobile = useIsSmallDevice();

  const [buttonDisabled, setButtonDisabled] = useState(false);

  async function handleMakeCurrent(id = "") {
    try {
      setButtonDisabled(true);
      await apiClient.put(`/ay/current/${id}`);
      updateCurrentAcademicYear(id);
      HELPERS.messageAlert({ success: "Academic year added as current" });
      getAcademicYearList();
    } finally {
      setButtonDisabled(false);
    }
  }

  const columns = useMemo(
    () => [
      {
        title: "Name",
        dataIndex: "name",
        ellipsis: true,
      },
      {
        title: "State",
        dataIndex: "state",
        ellipsis: true,
        render: (state: null | undefined) => {
          return (
            <Tag
              color={
                GLOBAL_CONSTANTS?.ACADEMIC_YEAR_STATE_COLOR?.[
                  state || "CURRENT"
                ]
              }
              key={state}
            >
              {GLOBAL_CONSTANTS?.ACADEMIC_YEAR_STATE?.[state || "CURRENT"]}
            </Tag>
          );
        },
      },
      {
        title: "Program",
        dataIndex: "state",
        ellipsis: true,
        fixed: "right",
        render: (
          state: string,
          e: {
            id: string;
            state: string;
          }
        ) => {
          const id = e?.id;
          const columnState = e?.state;
          if (columnState === "CURRENT") return null;
          return (
            <Button
              onClick={() => handleMakeCurrent(id)}
              color="primary"
              variant="filled"
              disabled={buttonDisabled}
            >
              Make current
            </Button>
          );
        },
      },
    ],
    // eslint-disable-next-line react-hooks/exhaustive-deps
    []
  );

  if (isMobile) {
    return (
      <StyledMobileSpacedContainer>
        {loading ? (
          <GeneralSkeleton
            countSmall={0}
            countLarge={10}
            isLargeWrapped
            largeBoxHeight={100}
          />
        ) : academicYearList?.length === 0 && !loading ? (
          <GENERAL_COMPONENTS.NoResult />
        ) : (
          <VirtualSwiper
            items={academicYearList as { id: string; state: string }[]}
            getKey={(data) => data?.id}
            containerHeight="calc(100vh - 130px)"
            cardEstimateWidth={60}
            renderItem={(data) => (
              <AcademicYearCard data={data} onMakeCurrent={() => handleMakeCurrent(data?.id)} />
            )}
          />
        )}
      </StyledMobileSpacedContainer>
    );
  }

  return (
    <StyledAcademicYearListingTable token={token}>
      <Table
        dataSource={academicYearList as { id: string; state: string }[]}
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-expect-error
        columns={columns}
        loading={loading}
        scroll={{ x: "max-content", y: 100 * 5 }}
        sticky={true}
        tableLayout={"fixed"}
      />
    </StyledAcademicYearListingTable>
  );
};

export default AcademicYearListingTable;
