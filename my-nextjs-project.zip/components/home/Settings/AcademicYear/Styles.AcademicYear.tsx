"use client";

import { commonContainerMobileExtraStyles, mobileNavbarExtraStyles } from "@/components/common/styles.common";
import { StyledContextProps } from "@/types";
import styled from "styled-components";

export const StyledAcademicYear = styled.div`
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 20px;
  ${commonContainerMobileExtraStyles};
`;

export const StyledNavbar = styled.div<StyledContextProps>`
  display: flex;
  justify-content: space-between;
  flex-wrap: wrap;
  gap: 20px;
  ${mobileNavbarExtraStyles}
`;

export const StyledAcademicYearModal = styled.div`
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 12px;

  .academic-year-modal-inputs {
    display: flex;
    align-items: center;

    .modal-academic-title {
      white-space: nowrap;
      width: 100px;
      font-weight: 600;
    }
  }
`;

export const StyledAcademicYearListingTable = styled.div<StyledContextProps>`
  width: 100%;
  height: calc(100vh - 130px);
  overflow: auto;

  .ant-table-thead > tr > th {
    background: transparent;
    font-weight: 600;
    text-transform: uppercase;
  }

  .ant-table-tbody > tr > td,
  .ant-table-wrapper tfoot > tr > td {
    padding: 10px 16px;
  }

  .ant-pagination {
    position: sticky;
    bottom: 0px;
    background-color: ${({ token }) => token?.colorBgBase};
    padding: 12px 20px;
    margin: 0px;
    z-index: 10;
  }
`;
