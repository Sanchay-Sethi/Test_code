interface AcademicYearProps {
    id?: string,
    name?: string,
    state?: string,
    createdAt?: string,
    updatedAt?: string,
}