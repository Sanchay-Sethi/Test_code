"use client";

import { GLOBAL_CONSTANTS } from "@/constants";
import styled from "styled-components";

export const StyledPaymentGateway = styled.div`
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 20px;

  .payment-gateway {
    padding: 40px 0;
  }

  .details-form {
    padding: 20px 0;
    width: 50%;
  }

  @media (max-width: ${GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.RESPONSIVE_WIDTH}px) {

    .payment-gateway {
      padding: 20px 0 20px 0;
    }

    .details-form {
      width: 100%;
    }
  }
`;
