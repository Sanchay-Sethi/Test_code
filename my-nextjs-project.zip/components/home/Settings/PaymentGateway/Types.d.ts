interface PaymentGatewayProps {
    id?: string;
    keyId?: string;
    secret?: string;
}