"use client";

import { theme, Typography } from "antd";
import { SideMenuIcons } from "@/components/home/Sidebar/Icons";
import { StyledNavbar } from "../../Program/Styles.Program";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";

const Navbar = () => {

  const  { token } = theme.useToken();
  const isMobile = useIsSmallDevice();

  return (
    <StyledNavbar token = {token}>
      <div className={isMobile ? "flex-col gap-1.5" : "flex-col gap-1.5"}>
        <div className="flex items-center gap-1.5">
          {SideMenuIcons.SETTINGS()}
          <Typography.Paragraph>Settings</Typography.Paragraph>
        </div>
        <Typography.Title level={isMobile ? 5 : 2}>Payment gateway</Typography.Title>
      </div>
    </StyledNavbar>
  );
};

export default Navbar;