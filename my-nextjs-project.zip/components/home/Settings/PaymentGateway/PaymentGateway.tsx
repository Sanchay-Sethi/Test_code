"use client";

import { Button, Form, Input, theme, Typography } from "antd";
import Navbar from "./components/Navbar";
import { StyledPaymentGateway } from "./Styles.PaymentGateway";
import { useEffect, useState } from "react";
import { EyeInvisibleOutlined, EyeTwoTone } from "@ant-design/icons";
import apiClient from "@/lib/apiClient";
import HELPERS from "@/lib/helpers";
import { StyledMobileSpacedFancyContainer } from "@/components/common/styles.common";

const PaymentGateway = () => {
  const [loading, setLoading] = useState(false);
  const [isChanged, setIsChanged] = useState(false);
  const [details, setDetails] = useState<PaymentGatewayProps>({});

  const { token } = theme.useToken();

  function handleChange(val = "", key = "") {
    setIsChanged(true);
    setDetails((prev) => {
      return {
        ...(prev || {}),
        [key]: val,
      };
    });
  }

  async function getDetails() {
    try {
      setLoading(true);
      const res = await apiClient.get("/pg/setting");
      setDetails(res?.data);
    } finally {
      setLoading(false);
    }
  }

  async function handleUpdate() {
    if (!details?.keyId) {
      return HELPERS.messageAlert({ error: "Please provide key id" });
    }

    if (!details?.secret) {
      return HELPERS.messageAlert({ error: "Please provide secret" });
    }

    try {
      setLoading(true);
      const res = await apiClient.put("/pg/setting", details);
      HELPERS.messageAlert({ success: "Updated successfully" });
      setDetails(res?.data);
      setIsChanged(false);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    getDetails();
  }, []);

  return (
    <StyledPaymentGateway>
      <Navbar />
      <StyledMobileSpacedFancyContainer token={token} height="calc(100vh - 140px)">
        <div className="payment-gateway">
          <Typography.Title level={5}>Razor Pay Payment Gateway</Typography.Title>
          <div className="details-form">
            <Form.Item label="Key" labelCol={{ span: 24 }} required>
              <Input
                type={"text"}
                value={details?.keyId}
                onChange={(e) => handleChange(e.target.value, "keyId")}
              />
            </Form.Item>
            <Form.Item label="Secret" labelCol={{ span: 24 }} required>
              <Input.Password
                value={details?.secret}
                onChange={(e) => handleChange(e.target.value, "secret")}
                iconRender={(visible) =>
                  visible ? <EyeTwoTone /> : <EyeInvisibleOutlined />
                }
              />
            </Form.Item>
            <Button
              type="primary"
              block
              disabled={!isChanged || loading}
              style={{ marginTop: 20 }}
              onClick={handleUpdate}
            >
              Update
            </Button>
          </div>
        </div>
      </StyledMobileSpacedFancyContainer>
    </StyledPaymentGateway>
  );
};

export default PaymentGateway;
