"use client";

import { useMemo, useState } from "react";
import { Button, Popconfirm, Table, theme } from "antd";
import { HiOutlinePencil } from "react-icons/hi";
import { BiTrashAlt } from "react-icons/bi";
import apiClient from "@/lib/apiClient";
import HELPERS from "@/lib/helpers";
import AddEditPlanModal from "../../FeeStructures/components/AddEditPlanModal";
import { StyledFeePlansListingTable } from "../Styles.FeePlans";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";
import { StyledMobileSpacedContainer } from "@/components/common/styles.common";
import GeneralSkeleton from "@/components/reusable/Loader/Skeleton/GeneralSkeleton";
import { GENERAL_COMPONENTS } from "@/components/common";
import VirtualSwiper from "@/components/reusable/Swiper/virtual/VirtualVerticalSwiper";
import { PlanCard } from "@/components/reusable/cards/GeneralCards";

const FeePlansListingTable = ({
  loading = false,
  listingData = [],
  getListingData = () => {},
}: {
  loading?: boolean;
  listingData?: FeePlanTypes[];
  getListingData?: () => void;
}) => {
  const isMobile = useIsSmallDevice();
  const { token } = theme.useToken();
  const [activeId, setActiveId] = useState("");

  function taskAfterSubmit() {
    setActiveId("");
    getListingData();
  }

  async function handleAction(id = "", key = "") {
    if (key === "EDIT") {
      setActiveId(id);
    } else if (key === "DELETE") {
      try {
        await apiClient.delete(`/fee/plan/${id}`);
        HELPERS.messageAlert({ error: "Deleted successfully" });
      } finally {
        getListingData();
      }
    }
  }

  const columns = useMemo(
    () => [
      {
        title: "Name",
        dataIndex: "name",
        ellipsis: true,
      },
      {
        title: "Type",
        dataIndex: "type",
        ellipsis: true,
      },
      {
        title: "Description",
        dataIndex: "description",
        ellipsis: true,
        render: (description: string) => {
          return (
            description || <span className="text-gray-500">Not added</span>
          );
        },
      },
      {
        title: "Action",
        dataIndex: "id",
        ellipsis: true,
        render: (id = "") => {
          return (
            <div className="flex items-center gap-2">
              <Button
                type="text"
                icon={<HiOutlinePencil />}
                color="primary"
                variant="filled"
                onClick={() => handleAction(id, "EDIT")}
              >
                Edit
              </Button>
              <Popconfirm
                title="Delete user"
                description="Are you sure to delete this user?"
                onConfirm={() => handleAction(id, "DELETE")}
                okText="Yes"
                cancelText="No"
              >
                <Button
                  type="text"
                  icon={<BiTrashAlt />}
                  color="danger"
                  variant="filled"
                >
                  Delete
                </Button>
              </Popconfirm>
            </div>
          );
        },
      },
    ],
    // eslint-disable-next-line react-hooks/exhaustive-deps
    []
  );

  if (isMobile) {
    return (
      <StyledMobileSpacedContainer>
        {loading ? (
          <GeneralSkeleton
            countSmall={0}
            countLarge={10}
            isLargeWrapped
            largeBoxHeight={100}
          />
        ) : listingData?.length === 0 && !loading ? (
          <GENERAL_COMPONENTS.NoResult />
        ) : (
          <VirtualSwiper
            items={listingData || []}
            getKey={(data) => data?.id || ""}
            cardEstimateWidth={110}
            renderItem={(data) => (
              <PlanCard
                data={data}
                onDelete={()=>handleAction(data?.id, "DELETE")}
                onEdit={()=>handleAction(data?.id, "EDIT")}
              />
            )}
          />
        )}
        <AddEditPlanModal
        id={activeId}
        open={!!activeId}
        onCancel={() => setActiveId("")}
        taskAfterSubmit={taskAfterSubmit}
        showTypeDropdown
      />
      </StyledMobileSpacedContainer>
    );
  }

  return (
    <StyledFeePlansListingTable token={token}>
      <Table
        dataSource={listingData}
        columns={columns}
        loading={loading}
        scroll={{ y: 90 * 5 }}
      />
      <AddEditPlanModal
        id={activeId}
        open={!!activeId}
        onCancel={() => setActiveId("")}
        taskAfterSubmit={taskAfterSubmit}
        showTypeDropdown
      />
    </StyledFeePlansListingTable>
  );
};

export default FeePlansListingTable;
