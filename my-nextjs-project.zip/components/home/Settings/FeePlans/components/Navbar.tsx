"use client";

import { useState } from "react";
import { Button, theme, Typography } from "antd";
import { AiOutlinePlus } from "react-icons/ai";
import { SideMenuIcons } from "@/components/home/Sidebar/Icons";
import { StyledNavbar } from "../../Program/Styles.Program";
import AddEditPlanModal from "../../FeeStructures/components/AddEditPlanModal";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";

const Navbar = ({
  getListingData = () => {},
}: {
  getListingData?: () => void;
}) => {
  const { token } = theme.useToken();
  const [openModal, setOpenModal] = useState(false);

  const isMobile = useIsSmallDevice();

  return (
    <StyledNavbar token = {token}>
      <div className="flex-col gap-1.5">
        <div className="flex items-center gap-1.5">
          {SideMenuIcons.SETTINGS()}
          <Typography.Paragraph>Settings</Typography.Paragraph>
        </div>
        <Typography.Title level={isMobile ? 4 : 3}>Plan types</Typography.Title>
      </div>
      <Button
        type="primary"
        icon={<AiOutlinePlus />}
        onClick={() => setOpenModal(true)}
      >
        New plan
      </Button>
      <AddEditPlanModal
        open={openModal}
        onCancel={() => setOpenModal(false)}
        taskAfterSubmit={getListingData}
        showTypeDropdown
      />
    </StyledNavbar>
  );
};

export default Navbar;
