"use client";

import { useEffect, useState } from "react";
import Navbar from "./components/Navbar";
import apiClient from "@/lib/apiClient";
import FeePlansListingTable from "./components/FeePlansListingTable";
import { StyledFeePlans } from "./Styles.FeePlans";

const FeePlans = () => {
  const [loading, setLoading] = useState(false);
  const [listingData, setListingData] = useState<FeePlanTypes[]>();

  async function getListingData() {
    try {
      setLoading(true);
      const res = await apiClient.get("/fee/plan");
      setListingData(res?.data);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    getListingData();
  }, []);

  return (
    <StyledFeePlans>
      <Navbar getListingData={getListingData} />
      <FeePlansListingTable
        listingData={listingData}
        loading={loading}
        getListingData={getListingData}
      />
    </StyledFeePlans>
  );
};

export default FeePlans;
