"use client";

import { Button, Form, Input, Typography } from "antd";
import { StyledSchoolDetails } from "../Styles.School";
import { useEffect, useState } from "react";
import apiClient from "@/lib/apiClient";
import { useParams } from "next/navigation";
import HELPERS from "@/lib/helpers";
import { useGlobalContext } from "@/lib/context/GlobalContext";

const SchoolDetails = () => {
  const { updateOrgs } = useGlobalContext();
  const [details, setDetails] = useState<SchoolDetailsTypes>();
  const [loading, setLoading] = useState(false);
  const [isChanged, setIsChanged] = useState(false);

  const { orgid } = useParams();

  async function handleUpdate() {
    if (!details?.name?.trim()) {
      return HELPERS.messageAlert({ error: "Please provide name" });
    }
    try {
      setLoading(true);
      const res = await apiClient.put(`/org`, details);
      setDetails(res?.data);
      HELPERS.messageAlert({ success: "Updated successfully" });
      const resList = await apiClient.get("/org");
      updateOrgs(resList?.data);
    } finally {
      setIsChanged(false);
      setLoading(false);
    }
  }

  async function getSchoolDetails(id = "") {
    try {
      setLoading(true);
      const res = await apiClient.get(`/org/${id}`);
      setDetails(res?.data);
    } finally {
      setLoading(false);
    }
  }

  function handleChange(val = "", key = "") {
    setIsChanged(true);
    setDetails((prev) => {
      return {
        ...(prev || {}),
        [key]: val,
      };
    });
  }

  useEffect(() => {
    if (orgid) {
      getSchoolDetails(orgid as string);
    }
  }, [orgid]);

  return (
    <StyledSchoolDetails>
      <Typography.Title level={5}>Basic information</Typography.Title>
      <div className="school-details-form">
        <Form.Item label="School full name" labelCol={{ span: 24 }} required>
          <Input
            type={"text"}
            value={details?.name}
            onChange={(e) => handleChange(e.target.value, "name")}
          />
        </Form.Item>
        <Form.Item label="School display name" labelCol={{ span: 24 }}>
          <Input
            type={"text"}
            value={details?.displayName}
            onChange={(e) => handleChange(e.target.value, "displayName")}
          />
        </Form.Item>
        <Button
          type="primary"
          block
          disabled={!isChanged || loading}
          style={{ marginTop: 20 }}
          onClick={handleUpdate}
        >
          Update
        </Button>
      </div>
    </StyledSchoolDetails>
  );
};

export default SchoolDetails;
