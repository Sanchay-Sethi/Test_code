"use client";

import GeneralModal from "@/components/reusable/Modal/GeneralModal/Modal";
import React, { useEffect, useState } from "react";
import { BRANCH_ICON } from "../Icons.School";
import { Button, Drawer, Form, Input, Typography } from "antd";
import apiClient from "@/lib/apiClient";
import HELPERS from "@/lib/helpers";
import TextArea from "antd/es/input/TextArea";
import { StyledBranchModal } from "../Styles.School";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";
import { GLOBAL_CONSTANTS } from "@/constants";
import { ButtonInlineStyles } from "@/components/common/styles.common";
import { SideMenuIcons } from "@/components/home/Sidebar/Icons";
import { CloseOutlined } from "@ant-design/icons";

const BranchModal = ({
  id = "",
  open = false,
  handleCancel = () => {},
  getTableDetails = () => {},
}) => {
  const [details, setDetails] = useState<SchoolBranchTypes>();
  const [loading, setLoading] = useState(false);

  const isMobile = useIsSmallDevice();

  function resetForm() {
    setDetails(undefined);
  }

  function handleModalCancel() {
    resetForm();
    handleCancel();
  }

  async function handleSubmit() {
    if (!details?.name) {
      return HELPERS.messageAlert({ error: "Please provide name" });
    }
    try {
      setLoading(true);
      if (id) {
        await apiClient.put(`/org/branch`, details);
        HELPERS.messageAlert({
          success: "Updated successfully",
        });
      } else {
        await apiClient.post(`/org/branch`, details);
        HELPERS.messageAlert({
          success: "Created successfully",
        });
        resetForm();
      }
      getTableDetails();
      handleModalCancel();
    } finally {
      setLoading(false);
    }
  }

  async function getModalDetails() {
    if (!id) return;
    try {
      setLoading(true);
      const res = await apiClient.get(`/org/branch/${id}`);
      setDetails(res?.data);
    } finally {
      setLoading(false);
    }
  }

  function handleChange(value: string, key = "") {
    setDetails((prev) => {
      return {
        ...(prev || {}),
        [key]: value,
      };
    });
  }

  useEffect(() => {
    getModalDetails();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  function getBody() {
    return (
      <StyledBranchModal>
        <Form.Item label="Branch name" labelCol={{ span: 24 }} required>
          <Input
            type={"text"}
            placeholder="eg: Vidyalaya high school"
            value={details?.name}
            onChange={(e) => handleChange(e.target.value, "name")}
          />
        </Form.Item>
        <Form.Item label="Address" labelCol={{ span: 24 }}>
          <TextArea
            value={details?.address}
            onChange={(e) => handleChange(e.target.value, "address")}
            placeholder="House/Flat no., Area, Pin code, City etc"
          />
        </Form.Item>
      </StyledBranchModal>
    );
  }

  if (isMobile) {
    return (
      <Drawer
        onClose={handleCancel}
        open={open}
        placement="bottom"
        height={"55%"}
        closable={false}
        style={{
          borderTopLeftRadius:
            GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.BORDER_RADIUS,
          borderTopRightRadius:
            GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.BORDER_RADIUS,
        }}
        footer={
          <div className="flex items-center justify-center gap-2">
            <Button style={ButtonInlineStyles} block onClick={handleCancel}>
              Cancel
            </Button>
            <Button
              type="primary"
              style={ButtonInlineStyles}
              block
              onClick={handleSubmit}
              disabled={loading}
            >
              {id ? "Update" : "Add"}
            </Button>
          </div>
        }
        title={
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              {SideMenuIcons.SETTINGS()}
              <Typography.Title level={5}>
                {id ? "Update branch" : "New branch"}
              </Typography.Title>
            </div>
            <Button onClick={handleCancel} shape="circle">
              <CloseOutlined />
            </Button>
          </div>
        }
      >
        {getBody()}
      </Drawer>
    );
  }

  return (
    <GeneralModal
      open={open}
      onCancel={handleModalCancel}
      customTitle={id ? "Update branch" : "New branch"}
      titleIcon={<BRANCH_ICON />}
      footer={[
        <Button key="cancel" onClick={handleCancel}>
          Cancel
        </Button>,
        <Button
          type="primary"
          key="create"
          onClick={handleSubmit}
          disabled={loading}
        >
          {id ? "Update" : "Add"}
        </Button>,
      ]}
    >
      {getBody()}
    </GeneralModal>
  );
};

export default BranchModal;
