"use client";

import React, { useEffect, useMemo, useState } from "react";
import { Button, Popconfirm, Table, theme, Typography } from "antd";
import { BiTrashAlt } from "react-icons/bi";
import { AiOutlinePlus } from "react-icons/ai";
import BranchModal from "./BranchModal";
import apiClient from "@/lib/apiClient";
import { HiOutlinePencil } from "react-icons/hi";
import { StyledBranches } from "../Styles.School";
import HELPERS from "@/lib/helpers";
import { useGlobalContext } from "@/lib/context/GlobalContext";
import { useParams } from "next/navigation";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";
import GeneralSkeleton from "@/components/reusable/Loader/Skeleton/GeneralSkeleton";
import { GENERAL_COMPONENTS } from "@/components/common";
import VirtualSwiper from "@/components/reusable/Swiper/virtual/VirtualVerticalSwiper";
import { BranchCard } from "@/components/reusable/cards/GeneralCards";

const Branches = () => {
  const { token } = theme.useToken();
  const { branchid } = useParams();
  const { updateBranches } = useGlobalContext();

  const isMobile = useIsSmallDevice();

  const [loading, setLoading] = useState(false);
  const [openModal, setOpenModal] = useState(false);
  const [activeId, setActiveId] = useState("");
  const [tableData, setTableData] = useState<SchoolBranchTypes[]>();

  function handleCancel() {
    setActiveId("");
    setOpenModal(false);
  }

  async function getTableDetails() {
    try {
      setLoading(true);
      const res = await apiClient.get("/org/branch/listbyid");
      setTableData(res?.data);
      updateBranches(res?.data);
    } finally {
      setLoading(false);
    }
  }

  async function handleAction(id = "", key = "") {
    if (key === "EDIT") {
      setActiveId(id);
      setOpenModal(true);
    } else if (key === "DELETE") {
      try {
        await apiClient.delete(`/org/branch/${id}`);
        HELPERS.messageAlert({ success: "Deleted successfully" });
      } finally {
        getTableDetails();
      }
    }
  }

  const columns = useMemo(
    () => [
      {
        title: "Name",
        dataIndex: "name",
        ellipsis: true,
      },
      {
        title: "Address",
        dataIndex: "address",
        ellipsis: true,
        render: (address: string) => {
          console.log({
            address,
          });
          return address || <span className="text-gray-500">Not added</span>;
        },
      },
      {
        title: "Action",
        dataIndex: "id",
        ellipsis: true,
        render: (id = "") => {
          return (
            <div className="flex items-center gap-2">
              <Button
                type="text"
                icon={<HiOutlinePencil />}
                color="primary"
                variant="filled"
                onClick={() => handleAction(id, "EDIT")}
              >
                Edit
              </Button>
              {branchid !== id && (
                <Popconfirm
                  title="Delete branch"
                  description="Are you sure to delete this branch?"
                  onConfirm={() => handleAction(id, "DELETE")}
                  okText="Yes"
                  cancelText="No"
                >
                  <Button
                    type="text"
                    icon={<BiTrashAlt />}
                    color="danger"
                    variant="filled"
                  >
                    Delete
                  </Button>
                </Popconfirm>
              )}
            </div>
          );
        },
      },
    ],
    // eslint-disable-next-line react-hooks/exhaustive-deps
    []
  );

  useEffect(() => {
    getTableDetails();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <StyledBranches token={token}>
      <div className="school-branches-title">
        <Typography.Title level={5}>All branches</Typography.Title>
        <Button
          type="primary"
          icon={<AiOutlinePlus />}
          onClick={() => setOpenModal(true)}
        >
          New branch
        </Button>
      </div>
      <div className="branches-table">
        {isMobile ? (
          <>
            {loading ? (
              <GeneralSkeleton
                countSmall={0}
                countLarge={10}
                isLargeWrapped
                largeBoxHeight={100}
              />
            ) : tableData?.length === 0 && !loading ? (
              <GENERAL_COMPONENTS.NoResult />
            ) : (
              <VirtualSwiper
                items={tableData || []}
                getKey={(student) => student?.id || ""}
                cardEstimateWidth={100}
                containerHeight={"calc(100vh - 254px)"}
                renderItem={(data) => (
                  <BranchCard
                    data={data}
                    onDelete={() => handleAction(data?.id, "DELETE")}
                    onEdit={() => handleAction(data?.id, "EDIT")}
                    branchid={`${branchid}`}
                  />
                )}
              />
            )}
          </>
        ) : (
          <Table
            loading={loading}
            dataSource={tableData}
            columns={columns}
            scroll={{ y: 100 * 5 }}
          />
        )}
      </div>
      <BranchModal
        id={activeId}
        open={openModal}
        handleCancel={handleCancel}
        getTableDetails={getTableDetails}
      />
    </StyledBranches>
  );
};

export default Branches;
