interface SchoolDetailsTypes {
    name: string,
    displayName?: string,
    id?: number,
}

interface SchoolBranchTypes {
    name: string,
    address?: string,
    id?: string,
    createdAt?: string,
    updatedAt?: string,
}