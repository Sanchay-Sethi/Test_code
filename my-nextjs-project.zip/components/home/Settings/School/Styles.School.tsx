"use client";

import { GLOBAL_CONSTANTS } from "@/constants";
import { StyledContextProps } from "@/types";
import styled from "styled-components";
import { commonContainerMobileExtraStyles, mobileNavbarExtraStyles } from "@/components/common/styles.common";

export const StyledSchool = styled.div`
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 20px;

  ${commonContainerMobileExtraStyles}
`;

export const StyledNavbar = styled.div<StyledContextProps>`
  display: flex;
  justify-content: space-between;
  flex-wrap: wrap;
  gap: 20px;

  ${mobileNavbarExtraStyles}

`;

export const StyledSchoolDetails = styled.div`
  width: 100%;
  padding: 40px 0;
  display: flex;
  flex-direction: column;
  gap: 20px;

  .school-details-form {
    width: 50%;
  }

  @media (max-width: ${GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.RESPONSIVE_WIDTH}px) {
    padding: 20px 0 40px 0;
    
    .school-details-form {
      width: 100%;
    }
  }
`;

export const StyledBranchModal = styled.div``;

export const StyledBranches = styled.div<StyledContextProps>`
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 20px;

  .branches-table {
    width: 100%;
    height: calc(100vh - 242px);
    overflow: auto;
  }

  .ant-pagination {
    position: sticky;
    bottom: 0px;
    background-color: ${({ token }) => token?.colorBgBase};
    padding: 12px 20px;
    margin: 0px;
    z-index: 10;
  }

  .school-branches-title {
    width: 100%;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 20px;
    flex-wrap: wrap;
  }

  .ant-table-thead > tr > th {
    background: transparent;
    font-weight: 500;
    text-transform: uppercase;
  }

  .ant-table-tbody > tr > td,
  .ant-table-wrapper tfoot > tr > td {
    padding: 12px 16px;
  }
`;
