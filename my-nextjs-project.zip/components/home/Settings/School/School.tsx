"use client"

import { useEffect, useMemo, useState } from "react";
import { Tabs, theme } from "antd";
import { useSearchParams } from "next/navigation";
import { useNavigation } from "@/lib/context/NavigationContext";
import SchoolDetails from "./components/SchoolDetails";
import Branches from "./components/Branches";
import Navbar from "./components/Navbar";
import { StyledSchool } from "./Styles.School";
import { StyledMobileSpacedFancyContainer } from "@/components/common/styles.common";

const TAB_KEYS = ["SCHOOL", "BRANCH"];

const School = () => {
  const searchParams = useSearchParams();
  const { navigate } = useNavigation();
  const { token } = theme.useToken();

  const [mode, setMode] = useState("SCHOOL");

  const paramMode = searchParams.get("mode");

  useEffect(() => {
    if (paramMode && TAB_KEYS?.includes(paramMode)) {
      setMode(paramMode);
    } else {
      setMode("SCHOOL");
    }
  }, [paramMode]);

  const handleTabChange = (key: string) => {
    setMode(key);
    const params = new URLSearchParams(searchParams?.toString());
    params.set("mode", key?.trim());
    navigate(`?${params.toString()}`);
  };

  const items = useMemo(
    () => [
      {
        key: "SCHOOL",
        label: "School details",
        children: (
          <SchoolDetails />
        ),
      },
      {
        key: "BRANCH",
        label: "Branches",
        children: (
          <Branches />
        ),
      },
    ],
    []
  );

  return (
    <StyledSchool>
      <Navbar />
      <StyledMobileSpacedFancyContainer token={token} height = "calc(100vh - 128px)">
        <Tabs activeKey={mode} items={items} onChange={handleTabChange} />
      </StyledMobileSpacedFancyContainer>
    </StyledSchool>
  );
};

export default School;
