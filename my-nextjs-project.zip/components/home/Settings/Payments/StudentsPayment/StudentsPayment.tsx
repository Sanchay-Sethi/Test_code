"use client";

import apiClient from "@/lib/apiClient";
import { Student } from "@/lib/context/students/studentsTypes";
import { useParams, useSearchParams } from "next/navigation";
import { useEffect, useState } from "react";
import { StyledPayments } from "../styles.Payments";
import Navbar from "../components/Navbar";
import Filters from "../components/Filters";
import StudentsList from "../components/StudentList";

const StudentsPayment = () => {
  const [students, setStudents] = useState<Student[]>([]);
  const [loading, setLoading] = useState(false);

  const searchParams = useSearchParams();

  const { branchid } = useParams();

  async function getStudents(
    branchid?: string,
    params?: Record<string, string>
  ) {
    try {
      setLoading(true);
      const queryString = params
        ? "&" + new URLSearchParams(params).toString()
        : "";

      const res = await apiClient.get(
        `/student?branchId=${branchid}${queryString}`
      );
      const data = res.data;
      setStudents(data);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    const params: Record<string, string> = {};
    for (const [key, value] of searchParams?.entries()) {
      params[key] = value;
    }
    if (Object?.keys(params)?.length > 0) {
      getStudents(branchid as string, params);
    } else {
      getStudents(branchid as string);
    }
  }, [searchParams, branchid]);

  return (
    <StyledPayments>
      <Navbar isStudentPage/>
      <Filters nameSearchInit={searchParams.get("nameSearch") || ""} isStudentPage/>
      <StudentsList data={students} loading={loading}/>
    </StyledPayments>
  );
};

export default StudentsPayment;
