"use client";

import React, { useMemo, useState } from "react";
import { AiOutlineDownload } from "react-icons/ai";
import { Button, Table, theme } from "antd";
import { StyledStudentsPaymentList } from "../styles.Payments";
import FormattedDate from "@/components/reusable/Date/FormattedDate";
import { StyledMobileSpacedContainer } from "@/components/common/styles.common";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";
import GeneralSkeleton from "@/components/reusable/Loader/Skeleton/GeneralSkeleton";
import { GENERAL_COMPONENTS } from "@/components/common";
import VirtualSwiper from "@/components/reusable/Swiper/virtual/VirtualVerticalSwiper";
import { PaymentCard } from "@/components/reusable/cards/GeneralCards";
import apiClient from "@/lib/apiClient";

export function DownloadReceipt({ id = "" }) {
  const [loading, setLoading] = useState(false);
  const isMobile = useIsSmallDevice();

  async function downloadReceipt() {
    try {
      setLoading(true);
      const res = await apiClient.get(`/payment/receipt/download/${id}`, {
        responseType: "blob",
      });
      const blob = res.data;
      const isInWebView = typeof window.ReactNativeWebView !== "undefined";
      if (isInWebView) {
        const fileReader = new FileReader();
        fileReader.onloadend = function () {
          if (fileReader.result && typeof fileReader.result === "string") {
            const base64data = fileReader.result.split(",")[1];
            if (
              typeof window !== "undefined" &&
              typeof window.ReactNativeWebView?.postMessage === "function"
            ) {
              window.ReactNativeWebView.postMessage(
                JSON.stringify({
                  type: "DOWNLOAD_PDF",
                  fileName: `receipt_${id}.pdf`,
                  base64: base64data,
                })
              );
            }
          }
        };
        fileReader.readAsDataURL(blob);
      } else {
        const link = document.createElement("a");
        link.href = window.URL.createObjectURL(blob);
        link.download = `receipt_${id}.pdf`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        window.URL.revokeObjectURL(link.href);
      }
    } catch (error) {
      console.error("Download failed:", error);
    } finally {
      setLoading(false);
    }
  }

  if (!id) return null;
  return (
    <Button
      icon={<AiOutlineDownload />}
      size="small"
      type={isMobile ? "default" : "link"}
      color={"primary"}
      variant={isMobile ? "outlined" : "link"}
      disabled={loading}
      loading={loading}
      onClick={downloadReceipt}
    >
      {isMobile ? "" : "Receipt"}
    </Button>
  );
}

const StudentsPaymentList = ({
  data,
  loading = false,
}: {
  data: PaymentTypes[];
  loading: boolean;
}) => {
  const { token } = theme.useToken();
  const isMobile = useIsSmallDevice();

  const columns = useMemo(
    () => [
      {
        key: "DATE",
        title: "Payment date",
        dataIndex: "paymentDate",
        ellipsis: true,
        width: 150,
        render: (paymentDate: string) => (
          <FormattedDate dateString={paymentDate} />
        ),
      },
      {
        key: "NAME",
        title: "Name",
        dataIndex: "studentName",
        ellipsis: true,
        width: 150,
      },
      {
        key: "ADMISSION_NUMBER",
        title: "Admission Id",
        dataIndex: "admissionNo",
        ellipsis: true,
        width: 150,
      },
      {
        key: "CLASS",
        title: "Class",
        dataIndex: "className",
        ellipsis: true,
        width: 150,
      },
      {
        key: "MODE",
        title: "Mode",
        dataIndex: "mode",
        ellipsis: true,
        width: 150,
      },
      {
        key: "AMOUNT",
        title: "Amount",
        dataIndex: "amount",
        ellipsis: true,
        width: 150,
        render: (amount: number) => amount?.toLocaleString(),
      },
      {
        key: "Action",
        title: "Action",
        dataIndex: "id",
        ellipsis: true,
        width: 150,
        render: (id: string) => <DownloadReceipt id={id} />,
      },
    ],
    []
  );

  if (isMobile) {
    return (
      <StyledMobileSpacedContainer>
        {loading ? (
          <GeneralSkeleton
            countSmall={0}
            countLarge={10}
            isLargeWrapped
            largeBoxHeight={100}
          />
        ) : data?.length === 0 && !loading ? (
          <GENERAL_COMPONENTS.NoResult />
        ) : (
          <VirtualSwiper
            items={data || []}
            getKey={(data) => data?.id || ""}
            cardEstimateWidth={180}
            containerHeight={"calc(100vh - 200px)"}
            renderItem={(details) => (
              <PaymentCard
                data={details}
                extra={<DownloadReceipt id={details?.id} />}
              />
            )}
          />
        )}
      </StyledMobileSpacedContainer>
    );
  }

  return (
    <StyledStudentsPaymentList token={token}>
      <Table
        dataSource={data}
        loading={loading}
        columns={columns}
        sticky={true}
        tableLayout={"fixed"}
        scroll={{ x: "max-content" }}
        pagination={{
          position: ["bottomRight"],
          total: (data || [])?.length,
          showTotal: (total) => `Total ${total} items`,
          align: "center",
        }}
      />
    </StyledStudentsPaymentList>
  );
};

export default StudentsPaymentList;
