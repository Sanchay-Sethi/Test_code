"use client";

import React, { useMemo } from "react";
import { Button, Table, theme } from "antd";
import { StyledStudentsPaymentList } from "../styles.Payments";
import { StyledMobileSpacedContainer } from "@/components/common/styles.common";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";
import GeneralSkeleton from "@/components/reusable/Loader/Skeleton/GeneralSkeleton";
import { GENERAL_COMPONENTS } from "@/components/common";
import VirtualSwiper from "@/components/reusable/Swiper/virtual/VirtualVerticalSwiper";
import { Student } from "@/lib/context/students/studentsTypes";
import { useNavigation } from "@/lib/context/NavigationContext";
import StudentMobileCard from "@/components/reusable/cards/StudentMobileCard/StudentMobileCard";

const StudentsList = ({
  data,
  loading = false,
}: {
  data: Student[];
  loading: boolean;
}) => {
  const { token } = theme.useToken();
  const isMobile = useIsSmallDevice();

  const { navigate } = useNavigation();

  function handleClick(id = "") {
    if (!id) return;
    navigate(`/fees/${id}?backurl=payments`);
  }

  const columns = useMemo(
    () => [
      {
        key: "NAME",
        title: "Name",
        dataIndex: "name",
        ellipsis: true,
        width: 150,
      },
      {
        key: "ADMISSION_NUMBER",
        title: "Admission Id",
        dataIndex: "admissionNumber",
        ellipsis: true,
        width: 150,
      },
      {
        key: "PROGRAM",
        title: "Program",
        dataIndex: "programName",
        ellipsis: true,
        width: 150,
      },
      {
        key: "ACTION",
        title: "Action",
        dataIndex: "id",
        ellipsis: true,
        width: 150,
        render: (id: string) => (
          <Button
            color="primary"
            variant="filled"
            onClick={() => handleClick(id)}
          >
            Collect
          </Button>
        ),
      },
    ],
    // eslint-disable-next-line react-hooks/exhaustive-deps
    []
  );

  if (isMobile) {
    return (
      <StyledMobileSpacedContainer>
        {loading ? (
          <GeneralSkeleton
            countSmall={0}
            countLarge={10}
            isLargeWrapped
            largeBoxHeight={100}
          />
        ) : data?.length === 0 && !loading ? (
          <GENERAL_COMPONENTS.NoResult />
        ) : (
          <VirtualSwiper
            items={data || []}
            getKey={(data) => data?.id || ""}
            cardEstimateWidth={120}
            containerHeight={"calc(100vh - 200px)"}
            renderItem={(details) => <StudentMobileCard details={details} onClick={() => handleClick(details?.id)} isPayment/>}
          />
        )}
      </StyledMobileSpacedContainer>
    );
  }

  return (
    <StyledStudentsPaymentList token={token}>
      <Table
        dataSource={data}
        loading={loading}
        columns={columns}
        sticky={true}
        tableLayout={"fixed"}
        scroll={{ x: "max-content" }}
        pagination={{
          position: ["bottomRight"],
          total: (data || [])?.length,
          showTotal: (total) => `Total ${total} items`,
          align: "center",
        }}
      />
    </StyledStudentsPaymentList>
  );
};

export default StudentsList;
