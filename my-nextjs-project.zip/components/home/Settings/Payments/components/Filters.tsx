"use client";

import { useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import { Button, Input } from "antd";
import { SearchOutlined } from "@ant-design/icons";
import { useDebounce } from "@/lib/hooks/useDebounce";
import { useNavigation } from "@/lib/context/NavigationContext";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";
import { StyledFilters } from "@/components/home/Students/styles.Students";
import { FILTER_ICON } from "@/components/home/Students/Icons";
import FilterDrawer from "@/components/reusable/Drawers/FilterDrawer/FilterDrawer";
import FilterButton from "@/components/reusable/Buttons/Filters/FilterButton";

const Filters = ({
  nameSearchInit,
  isStudentPage,
}: {
  nameSearchInit: string;
  isStudentPage?: boolean;
}) => {
  const { navigate } = useNavigation();
  const searchParams = useSearchParams();
  const isMobile = useIsSmallDevice();

  const [nameSearch, setNameSearch] = useState(nameSearchInit);
  const debouncedSearch = useDebounce(nameSearch, 500);

  function handleChange(key = "", value = "") {
    if (key === "nameSearch") {
      setNameSearch(value);
    }
  }

  function getFilters() {
    if (isStudentPage) {
      return isMobile ? (
        <FilterDrawer
          types={["BRANCH", "PHONE"]}
        />
      ) : (
        <>
          <Button
            icon={<FILTER_ICON />}
            shape="circle"
            className="filter-mock-button"
          />
          <FilterButton type="BRANCH" />
          <FilterButton type="PHONE" />
        </>
      );
    }
    return isMobile ? (
      <FilterDrawer
        types={["BRANCH", "STUDENT_PHONE", "DATE_RANGE", "PAYMENT_MODE"]}
      />
    ) : (
      <>
        <Button
          icon={<FILTER_ICON />}
          shape="circle"
          className="filter-mock-button"
        />
        <FilterButton type="BRANCH" />
        <FilterButton type="STUDENT_PHONE" />
        <FilterButton type="DATE_RANGE" />
        <FilterButton type="PAYMENT_MODE" />
      </>
    );
  }

  useEffect(() => {
    const params = new URLSearchParams(searchParams.toString());
    if (debouncedSearch) {
      params.set(isStudentPage ? "nameSearch" : "studentName", debouncedSearch?.trim());
    } else {
      params.delete(isStudentPage ? "nameSearch" : "studentName");
    }

    navigate(`?${params.toString()}`);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debouncedSearch]);

  return (
    <StyledFilters>
      <div className="filter-search">
        <Input
          type="text"
          prefix={<SearchOutlined />}
          placeholder="Search by name..."
          className="search-input"
          value={nameSearch}
          size={isMobile ? "small" : "middle"}
          style={
            isMobile
              ? { borderRadius: "8px", padding: "2px 15px", fontSize: 14 }
              : {}
          }
          onChange={(e) => handleChange("nameSearch", e.target.value)}
        />
      </div>
      {getFilters()}
    </StyledFilters>
  );
};

export default Filters;
