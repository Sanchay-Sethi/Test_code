"use client";

import { Button, Select, theme, Typography } from "antd";
import { SideMenuIcons } from "@/components/home/Sidebar/Icons";
import { StyledNavbar } from "../../Program/Styles.Program";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";
import { useGlobalValues } from "@/lib/hooks/useGlobalValues";
import { useNavigation } from "@/lib/context/NavigationContext";
import { useSearchParams } from "next/navigation";
import { GENERAL_COMPONENTS } from "@/components/common";

const Navbar = ({ onCollect = () => {}, academicYearId = "", isStudentPage = false }) => {
  const { token } = theme.useToken();
  const isMobile = useIsSmallDevice();
  const { CURRENT_ACADEMIC_YEAR, ACADEMIC_YEAR_OPTIONS } = useGlobalValues();
  const { navigate } = useNavigation();
  const searchParams = useSearchParams();

  function handleAcadmicYearChange(val="") {
    const params = new URLSearchParams(searchParams.toString());
    if (val) {
      params.set("academicYearId", val);
    } else {
      params.delete("academicYearId");
    }

    navigate(`?${params.toString()}`);
  }

  return (
    <StyledNavbar token={token}>
      <div className="flex items-center gap-4">
        {
          isStudentPage &&
          <GENERAL_COMPONENTS.BackButton backUrl={"/payments"} />
        }
        <div className={"flex-col gap-1.5"}>
          <div className="flex items-center gap-1.5">
            {SideMenuIcons.SETTINGS()}
            <Typography.Paragraph>Settings</Typography.Paragraph>
          </div>
          <Typography.Title level={isMobile ? 5 : 2}>{isStudentPage ? "Students" : "Payments"}</Typography.Title>
        </div>
      </div>
      {
        !isStudentPage &&
        <div className="flex items-center gap-2">
          <Select
            style={{ width: 120 }}
            value={academicYearId || CURRENT_ACADEMIC_YEAR}
            onChange={handleAcadmicYearChange}
            options={ACADEMIC_YEAR_OPTIONS}
          />
          <Button type="primary" onClick={onCollect}>
            Collect
          </Button>
        </div>
      }
    </StyledNavbar>
  );
};

export default Navbar;
