"use client";

import { StyledContextProps } from "@/types";
import styled from "styled-components";

export const StyledPayments = styled.div`
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 20px;
`;

export const StyledStudentsPaymentList = styled.div<StyledContextProps>`
  width: 100%;

  .ant-pagination {
    position: sticky;
    bottom: 0px;
    background-color: ${({ token }) => token?.colorBgBase};
    padding: 12px 20px;
    margin: 0px;
    z-index: 10;
  }

  .ant-table-thead > tr > th {
    background: ${({ token }) => token?.colorBgBase};
    font-weight: 500;
    text-transform: uppercase;
  }

  .ant-table-tbody > tr > td,
  .ant-table-wrapper tfoot > tr > td {
    padding: 14px 16px;
  }

  .clickable-row {
    cursor: pointer;
    transition: color 0.4s ease;
  }

  .clickable-row:hover td {
    color: ${({ token }) => token?.colorLink};
  }
`;
