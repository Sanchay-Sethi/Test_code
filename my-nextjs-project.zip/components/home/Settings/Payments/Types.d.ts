interface PaymentTypes {
    id: string;
    paymentDate: string;
    studentId: string;
    studentName: string;
    admissionNo: string;
    className: string;
    amount: number;
    mode: string;
    receiptNo: number;
}