"use client";

import { useEffect, useState } from "react";
import Navbar from "./components/Navbar";
import StudentsPaymentList from "./components/StudentsPaymentList";
import { StyledPayments } from "./styles.Payments";
import { useParams, useSearchParams } from "next/navigation";
import apiClient from "@/lib/apiClient";
import Filters from "./components/Filters";
import { useGlobalValues } from "@/lib/hooks/useGlobalValues";
import { useNavigation } from "@/lib/context/NavigationContext";

const Payments = () => {
  const [payments, setPayments] = useState<PaymentTypes[]>([]);
  const [loading, setLoading] = useState(false);

  const { CURRENT_ACADEMIC_YEAR } = useGlobalValues();

  const { navigate } = useNavigation();

  const searchParams = useSearchParams();

  const { branchid } = useParams();

  async function getPayments(
    branchid?: string,
    params?: Record<string, string>
  ) {
    try {
      setLoading(true);
      const academicYearId = params?.academicYearId || CURRENT_ACADEMIC_YEAR;
      if (params?.academicYearId) {
        delete params?.["academicYearId"];
      }
      const queryString = params
        ? "&" + new URLSearchParams(params).toString()
        : "";

      const res = await apiClient.get(
        `/payment/listinfo?branchId=${branchid}&academicYearId=${academicYearId}${queryString}`
      );
      const data = res.data;
      setPayments(data);
    } finally {
      setLoading(false);
    }
  }

  function handleCollect() {
    navigate("/payments/student-payment")
  }

  useEffect(() => {
    // This Effect calls when any change in params
    const params: Record<string, string> = {};
    for (const [key, value] of searchParams?.entries()) {
      params[key] = value;
    }
    if (Object?.keys(params)?.length > 0) {
      getPayments(branchid as string, params);
    } else {
      getPayments(branchid as string);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchParams, branchid]);

  return (
    <StyledPayments>
      <Navbar
        onCollect={handleCollect}
        academicYearId={searchParams.get("academicYearId") || ""}
      />
      <Filters nameSearchInit={searchParams.get("studentName") || ""} />
      <StudentsPaymentList data={payments} loading={loading} />
    </StyledPayments>
  );
};

export default Payments;
