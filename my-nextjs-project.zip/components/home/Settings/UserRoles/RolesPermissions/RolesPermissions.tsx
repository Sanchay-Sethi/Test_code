"use client"
import { useEffect, useState } from "react";
import Navbar from "./components/Navbar";
import apiClient from "@/lib/apiClient";
import { StyledRolesPermissions } from "../Styles.UserRoles";
import DetailsAndPermissions from "./components/DetailsAndPermissions";
import HELPERS from "@/lib/helpers";

const RolesPermissions = ({ id = "" }: { id?: string }) => {
  const [details, setDetails] = useState<RolesOptionsTypes>({});
  const [loading, setLoading] = useState(false);

  async function getDetails() {
    if (!id) return;
    try {
      setLoading(true);
      const res = await apiClient.get(`/role/${id}`);
      setDetails(res?.data);
    } finally {
      setLoading(false);
    }
  }

  async function handleSubmit(allDetails : RolesOptionsTypes) {
    if (!allDetails?.name) {
      return HELPERS.messageAlert({
        error: "Please provide name"
      })
    }
    try {
      setLoading(true);
      if (id) {
        const res = await apiClient.put(`/role`, allDetails);
        setDetails(res?.data);
        HELPERS.messageAlert({
          success : "Updated successfully"
        })
      } else {
        const res = await apiClient.post(`/role`, allDetails);
        setDetails(res?.data);
         HELPERS.messageAlert({
          success : "Created successfully"
        })
      }
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    getDetails();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <StyledRolesPermissions>
      <Navbar title={details?.name || ""} loading = {loading}/>
      <DetailsAndPermissions details = {details} onSubmit = {handleSubmit}/>
    </StyledRolesPermissions>
  );
};

export default RolesPermissions;
