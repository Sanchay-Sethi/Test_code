"use client";

import { Skeleton, theme, Typography } from "antd";
import { SideMenuIcons } from "@/components/home/Sidebar/Icons";
import { StyledNavbar } from "../../Styles.UserRoles";
import { GENERAL_COMPONENTS } from "@/components/common";
import { RightArrow } from "@/components/home/Fee/Icons";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";

const Navbar = ({
  loading = false,
  title = "",
}: {
  loading?: boolean;
  title?: string;
}) => {
  const { token } = theme.useToken();
  const isMobile = useIsSmallDevice();
  return (
    <StyledNavbar token={token}>
      <div className="flex items-center gap-5">
        <GENERAL_COMPONENTS.BackButton backUrl="/settings/users-roles?mode=ROLES" />
        <div className="flex-col gap-1.5">
          <div className="flex items-center gap-1.5">
            {SideMenuIcons.SETTINGS()}
            <Typography.Paragraph className="flex items-center gap-1.5">
              Users & roles <RightArrow /> Roles
            </Typography.Paragraph>
          </div>
          {loading ? (
            <Skeleton.Input active={true} size={"small"} />
          ) : (
            <Typography.Title level={isMobile ? 4 : 2}>{title || "New role"}</Typography.Title>
          )}
        </div>
      </div>
    </StyledNavbar>
  );
};

export default Navbar;
