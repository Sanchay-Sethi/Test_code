"use client";

import { Button, Checkbox, message, theme, Typography } from "antd";
import { useEffect, useState } from "react";
import { DESC_EDIT_ICON, ROLE_EDIT_ICON } from "../../Icons.UserRoles";
import { StyledDetailsAndPermissions } from "../../Styles.UserRoles";
import GeneralSkeleton from "@/components/reusable/Loader/Skeleton/GeneralSkeleton";
import { GLOBAL_CONSTANTS } from "@/constants";
import { ButtonInlineStyles, StyledMobileSpacedFancyContainer } from "@/components/common/styles.common";
import { CheckOutlined } from "@ant-design/icons";
import { useNavigation } from "@/lib/context/NavigationContext";

interface PermissionMapTypes {
  [key: string]: {
    title: string;
    id: string;
    VIEW: boolean;
    MANAGE: boolean;
  };
}

const DetailsAndPermissions = ({
  loading = false,
  details = {},
  onSubmit = () => {},
}: {
  loading?: boolean;
  details?: RolesOptionsTypes;
  onSubmit?: (obj: RolesOptionsTypes) => void;
}) => {
  const { token } = theme.useToken();
  const { navigate } = useNavigation();
  const [messageApi, contextHolder] = message.useMessage();

  const [internalDetails, setInternalDetails] = useState<RolesOptionsTypes>();
  const [inputChange, setInputChange] = useState(false);
  const [permissionsMap, setPermissionsMap] = useState<PermissionMapTypes>(
    GLOBAL_CONSTANTS.ROLE_PERMISSIONS_MAP
  );

  function handleCancel() {
    navigate("/settings/users-roles?mode=ROLES");
  }

  function handleSubmit() {
    const permissionArr: string[] = [];
    Object?.keys(permissionsMap || {})?.forEach((key) => {
      if (key) {
        const detail = permissionsMap?.[key];
        if (detail?.VIEW) {
          permissionArr?.push(`${key}_VIEW`);
        }
        if (detail?.MANAGE) {
          permissionArr?.push(`${key}_MANAGE`);
        }
      }
    });
    onSubmit({
      ...(internalDetails || {}),
      permissions: permissionArr,
    });
  }

  function handleChange(value: string | string[] | boolean | null, key = "") {
    setInputChange(true);
    setInternalDetails((prev) => {
      return {
        ...(prev || {}),
        [key]: value,
      };
    });
  }

  function handlePermissionMapOnChange(value: boolean, key = "", type = "") {
    setInputChange(true);

    if (type === "VIEW" && permissionsMap?.[key]?.MANAGE === true) {
      messageApi.open({
        type: "warning",
        content: "Action not allowed",
      });
      return;
    }

    setPermissionsMap((prev) => {
      return {
        ...(prev || {}),
        [key]: {
          ...(prev?.[key] || {}),
          [type]: value,
          ...(type === "MANAGE" && value === true
            ? {
                VIEW: value,
              }
            : {}),
        },
      };
    });
  }

  function handlePermissionChanges(permissions: string[]) {
    let allPermissionsMap = GLOBAL_CONSTANTS.ROLE_PERMISSIONS_MAP;
    permissions?.forEach((permission) => {
      const title = permission?.split("_")?.[0];
      const perm_type = permission?.split("_")?.[1];
      allPermissionsMap = {
        ...(allPermissionsMap || {}),
        [title]: {
          ...(allPermissionsMap?.[
            title as keyof typeof GLOBAL_CONSTANTS.ROLE_PERMISSIONS_MAP
          ] || {}),
          [perm_type]: true,
        },
      };
    });
    setPermissionsMap(allPermissionsMap);
  }

  useEffect(() => {
    if (JSON.stringify(internalDetails) !== JSON.stringify(details)) {
      setInternalDetails(details);
      handlePermissionChanges(details?.permissions || []);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [details]);

  if (loading) {
    return <GeneralSkeleton />;
  }

  return (
    <StyledMobileSpacedFancyContainer token={token}>
      <StyledDetailsAndPermissions token={token}>
        <div className="role-title-description">
          <div className="single-t-d-container">
            <div className="icon-title-wrapper">
              <div className="edit-icon-container">
                <ROLE_EDIT_ICON />
              </div>
              <p className="role-title">Role</p>
            </div>
            <Typography.Paragraph
              editable={{ onChange: (val) => handleChange(val, "name") }}
            >
              {internalDetails?.name || (
                <span style={{ color: "#8C8C8C" }}>New role</span>
              )}
            </Typography.Paragraph>
          </div>

          <div className="single-t-d-container">
            <div className="icon-title-wrapper">
              <div className="edit-icon-container">
                <DESC_EDIT_ICON />
              </div>
              <p className="role-title">Description</p>
            </div>
            <Typography.Paragraph
              editable={{ onChange: (val) => handleChange(val, "description") }}
            >
              {internalDetails?.description || (
                <span style={{ color: "#8C8C8C" }}>Not added</span>
              )}
            </Typography.Paragraph>
          </div>
        </div>
        <div className="role-permissions">
          <Typography.Title level={5}>Permissions</Typography.Title>
          <div className="permission-container">
            {Object.keys(permissionsMap || {})?.map((key, index) => {
              const details = permissionsMap?.[key];
              const isLastElement =
                index === Object?.keys(permissionsMap || {})?.length - 1;
              return (
                <div
                  key={details?.id}
                  className={`single-permission-container ${
                    isLastElement ? "perm-last-elem" : ""
                  }`}
                >
                  <div className="permission-box">
                    <Typography.Paragraph>{details?.title}</Typography.Paragraph>
                  </div>
                  <div className="permission-box">
                    <Checkbox
                      checked={details?.VIEW}
                      onChange={(e) =>
                        handlePermissionMapOnChange(
                          e.target?.checked,
                          key,
                          "VIEW"
                        )
                      }
                    >
                      View
                    </Checkbox>
                  </div>
                  <div className="permission-box">
                    <Checkbox
                      checked={details?.MANAGE}
                      onChange={(e) =>
                        handlePermissionMapOnChange(
                          e.target?.checked,
                          key,
                          "MANAGE"
                        )
                      }
                    >
                      Modify
                    </Checkbox>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
        <div className="footer-permission-buttons">
          <Button style={ButtonInlineStyles} onClick={handleCancel}>
            Cancel
          </Button>
          <Button
            style={ButtonInlineStyles}
            icon={<CheckOutlined />}
            type="primary"
            onClick={handleSubmit}
            disabled={!inputChange || loading}
          >
            {details?.id ? "Update" : "Create"}
          </Button>
        </div>
        {contextHolder}
      </StyledDetailsAndPermissions>
    </StyledMobileSpacedFancyContainer>
  );
};

export default DetailsAndPermissions;
