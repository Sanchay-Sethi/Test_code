"use client";

import { useEffect, useMemo, useState } from "react";
import Navbar from "./components/Navbar";
import { StyledUserRoles } from "./Styles.UserRoles";
import { Tabs, theme } from "antd";
import { useSearchParams } from "next/navigation";
import { useNavigation } from "@/lib/context/NavigationContext";
import Users from "./components/Users/Users";
import Roles from "./components/Roles/Roles";
import apiClient from "@/lib/apiClient";
import UsersModal from "./components/Users/UsersModal";
import { StyledMobileSpacedContainer } from "@/components/common/styles.common";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";

const TAB_KEYS = ["USERS", "ROLES"];

const UserRoles = () => {
  const searchParams = useSearchParams();
  const { navigate } = useNavigation();
  const { token } = theme.useToken();
  const isMobile = useIsSmallDevice();

  const [mode, setMode] = useState("USERS");
  const [usersData, setUsersData] = useState();
  const [rolesData, setRolesData] = useState();
  const [loading, setLoading] = useState(false);
  const [openModal, setOpenModal] = useState(false);
  const [activeId, setActiveId] = useState("");

  const paramMode = searchParams.get("mode");

  function handleModalClose() {
    setOpenModal(false);
    setActiveId("");
  }

  function handleNavAction(mode = "") {
    if (mode === "USERS") {
      setOpenModal(true);
    } else if (mode === "ROLES") {
      navigate(`/settings/users-roles/roles`);
    }
  }

  function handleEditUser(id = "") {
    setOpenModal(true);
    setActiveId(id);
  }

  function handleEditRole(id = "") {
    navigate(`/settings/users-roles/roles/${id}`);
  }

  const handleTabChange = (key: string) => {
    setMode(key);
    const params = new URLSearchParams(searchParams?.toString());
    params.set("mode", key?.trim());
    navigate(`?${params.toString()}`);
  };

  async function getAllUsers(params?: Record<string, string>) {
    try {
      setLoading(true);
      const queryString = params
        ? "?" + new URLSearchParams(params)?.toString()
        : "";
      const res = await apiClient.get(`/staff${queryString}`);
      console.log({
        res,
      });
      setUsersData(res?.data);
    } finally {
      setLoading(false);
    }
  }

  async function getAllRoles() {
    try {
      setLoading(true);
      const res = await apiClient.get("/role");
      setRolesData(res?.data);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    if (paramMode && TAB_KEYS?.includes(paramMode)) {
      setMode(paramMode);
    } else {
      setMode("USERS");
    }

    const params: Record<string, string> = {};
    for (const [key, value] of searchParams?.entries()) {
      params[key] = value;
    }
    if (Object?.keys(params)?.length > 0) {
      delete params?.mode;
      if (!paramMode || paramMode === "USERS") {
        getAllUsers(params);
      } else if (paramMode === "ROLES") {
        getAllRoles();
      }
    } else {
      if (!paramMode || paramMode === "USERS") {
        getAllUsers();
      } else if (paramMode === "ROLES") {
        getAllRoles();
      }
    }
  }, [paramMode, searchParams]);

  const items = useMemo(
    () => [
      {
        key: "USERS",
        label: "All users",
        children: (
          <Users
            data={usersData}
            loading={loading}
            onEditUser={handleEditUser}
            getTableDetails={getAllUsers}
          />
        ),
      },
      {
        key: "ROLES",
        label: "Roles",
        children: (
          <Roles
            data={rolesData}
            loading={loading}
            onEditRole={handleEditRole}
            getTableDetails={getAllRoles}
          />
        ),
      },
    ],
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [usersData, loading, rolesData]
  );

  return (
    <StyledUserRoles>
      <Navbar mode={mode} onNavAction={handleNavAction} />
      <StyledMobileSpacedContainer>
        <Tabs
          activeKey={mode}
          items={items}
          onChange={handleTabChange}
          tabBarStyle={
            isMobile
              ? {
                  background: token?.colorBgBase,
                  paddingInline: 16,
                  borderRadius: 12,
                  overflow: "auto",
                }
              : {}
          }
        />
      </StyledMobileSpacedContainer>
      <UsersModal
        id={activeId}
        open={openModal}
        handleCancel={handleModalClose}
        getTableDetails={getAllUsers}
      />
    </StyledUserRoles>
  );
};

export default UserRoles;
