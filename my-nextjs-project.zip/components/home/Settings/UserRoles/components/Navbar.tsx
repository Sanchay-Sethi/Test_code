"use client";

import { Button, theme, Typography } from "antd";
import { SideMenuIcons } from "@/components/home/Sidebar/Icons";
import { StyledNavbar } from "../Styles.UserRoles";
import { AiOutlinePlus } from "react-icons/ai";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";

const Navbar = ({
  mode = "USERS",
  onNavAction = () => {},
}: {
  mode?: string;
  onNavAction?: (mode: string) => void;
}) => {
  const { token } = theme.useToken();
  const isMobile = useIsSmallDevice();

  return (
    <StyledNavbar token={token}>
      <div className="flex-col gap-1.5">
        <div className="flex items-center gap-1.5">
          {SideMenuIcons.SETTINGS()}
          <Typography.Paragraph>Settings</Typography.Paragraph>
        </div>
        <Typography.Title level={isMobile ? 5 : 3}>Users & roles</Typography.Title>
      </div>
      <Button
        type="primary"
        icon={<AiOutlinePlus />}
        onClick={() => onNavAction(mode)}
      >
        New {mode === "USERS" ? "user" : "role"}
      </Button>
    </StyledNavbar>
  );
};

export default Navbar;
