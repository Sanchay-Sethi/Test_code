"use client"

import { useMemo } from "react";
import apiClient from "@/lib/apiClient";
import HELPERS from "@/lib/helpers";
import { Button, Popconfirm, Table } from "antd";
import { BiTrashAlt } from "react-icons/bi";
import { HiOutlinePencil } from "react-icons/hi";
import { StyledUsers } from "../../Styles.UserRoles";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";
import GeneralSkeleton from "@/components/reusable/Loader/Skeleton/GeneralSkeleton";
import { GENERAL_COMPONENTS } from "@/components/common";
import VirtualSwiper from "@/components/reusable/Swiper/virtual/VirtualVerticalSwiper";
import { RoleMobileCard } from "@/components/reusable/cards/GeneralCards";

const Roles = ({
  data = [],
  loading = false,
  getTableDetails = () => {},
  onEditRole = () => {},
}: {
  data?: RolesOptionsTypes[];
  loading?: boolean;
  getTableDetails?: () => void;
  onEditRole?: (id: string) => void;
}) => {

  const isMobile = useIsSmallDevice();

  async function handleAction(id = "", key = "") {
    if (key === "EDIT") {
      onEditRole(id);
    } else if (key === "DELETE") {
      try {
        await apiClient.delete(`/role/${id}`);
        HELPERS.messageAlert({ success: "Deleted successfully" });
      } finally {
        getTableDetails();
      }
    }
  }

  const columns = useMemo(
    () => [
      {
        key: "NAME",
        title: "Name",
        dataIndex: "name",
        ellipsis: true,
        // sorter: true,
        // width: 150,
      },
      {
        key: "DESCRIPTION",
        title: "Description",
        dataIndex: "description",
        ellipsis: true,
        // sorter: true,
        // width: 150,
        render: (description: string) => {
          return description || <span className="text-gray-500">Not added</span>;
        },
      },
      {
        title: "Action",
        dataIndex: "id",
        ellipsis: true,
        render: (id = "") => {
          return (
            <div className="flex items-center gap-2">
              <Button
                type="text"
                icon={<HiOutlinePencil />}
                color="primary"
                variant="filled"
                onClick={() => handleAction(id, "EDIT")}
              >
                Edit
              </Button>
              <Popconfirm
                title="Delete role"
                description="Are you sure to delete this role?"
                onConfirm={() => handleAction(id, "DELETE")}
                okText="Yes"
                cancelText="No"
              >
                <Button
                  type="text"
                  icon={<BiTrashAlt />}
                  color="danger"
                  variant="filled"
                >
                  Delete
                </Button>
              </Popconfirm>
            </div>
          );
        },
      },
    ],
    // eslint-disable-next-line react-hooks/exhaustive-deps
    []
  );
  return (
    <StyledUsers>
      {
        isMobile ? (
          <>
            {loading ? (
              <GeneralSkeleton
                countSmall={0}
                countLarge={10}
                isLargeWrapped
                largeBoxHeight={100}
              />
            ) : data?.length === 0 && !loading ? (
              <GENERAL_COMPONENTS.NoResult />
            ) : (
              <VirtualSwiper
                items={data || []}
                getKey={(role) => role?.id || ""}
                cardEstimateWidth={100}
                containerHeight={"calc(-194px + 100vh)"}
                renderItem={(data) => (
                  <RoleMobileCard
                    data={data}
                    onEdit={() => handleAction(data?.id, "EDIT")}
                    onDelete={() => handleAction(data?.id, "DELETE")}
                  />
                )}
              />
            )}
          </>
        )
        :
        <Table
          dataSource={data}
          columns={columns}
          loading={loading}
          sticky={true}
          tableLayout={"fixed"}
          scroll={{ x: "max-content", y: 60 * 5 }}
        />
      }
    </StyledUsers>
  );
};

export default Roles;
