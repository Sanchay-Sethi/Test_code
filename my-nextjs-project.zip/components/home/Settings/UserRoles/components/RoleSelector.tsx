import React, { useState } from "react";
import { ROLE_ICON } from "../Icons.UserRoles";
import { Button, Popover, theme, Typography } from "antd";
import { StyledRoleContent, StyledRoleSelector } from "../Styles.UserRoles";
import { DownOutlined } from "@ant-design/icons";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";

const Role = ({
  value = "",
  onChange = () => {},
  options = [],
}: {
  value?: string;
  options?: RolesOptionsTypes[];
  onChange?: (val: string) => void;
}) => {
  return (
    <StyledRoleContent>
      {options?.length === 0 && (
        <Typography.Text>No roles created</Typography.Text>
      )}
      {options?.map((option) => {
        const isButtonHighlighted = value === option?.value;
        return (
          <div className="single-role-container" key={option?.value}>
            <Button
              color={isButtonHighlighted ? "primary" : "default"}
              variant={isButtonHighlighted ? "filled" : "text"}
              block
              style={{
                display: "flex",
                justifyContent: "flex-start",
              }}
              onClick={() => onChange(option?.value as string)}
            >
              {option?.label}
            </Button>
          </div>
        );
      })}
    </StyledRoleContent>
  );
};

const RoleSelector = ({
  value = "",
  onChange = () => {},
  options = [],
}: {
  value?: string;
  options?: RolesOptionsTypes[];
  onChange?: (val: string) => void;
}) => {
  const [openDropdown, setOpenDropdown] = useState(false);
  const { token } = theme.useToken();

  const isMobile = useIsSmallDevice();

  const labelVal = options?.find((option) => option.value === value);

  function handleChange(id = "") {
    setOpenDropdown(false);
    onChange(id);
  }

  return (
    <Popover
      content={<Role value={value} onChange={handleChange} options={options} />}
      trigger="click"
      arrow={false}
      open={openDropdown}
      onOpenChange={setOpenDropdown}
      placement={"bottom"}
    >
      <StyledRoleSelector token={token}>
        {!value ? (
          <>
            <Typography.Paragraph style={{ fontSize: 13 }} ellipsis>
              Select the required role
            </Typography.Paragraph>
            <DownOutlined rotate={openDropdown ? 180 : 0} />
          </>
        ) : (
          <>
            <div className="flex items-center gap-4">
              <div className="role-icon">
                <ROLE_ICON />
              </div>
              <div className={`flex-col gap-1 ${isMobile ? "w-[200px]" : ""}`}>
                <Typography.Paragraph style={{ fontWeight: 600 }} ellipsis>
                  {labelVal?.label}
                </Typography.Paragraph>
                <Typography.Paragraph style={{ fontSize: 12 }} ellipsis>
                  {labelVal?.description}
                </Typography.Paragraph>
              </div>
            </div>
            <DownOutlined rotate={openDropdown ? 180 : 0} />
          </>
        )}
      </StyledRoleSelector>
    </Popover>
  );
};

export default RoleSelector;
