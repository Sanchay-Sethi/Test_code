"use client";

import { useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import { Button, Input } from "antd";
import { SearchOutlined } from "@ant-design/icons";
import { useDebounce } from "@/lib/hooks/useDebounce";
import { useNavigation } from "@/lib/context/NavigationContext";
import { FILTER_ICON } from "@/components/home/Students/Icons";
import { StyledFilters } from "../../Styles.UserRoles";
import FilterButton from "@/components/reusable/Buttons/Filters/FilterButton";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";
import FilterDrawer from "@/components/reusable/Drawers/FilterDrawer/FilterDrawer";

const UsersFilter = ({ nameSearchInit = "" }: { nameSearchInit: string }) => {
  const { navigate } = useNavigation();
  const searchParams = useSearchParams();

  const isMobile = useIsSmallDevice();

  const [nameSearch, setNameSearch] = useState(nameSearchInit);
  const debouncedSearch = useDebounce(nameSearch, 500);

  function handleChange(key = "", value = "") {
    if (key === "name") {
      setNameSearch(value);
    }
  }

  useEffect(() => {
    const params = new URLSearchParams(searchParams.toString());
    if (debouncedSearch) {
      params.set("name", debouncedSearch?.trim());
    } else {
      params.delete("name");
    }

    navigate(`?${params.toString()}`);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debouncedSearch]);

  return (
    <StyledFilters>
      <div className="filter-search">
        <Input
          type="text"
          prefix={<SearchOutlined />}
          placeholder="Search by name"
          className="search-input"
          value={nameSearch}
          onChange={(e) => handleChange("name", e.target.value)}
          size={isMobile ? "small" : "middle"}
          style={
            isMobile
              ? { borderRadius: "8px", padding: "5px 15px", fontSize: 14 }
              : {}
          }
        />
      </div>
      <div className="filter-container">
        {
          isMobile ? 
          <FilterDrawer
            types = {["BRANCH"]}
          />
          :
          <>
            <Button
              icon={<FILTER_ICON />}
              shape="circle"
              className="filter-mock-button"
            />
            <FilterButton type="BRANCH" />
          </>
        }
      </div>
    </StyledFilters>
  );
};

export default UsersFilter;
