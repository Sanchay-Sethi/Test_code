"use client";
import { useMemo } from "react";
import { Button, Popconfirm, Table, theme } from "antd";
import { HiOutlinePencil } from "react-icons/hi";
import { BiTrashAlt } from "react-icons/bi";
import { useSearchParams } from "next/navigation";
import UsersFilter from "./UsersFilter";
import apiClient from "@/lib/apiClient";
import HELPERS from "@/lib/helpers";
import { StyledUsers } from "../../Styles.UserRoles";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";
import GeneralSkeleton from "@/components/reusable/Loader/Skeleton/GeneralSkeleton";
import { GENERAL_COMPONENTS } from "@/components/common";
import VirtualSwiper from "@/components/reusable/Swiper/virtual/VirtualVerticalSwiper";
import { UserMobileCard } from "@/components/reusable/cards/GeneralCards";

const Users = ({
  data = [],
  loading = false,
  onEditUser = () => {},
  getTableDetails = () => {},
}: {
  data?: UsersType[];
  loading?: boolean;
  onEditUser?: (id: string) => void;
  getTableDetails?: () => void;
}) => {
  const { token } = theme.useToken();
  const searchParams = useSearchParams();

  const isMobile = useIsSmallDevice();

  async function handleAction(id = "", key = "") {
    if (key === "EDIT") {
      onEditUser(id);
    } else if (key === "DELETE") {
      try {
        await apiClient.delete(`/staff/${id}`);
        HELPERS.messageAlert({ success: "Deleted successfully" });
      } finally {
        getTableDetails();
      }
    }
  }

  const columns = useMemo(
    () => [
      {
        key: "NAME",
        title: "Name",
        dataIndex: "name",
        ellipsis: true,
        // sorter: true,
        // width: 150,
      },
      {
        key: "ROLE",
        title: "Role",
        dataIndex: "role",
        ellipsis: true,
        // sorter: true,
        // width: 150,
      },
      {
        key: "BRANCHES",
        title: "Branches",
        dataIndex: "branches",
        ellipsis: true,
        // sorter: true,
        // width: 200,
        render: (branches: string[]) => {
          return branches?.join(", ");
        },
      },
      {
        key: "PHONE",
        title: "Phone",
        dataIndex: "mobile",
        ellipsis: true,
        // sorter: true,
        width: 200,
        render: (mobile: string) => {
          return mobile || <span className="text-gray-500">Not added</span>;
        },
      },
      {
        key: "EMAIL",
        title: "Email",
        dataIndex: "email",
        ellipsis: true,
        // sorter: true,
        width: 200,
        render: (email: string) => {
          return email || <span className="text-gray-500">Not added</span>;
        },
      },
      {
        title: "Action",
        dataIndex: "id",
        ellipsis: true,
        render: (id = "") => {
          return (
            <div className="flex items-center gap-2">
              <Button
                type="text"
                icon={<HiOutlinePencil />}
                color="primary"
                variant="filled"
                onClick={() => handleAction(id, "EDIT")}
              >
                Edit
              </Button>
              <Popconfirm
                title="Delete user"
                description="Are you sure to delete this user?"
                onConfirm={() => handleAction(id, "DELETE")}
                okText="Yes"
                cancelText="No"
              >
                <Button
                  type="text"
                  icon={<BiTrashAlt />}
                  color="danger"
                  variant="filled"
                >
                  Delete
                </Button>
              </Popconfirm>
            </div>
          );
        },
      },
    ],
    // eslint-disable-next-line react-hooks/exhaustive-deps
    []
  );

  return (
    <StyledUsers token={token}>
      <UsersFilter nameSearchInit={searchParams.get("name") || ""} />
      <div className="users-list-table">
        {isMobile ? (
          <>
            {loading ? (
              <GeneralSkeleton
                countSmall={0}
                countLarge={10}
                isLargeWrapped
                largeBoxHeight={100}
              />
            ) : data?.length === 0 && !loading ? (
              <GENERAL_COMPONENTS.NoResult />
            ) : (
              <VirtualSwiper
                items={data || []}
                getKey={(user) => user?.id || ""}
                cardEstimateWidth={125}
                containerHeight={"calc(-250px + 100vh)"}
                renderItem={(data) => (
                  <UserMobileCard
                    data={data}
                    onEdit={() => handleAction(data?.id, "EDIT")}
                    onDelete={() => handleAction(data?.id, "DELETE")}
                  />
                )}
              />
            )}
          </>
        ) : (
          <Table
            dataSource={data}
            columns={columns}
            loading={loading}
            sticky={true}
            tableLayout={"fixed"}
            scroll={{ x: "max-content", y: 60 * 5 }}
          />
        )}
      </div>
    </StyledUsers>
  );
};

export default Users;
