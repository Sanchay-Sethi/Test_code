"use client";

import { useEffect, useState } from "react";
import GeneralModal from "@/components/reusable/Modal/GeneralModal/Modal";
import { Button, Drawer, Form, Input, Select, Switch, Typography } from "antd";
import apiClient from "@/lib/apiClient";
import HELPERS from "@/lib/helpers";
import { USERS_ICON } from "../../Icons.UserRoles";
import RoleSelector from "../RoleSelector";
import { StyledUsersModal } from "../../Styles.UserRoles";
import { useGlobalValues } from "@/lib/hooks/useGlobalValues";
import { cloneDeep } from "lodash";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";
import { GLOBAL_CONSTANTS } from "@/constants";
import { ButtonInlineStyles } from "@/components/common/styles.common";
import { CloseOutlined } from "@ant-design/icons";

function getRolesOptions(roles: RolesOptionsTypes[]) {
  return roles?.map((role) => {
    return {
      label: role?.name,
      value: role?.id,
      description: role?.description,
      _original: role,
    };
  });
}

const UsersModal = ({
  id = "",
  open = false,
  handleCancel = () => {},
  getTableDetails = () => {},
}) => {
  const isMobile = useIsSmallDevice();
  const { BRANCHES_OPTIONS } = useGlobalValues();

  const [details, setDetails] = useState<UsersDetailsTypes>();
  const [roles, setRoles] = useState();
  const [loading, setLoading] = useState(false);

  function resetForm() {
    setDetails(undefined);
  }

  function handleModalCancel() {
    resetForm();
    handleCancel();
  }

  async function handleSubmit() {
    let detailsCloned = cloneDeep(details) || {};
    if (!detailsCloned?.name) {
      return HELPERS.messageAlert({ error: "Please provide name" });
    }
    if (!detailsCloned?.schoolAdmin) {
      if (!detailsCloned?.branchRoleId) {
        return HELPERS.messageAlert({ error: "Please select role" });
      }
      if (detailsCloned?.branchIds?.length === 0 || !detailsCloned?.branchIds) {
        return HELPERS.messageAlert({ error: "Please select branch/branches" });
      }
    }
    if (!detailsCloned?.mobile) {
      return HELPERS.messageAlert({ error: "Please provide phone number" });
    }

    if (detailsCloned?.schoolAdmin === true) {
      detailsCloned = {
        ...(detailsCloned || {}),
        branchRoleId: "",
        branchIds: []
      }
    }

    try {
      setLoading(true);
      if (id) {
        await apiClient.put(`/staff`, detailsCloned);
        HELPERS.messageAlert({
          success: "Updated successfully",
        });
      } else {
        await apiClient.post(`/staff`, detailsCloned);
        HELPERS.messageAlert({
          success: "Created successfully",
        });
        resetForm();
      }
      getTableDetails();
      handleModalCancel();
    } finally {
      setLoading(false);
    }
  }

  async function getAllRoles() {
    try {
      setLoading(true);
      const res = await apiClient.get("/role");
      setRoles(res?.data);
    } finally {
      setLoading(false);
    }
  }

  async function getModalDetails() {
    getAllRoles();
    if (!id) return;
    try {
      setLoading(true);
      const res = await apiClient.get(`/staff/${id}`);
      setDetails(res?.data);
    } finally {
      setLoading(false);
    }
  }

  function handleChange(value: string | string[] | boolean | null, key = "") {
    setDetails((prev) => {
      return {
        ...(prev || {}),
        [key]: value,
      };
    });
  }

  useEffect(() => {
    if (open) {
      getModalDetails();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, id]);

  function getBody() {
    return (
      <StyledUsersModal>
        <Form.Item label="Full name" labelCol={{ span: 24 }} required>
          <Input
            type={"text"}
            placeholder="eg. xyz"
            value={details?.name}
            onChange={(e) => handleChange(e.target.value, "name")}
          />
        </Form.Item>
        <div className="flex w-[100%]">
          <Form.Item label="School admin" colon={false}>
            <Switch
              checkedChildren={"On"}
              unCheckedChildren={"Off"}
              checked={!!details?.schoolAdmin}
              onChange={(val) => handleChange(val, "schoolAdmin")}
            />
          </Form.Item>
        </div>
        {!details?.schoolAdmin && (
          <>
            <Form.Item label="Role" labelCol={{ span: 24 }} required>
              <RoleSelector
                value={details?.branchRoleId}
                onChange={(val: string) => handleChange(val, "branchRoleId")}
                options={getRolesOptions(roles || [])}
              />
            </Form.Item>
            <Form.Item label="Branches" labelCol={{ span: 24 }} required>
              <Select
                value={details?.branchIds}
                options={BRANCHES_OPTIONS}
                onChange={(val) => handleChange(val, "branchIds")}
                mode="multiple"
                allowClear
              />
            </Form.Item>
          </>
        )}
        <div className="flex gap-4">
          <div className="flex-1/2">
            <Form.Item label="Phone no." labelCol={{ span: 24 }} required>
              <Input
                type={"text"}
                placeholder="987****321"
                value={details?.mobile}
                onChange={(e) => handleChange(e.target.value, "mobile")}
              />
            </Form.Item>
          </div>
          <div className="flex-1/2">
            <Form.Item label="Email" labelCol={{ span: 24 }}>
              <Input
                type={"email"}
                placeholder="abc@xyz.com"
                value={details?.email}
                onChange={(e) => handleChange(e.target.value, "email")}
              />
            </Form.Item>
          </div>
        </div>
      </StyledUsersModal>
    )
  }

  if (isMobile) {
    return (
      <Drawer
        onClose={handleModalCancel}
        open={open}
        placement="bottom"
        height={"85%"}
        closable={false}
        style={{
          borderTopLeftRadius:
            GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.BORDER_RADIUS,
          borderTopRightRadius:
            GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.BORDER_RADIUS,
        }}
        footer={
          <div className="flex items-center justify-center gap-2">
            <Button
              style={ButtonInlineStyles}
              block
              onClick={handleCancel}
            >
              Cancel
            </Button>
            <Button
              type="primary"
              style={ButtonInlineStyles}
              block
              onClick={handleSubmit}
              disabled={loading}
            >
              {id ? "Update" : "Add"}
            </Button>
          </div>
        }
        title={
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <USERS_ICON />
              <Typography.Title level={5}>{id ? "Update user" : "New user"}</Typography.Title>
            </div>
            <Button onClick={handleModalCancel} shape="circle">
              <CloseOutlined />
            </Button>
          </div>
        }
      >
        {getBody()}
      </Drawer>
    )
  }

  return (
    <GeneralModal
      open={open}
      onCancel={handleModalCancel}
      customTitle={id ? "Update user" : "New user"}
      titleIcon={<USERS_ICON />}
      footer={[
        <Button key="cancel" onClick={handleCancel}>
          Cancel
        </Button>,
        <Button
          type="primary"
          key="create"
          onClick={handleSubmit}
          disabled={loading}
        >
          {id ? "Update" : "Add"}
        </Button>,
      ]}
    >
      {getBody()}
    </GeneralModal>
  );
};

export default UsersModal;
