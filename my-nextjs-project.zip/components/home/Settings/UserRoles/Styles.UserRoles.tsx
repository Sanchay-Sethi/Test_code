"use client";

import { commonContainerMobileExtraStyles, mobileNavbarExtraStyles } from "@/components/common/styles.common";
import { GLOBAL_CONSTANTS } from "@/constants";
import { StyledContextProps } from "@/types";
import styled from "styled-components";

export const StyledNavbar = styled.div<StyledContextProps>`
  display: flex;
  justify-content: space-between;
  flex-wrap: wrap;
  gap: 20px;

  ${mobileNavbarExtraStyles}
`;

export const StyledUserRoles = styled.div`
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 20px;

  ${commonContainerMobileExtraStyles}
`;

export const StyledUsers = styled.div<StyledContextProps>`
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 20px;

  .ant-pagination {
    position: sticky;
    bottom: 0px;
    background-color: ${({ token }) => token?.colorBgBase};
    padding: 12px 20px;
    margin: 0px;
    z-index: 10;
  }

  .ant-table-thead > tr > th {
    background: transparent;
    font-weight: 500;
    text-transform: uppercase;
  }

  .ant-table-tbody > tr > td,
  .ant-table-wrapper tfoot > tr > td {
    padding: 10px 16px;
  }
`;

export const StyledFilters = styled.div`
  display: flex;
  align-items: center;
  gap: 20px;
  flex-wrap: wrap;

  .filter-container {
    display: flex;
    align-items: center;
    gap: 15px;
    flex-wrap: wrap;
  }

  .search-input {
    .ant-input-prefix {
      svg {
        color: #697386;
      }
    }
  }

  @media (max-width: ${GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.RESPONSIVE_WIDTH}px) {
    gap: 6px;
  }

`;

export const StyledRoleSelector = styled.div<StyledContextProps>`
  width: 100%;
  display: flex;
  justify-content: space-between;
  padding: 8px;
  border-top: 1px solid ${({ token }) => token?.colorBorder};
  border-bottom: 1px solid ${({ token }) => token?.colorBorder};
  cursor: pointer;
`;

export const StyledRoleContent = styled.div`
  width: 400px;
  display: flex;
  flex-direction: column;
  gap: 2px;
  overflow: auto;

  @media (max-width: ${GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.RESPONSIVE_WIDTH}px) {
    width: 200px;
  }

`;

export const StyledUsersModal = styled.div`
  width: 100%;
  display: flex;
  flex-direction: column;

  .ant-form-item-label > label {
    /* font-weight: 500; */
  }

  .ant-form-item-label {
    padding: 0px;
  }

  .ant-form-item {
    margin-bottom: 20px;
  }
`;

export const StyledRolesPermissions = styled.div`
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 20px;

  ${commonContainerMobileExtraStyles}
`;

export const StyledDetailsAndPermissions = styled.div<StyledContextProps>`
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 20px;

  .role-title-description {
    display: flex;
    flex-direction: column;
    gap: 18px;
    padding: 20px;
  }

  .single-t-d-container {
    display: flex;
    align-items: center;
    gap: 15px;
    flex-wrap: wrap;
  }

  .icon-title-wrapper {
    width: 150px;
    display: flex;
    align-items: center;
    gap: 5px;
  }

  .edit-icon-container {
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 6px 9px;
    border-radius: 10px;
    background: ${({ token }) => token?.colorGreyCard};
  }

  .role-title {
    color: ${({ token }) => token?.colorGreyPrimary};
    font-weight: 600;
  }

  .role-permissions {
    padding: 10px 20px;
    display: flex;
    flex-direction: column;
    gap: 15px;
  }

  .permission-container {
    display: flex;
    flex-direction: column;
  }

  .single-permission-container {
    width: 100%;
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 10px 0px;
    border-top: 1px solid ${({token}) => token?.colorBorder};
  }

  .perm-last-elem {
    border-bottom: 1px solid ${({token}) => token?.colorBorder};
  }

  .permission-box {
    flex: 1 1 calc(100% - 1px);
  }

  .footer-permission-buttons {
    width: 100%;
    display: flex;
    justify-content: flex-end;
    gap: 10px;
    padding: 30px 0;
  }

  @media (max-width: ${GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.RESPONSIVE_WIDTH}px) {
    gap: 12px;
    padding-bottom: 40px;

    .footer-permission-buttons {
      position: fixed;
      bottom: 0;
      left: 0;
      right: 0;
      padding: 10px 14px;
      background-color: ${({token}) => token?.colorBgBase};
    }

    .role-title-description {
      padding: 12px 0;
    }

    .role-permissions {
      padding: 12px 0;    
    }
  }
`;
