interface UsersType {
    id: string,
    name: string,
    role: string,
    branches: string[],
    mobile: string,
    email: string,
    employeeId: string,
}

interface RolesOptionsTypes {
  name?: string,
  id?: string,
  description?: string,
  label?: string,
  value?: string,
  permissions?: string[]
}

interface UsersDetailsTypes {
    name?: string,
    mobile?: string,
    email?: string,
    schoolAdmin?: boolean,
    branchRoleId?: string,
    branchIds?: string[],
    id?: string,
}