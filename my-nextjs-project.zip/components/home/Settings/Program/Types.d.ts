interface ProgramSectionTypes {
    id?: string,
    name?: string,
    levelOrder?: number,
    createdAt?: string,
    updatedAt?: string,
}