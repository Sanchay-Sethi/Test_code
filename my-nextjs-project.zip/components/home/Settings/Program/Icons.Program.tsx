export const PROGRAM_ICON = () => (
  <svg
    width="19"
    height="14"
    viewBox="0 0 19 14"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M0 10V8H7V10H0ZM0 6V4H11V6H0ZM0 2V0H11V2H0ZM13 14V10H9V8H13V4H15V8H19V10H15V14H13Z"
      fill="#A3ACB9"
    />
  </svg>
);
