"use client";

import { useEffect, useState, useMemo } from "react";
import Navbar from "./components/Navbar";
import { StyledProgram } from "./Styles.Program";
import { useSearchParams } from "next/navigation";
import { useNavigation } from "@/lib/context/NavigationContext";
import { Tabs, theme } from "antd";
import apiClient from "@/lib/apiClient";
import ProgramListingTable from "./components/ProgramListingTable";
import { StyledMobileSpacedContainer } from "@/components/common/styles.common";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";

const TAB_KEYS = ["PROGRAM", "SECTION"];

const Program = () => {
  const searchParams = useSearchParams();
  const { navigate } = useNavigation();

  const isMobile = useIsSmallDevice();
  const { token } = theme.useToken();

  const [mode, setMode] = useState("PROGRAM");
  const [listingData, setlistingData] = useState();
  const [tableLoading, setTableLoading] = useState(false);
  const paramMode = searchParams.get("mode");

  async function getListingData(mode = "PROGRAM") {
    try {
      setTableLoading(true);
      const res = await apiClient.get(
        mode === "PROGRAM" ? "/program" : "/program/section"
      );
      setlistingData(res?.data);
    } finally {
      setTableLoading(false);
    }
  }

  useEffect(() => {
    getListingData(mode);
  }, [mode]);

  useEffect(() => {
    if (paramMode && TAB_KEYS?.includes(paramMode)) {
      setMode(paramMode);
    } else {
      setMode("PROGRAM");
    }
  }, [paramMode]);

  const handleTabChange = (key: string) => {
    setMode(key);
    const params = new URLSearchParams(searchParams?.toString());
    params.set("mode", key?.trim());
    navigate(`?${params.toString()}`);
  };

  const items = useMemo(
    () => [
      {
        key: "PROGRAM",
        label: "Programs",
        children: (
          <ProgramListingTable
            mode={mode}
            data={listingData}
            loading={tableLoading}
            getListingData={getListingData}
          />
        ),
      },
      {
        key: "SECTION",
        label: "Sections",
        children: (
          <ProgramListingTable
            mode={mode}
            data={listingData}
            loading={tableLoading}
            getListingData={getListingData}
          />
        ),
      },
    ],
    [mode, listingData, tableLoading]
  );

  return (
    <StyledProgram>
      <Navbar mode={mode} getListingData={getListingData} />
      <StyledMobileSpacedContainer>
        <Tabs activeKey={mode} items={items} onChange={handleTabChange} tabBarStyle={
            isMobile
              ? {
                  background: token?.colorBgBase,
                  paddingInline: 16,
                  borderRadius: 12,
                  overflow: "auto",
                }
              : {}
          }/>
      </StyledMobileSpacedContainer>
    </StyledProgram>
  );
};

export default Program;
