"use client"

import { useEffect, useState } from "react";
import { Button, Drawer, Form, Input, InputNumber, Typography } from "antd";
import GeneralModal from "@/components/reusable/Modal/GeneralModal/Modal";
import { PROGRAM_ICON } from "../Icons.Program";
import apiClient from "@/lib/apiClient";
import { StyledProgramSectionModal } from "../Styles.Program";
import HELPERS from "@/lib/helpers";
import { GLOBAL_CONSTANTS } from "@/constants";
import { ButtonInlineStyles } from "@/components/common/styles.common";
import { CloseOutlined } from "@ant-design/icons";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";

function getTitle(mode = "", id = "") {
  if (mode === "PROGRAM") {
    if (id) {
      return "Update program";
    }
    return "Add program";
  }
  if (id) {
    return "Update section";
  }
  return "Add section";
}

const ProgramSectionModal = ({
  id = "",
  mode = "",
  open = false,
  handleCancel = () => {},
  getListingData = () => {},
}: {
  id?: string,
  mode?: string,
  open?: boolean,
  handleCancel?: () => void,
  getListingData?: (flag: string) => void,
}) => {
  const [loading, setloading] = useState(false);
  const [details, setDetails] = useState<ProgramSectionTypes>();

  const isMobile = useIsSmallDevice();

  function resetForm() {
    if (!id) {
      setDetails({});
    }
  }

  async function getDetailsById() {
    if (!id) return;
    try {
      setloading(true);
      const res =
        mode === "PROGRAM"
          ? await apiClient.get(`/program/${id}`)
          : await apiClient.get(`/program/section/${id}`);
      setDetails(res?.data);
    } finally {
      setloading(false);
    }
  }

  async function handleSubmit() {
    if (!details?.name) {
      return HELPERS.messageAlert({ error: "Please provide name" });
    }
    if (mode === "PROGRAM") {
      if (!details?.levelOrder) {
        return HELPERS.messageAlert({ error: "Please provide level order" });
      }
    }
    try {
      setloading(true);
      if (!id) {
        await apiClient.post(
          mode === "PROGRAM" ? "/program" : "/program/section",
          details
        );
        HELPERS.messageAlert({
          success: "Added successfully",
        });
        resetForm();
      } else {
        await apiClient.put(
          mode === "PROGRAM" ? "/program" : "/program/section",
          details
        );
        HELPERS.messageAlert({
          success: "Updated successfully",
        });
      }
      getListingData(mode);
      handleCancel();
    } finally {
      setloading(false);
    }
  }

  function handleChange(value: string | number | null, key = "") {
    setDetails((prev) => {
      return {
        ...(prev || {}),
        [key]: value,
      };
    });
  }

  useEffect(() => {
    getDetailsById();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  function getBody() {
    return (
      <StyledProgramSectionModal>
        <Form.Item label="Name" labelCol={{ span: 24 }} required>
          <Input
            type={"text"}
            value={details?.name}
            onChange={(e) => handleChange(e.target.value, "name")}
          />
        </Form.Item>
        {mode === "PROGRAM" && (
          <Form.Item
            label="Level"
            labelCol={{ span: 24 }}
            required
            help="Internal ordering (Level 1 is earliest). Level increases as class progresses."
          >
            <InputNumber
              value={details?.levelOrder}
              onChange={(val) => handleChange(val, "levelOrder")}
              style={{
                width: "100%",
              }}
            />
          </Form.Item>
        )}
      </StyledProgramSectionModal>
    )
  }

  if (isMobile) {
    return (
      <Drawer
        onClose={handleCancel}
        open={open}
        placement="bottom"
        height={"65%"}
        closable={false}
        style={{
          borderTopLeftRadius:
            GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.BORDER_RADIUS,
          borderTopRightRadius:
            GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.BORDER_RADIUS,
        }}
        footer={
          <div className="flex items-center justify-center gap-2">
            <Button
              style={ButtonInlineStyles}
              block
              onClick={handleCancel}
            >
              Cancel
            </Button>
            <Button
              type="primary"
              style={ButtonInlineStyles}
              block
              onClick={handleSubmit}
              disabled={loading}
            >
              {id ? "Update" : "Add"}
            </Button>
          </div>
        }
        title={
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <PROGRAM_ICON />
              <Typography.Title level={5}>{getTitle(mode, id)}</Typography.Title>
            </div>
            <Button onClick={handleCancel} shape="circle">
              <CloseOutlined />
            </Button>
          </div>
        }
      >
       {getBody()}
      </Drawer>
    )
  }

  return (
    <GeneralModal
      open={open}
      onCancel={handleCancel}
      customTitle={getTitle(mode, id)}
      titleIcon={<PROGRAM_ICON />}
      footer={[
        <Button key="cancel" onClick={handleCancel}>
          Cancel
        </Button>,
        <Button
          type="primary"
          key="create"
          onClick={handleSubmit}
          disabled={loading}
        >
          {id ? "Update" : "Add"}
        </Button>,
      ]}
    >
      {getBody()}
    </GeneralModal>
  );
};

export default ProgramSectionModal;
