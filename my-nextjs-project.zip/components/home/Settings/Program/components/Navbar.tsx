"use client";

import { useState } from "react";
import { Button, theme, Typography } from "antd";
import { AiOutlinePlus } from "react-icons/ai";
import { StyledNavbar } from "../Styles.Program";
import ProgramSectionModal from "./ProgramSectionModal";
import { SideMenuIcons } from "@/components/home/Sidebar/Icons";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";

const Navbar = ({
  mode = "PROGRAM",
  getListingData = () => {},
}: {
  mode?: string;
  getListingData?: () => void;
}) => {
  const { token } = theme.useToken();

  const isMobile = useIsSmallDevice();

  const [openModal, setOpenModal] = useState(false);

  return (
    <StyledNavbar token = {token}>
      <div className="flex-col gap-1.5">
        <div className="flex items-center gap-1.5">
          {SideMenuIcons.SETTINGS()}
          <Typography.Paragraph>Settings</Typography.Paragraph>
        </div>
        <Typography.Title level={isMobile ? 5 : 3}>Program & section</Typography.Title>
      </div>
      <Button
        type="primary"
        icon={<AiOutlinePlus />}
        onClick={() => setOpenModal(true)}
      >
        New {mode === "PROGRAM" ? "Program" : "Section"}
      </Button>
      <ProgramSectionModal
        mode={mode}
        open={openModal}
        handleCancel={() => setOpenModal(false)}
        getListingData={getListingData}
      />
    </StyledNavbar>
  );
};

export default Navbar;
