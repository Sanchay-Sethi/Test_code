"use client"

import { HiOutlinePencil } from "react-icons/hi";
import { useMemo, useState } from "react";
import { AiOutlineInfoCircle } from "react-icons/ai";
import { Button, Table, theme, Tooltip } from "antd";
import { StyledProgramListingTable } from "../Styles.Program";
import ProgramSectionModal from "./ProgramSectionModal";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";
import GeneralSkeleton from "@/components/reusable/Loader/Skeleton/GeneralSkeleton";
import { GENERAL_COMPONENTS } from "@/components/common";
import VirtualSwiper from "@/components/reusable/Swiper/virtual/VirtualVerticalSwiper";
import { ProgramMobileCard } from "@/components/reusable/cards/GeneralCards";

const ProgramListingTable = ({
  loading = false,
  mode = "PROGRAM",
  data = [],
  getListingData = () => {},
} : {
  loading?: boolean;
  mode?: string;
  data?: ProgramSectionTypes[];
  getListingData?: () => void;
}) => {
  const { token } = theme.useToken();
  const [activeId, setActiveId] = useState("");

  const isMobile = useIsSmallDevice();

  function handleEdit(id = "") {
    setActiveId(id);
  }

  const columns = useMemo(
    () => [
      {
        title: "Name",
        dataIndex: "name",
        ellipsis: true,
        // width: 250
      },
      ...(mode === "PROGRAM"
        ? [
            {
              title: (
                <div className="flex items-center gap-1.5">
                  LEVEL{" "}
                  <Tooltip title="Internal ordering (Level 1 is earliest) Level increases as class progresses.">
                    <AiOutlineInfoCircle />
                  </Tooltip>
                </div>
              ),
              dataIndex: "levelOrder",
              ellipsis: true,
            },
          ]
        : []),

      {
        title: "Action",
        dataIndex: "id",
        ellipsis: true,
        render: (id = "") => {
          return (
            <div className="flex items-center gap-1.5">
              <Button
                type="text"
                icon={<HiOutlinePencil />}
                color="primary"
                variant="filled"
                onClick={() => handleEdit(id)}
              >
                Edit
              </Button>
            </div>
          );
        },
      },
    ],
    [mode]
  );

  return (
    <StyledProgramListingTable token={token}>
      {
        isMobile ? (
          <>
            {loading ? (
              <GeneralSkeleton
                countSmall={0}
                countLarge={10}
                isLargeWrapped
                largeBoxHeight={100}
              />
            ) : data?.length === 0 && !loading ? (
              <GENERAL_COMPONENTS.NoResult />
            ) : (
              <VirtualSwiper
                items={data || []}
                getKey={(program) => program?.id || ""}
                cardEstimateWidth={mode === "SECTION" ? 70 : 100}
                containerHeight={"calc(-194px + 100vh)"}
                renderItem={(data) => (
                  <ProgramMobileCard
                    data={data}
                    onEdit={() => handleEdit(data?.id)}
                  />
                )}
              />
            )}
          </>
        )
        :
      <Table
        loading={loading}
        dataSource={data}
        columns={columns}
        scroll={{ y: 90 * 5 }}
      />
      }
      <ProgramSectionModal
        id={activeId}
        mode={mode}
        open={!!activeId}
        handleCancel={() => setActiveId("")}
        getListingData={getListingData}
      />
    </StyledProgramListingTable>
  );
};

export default ProgramListingTable;
