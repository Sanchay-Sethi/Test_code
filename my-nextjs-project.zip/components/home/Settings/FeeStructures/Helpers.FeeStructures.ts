export function calculateTotalAmount(items: { amount?: number }[]) {
    return items?.reduce((total, item) => total + (item?.amount || 0), 0);
}