interface FeeStructureData {
    id?: string,
    type?: string,
    planName?: string,
    name?: string,
    branchIdNameMap?: {
        [key: string] : string
    },
    totalAmount?: number,
    value?: number,
}

interface feeItemType {
    id?: string,
    feeId?: string,
    name?: string,
    amount?: number,
    dueDate?: string,
    createdAt?: string,
    updatedAt?: string,
}

interface FeeDataTypes {
    id?: string,
    academicYearId?: string,
    type?: string,
    planId?: string,
    createdAt?: string,
    updatedAt?: string,
    branchIds?: string[],
    feeItems?: feeItemType[],
    totalAmount?: number,
}


interface OptionsTypes {
  name?: string;
  label?: string;
  id?: string;
  value?: string;
}

interface FeePlanTypes {
    id?: string;
    name?: string;
    description?: string;
    type?: string;
}

interface DiscountDataTypes {
    id?: string;
    name?: string;
    academicYearId?: string;
    type?: string;
    branchIds?: string[];
    value?: number;
}