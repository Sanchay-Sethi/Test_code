"use client";

import { Select, Skeleton, theme, Typography } from "antd";
import { useSearchParams } from "next/navigation";
import { SideMenuIcons } from "@/components/home/Sidebar/Icons";
import { useGlobalValues } from "@/lib/hooks/useGlobalValues";
import { useNavigation } from "@/lib/context/NavigationContext";
import { GENERAL_COMPONENTS } from "@/components/common";
import { RightArrow } from "@/components/home/Fee/Icons";
import { StyledNavbar } from "../Styles.FeeStructures";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";

const MODE_NAMES = {
  PROGRAM: "Program",
  ADMISSION: "Admission",
  TRANSPORT: "Transport",
  HOSTEL: "Hostel",
  DISCOUNT: "Discount",
};

const Navbar = ({
  isEdit = false,
  mode = "",
  loading = false,
  title = "",
}: {
  isEdit?: boolean;
  mode?: string;
  loading?: boolean;
  title?: string;
}) => {
  const searchParams = useSearchParams();
  const { navigate } = useNavigation();
  const { ACADEMIC_YEAR_OPTIONS, CURRENT_ACADEMIC_YEAR } = useGlobalValues();

  const {token} = theme.useToken();
  const isMobile = useIsSmallDevice();

  const academicYearId =
    searchParams.get("academicYearId") || CURRENT_ACADEMIC_YEAR;

  function handleAcadmicYearChange(val: string) {
    const params = new URLSearchParams(searchParams.toString());
    if (val) {
      params.set("academicYearId", val);
    } else {
      params.delete("academicYearId");
    }
    navigate(`?${params.toString()}`);
  }

  if (isEdit) {
    return (
      <StyledNavbar token = {token}>
        <div className="flex items-center gap-5">
          <GENERAL_COMPONENTS.BackButton backUrl={`/settings/fee-structures?mode=${mode}`}/>
          <div className="flex-col gap-1.5">
            <div className="flex items-center gap-1.5">
              {SideMenuIcons.SETTINGS()}
              <Typography.Paragraph className="flex items-center gap-1.5">
                Fee structures <RightArrow />{" "}
                {MODE_NAMES?.[mode as keyof typeof MODE_NAMES]}
              </Typography.Paragraph>
            </div>
            {loading ? (
              <Skeleton.Input active={true} size={"small"} />
            ) : (
              <Typography.Title level={isMobile ? 5 : 2}>
                {title ||
                  `New ${MODE_NAMES?.[mode as keyof typeof MODE_NAMES]}`}
              </Typography.Title>
            )}
          </div>
        </div>
      </StyledNavbar>
    );
  }

  return (
    <StyledNavbar token = {token}>
      <div className="flex-col gap-1.5">
        <div className="flex items-center gap-1.5">
          {SideMenuIcons.SETTINGS()}
          <Typography.Paragraph>Settings</Typography.Paragraph>
        </div>
        <Typography.Title level={isMobile ? 5 : 3}>Fee structures</Typography.Title>
      </div>
      <div className="nav-studentlist-actions">
        {
          !isMobile &&
        <Typography.Paragraph>Academic year</Typography.Paragraph>
        }
        <Select
          style={{ width: 120 }}
          value={academicYearId}
          onChange={handleAcadmicYearChange}
          options={ACADEMIC_YEAR_OPTIONS}
        />
      </div>
    </StyledNavbar>
  );
};

export default Navbar;
