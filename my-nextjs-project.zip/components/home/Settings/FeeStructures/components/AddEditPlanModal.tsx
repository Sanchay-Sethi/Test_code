"use client";

import { SideMenuIcons } from "@/components/home/Sidebar/Icons";
import GeneralModal from "@/components/reusable/Modal/GeneralModal/Modal";
import HELPERS from "@/lib/helpers";
import { Button, Drawer, Form, Input, Select, Typography } from "antd";
import { useEffect, useState } from "react";
import { StyledProgramSectionModal } from "../../Program/Styles.Program";
import TextArea from "antd/es/input/TextArea";
import apiClient from "@/lib/apiClient";
import { GLOBAL_CONSTANTS } from "@/constants";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";
import { ButtonInlineStyles } from "@/components/common/styles.common";
import { CloseOutlined } from "@ant-design/icons";

function getTitle(mode = "", id = "") {
  return `${id ? "Update" : "Add"} ${mode ? mode?.toLowerCase() : "plan"}`;
}

const AddEditPlanModal = ({
  id = "",
  open = false,
  mode = "",
  showTypeDropdown = false,
  onCancel = () => {},
  taskAfterSubmit = () => {},
}: {
  id?: string;
  open?: boolean;
  showTypeDropdown?: boolean;
  mode?: string;
  onCancel?: () => void;
  taskAfterSubmit?: () => void;
}) => {
  const [loading, setLoading] = useState(false);
  const [details, setDetails] = useState<FeePlanTypes>();

  const isMobile = useIsSmallDevice();

  function handleCancel() {
    setDetails({});
    setLoading(false);
    onCancel();
  }

  async function handleSubmit() {
    if (!details?.name) {
      return HELPERS.messageAlert({ error: "Please provide name" });
    }
    try {
      setLoading(true);
      const body = {
        ...(details || {}),
        type: details?.type || mode,
      };
      if (id) {
        await apiClient.put("fee/plan", body);
        HELPERS.messageAlert({ success: "Updated successfully" });
      } else {
        await apiClient.post("fee/plan", body);
        HELPERS.messageAlert({ success: "Added successfully" });
      }
      taskAfterSubmit();
    } finally {
      setLoading(false);
    }
  }

  function handleChange(value: string | number | null, key = "") {
    setDetails((prev) => {
      return {
        ...(prev || {}),
        [key]: value,
      };
    });
  }

  async function getDetails() {
    if (!id) return;
    try {
      setLoading(true);
      const res = await apiClient.get(`/fee/plan/${id}`);
      setDetails(res?.data);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    getDetails();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  function getBody() {
    return (
      <StyledProgramSectionModal>
        <Form.Item label="Name" labelCol={{ span: 24 }} required>
          <Input
            type={"text"}
            value={details?.name}
            onChange={(e) => handleChange(e.target.value, "name")}
          />
        </Form.Item>
        {showTypeDropdown && (
          <Form.Item label="Plan type" labelCol={{ span: 24 }} required>
            <Select
              value={details?.type}
              onChange={(val) => handleChange(val, "type")}
              options={GLOBAL_CONSTANTS.FEE_TYPES_OPTIONS}
            />
          </Form.Item>
        )}
        <Form.Item label="Description" labelCol={{ span: 24 }}>
          <TextArea
            value={details?.description}
            onChange={(e) => handleChange(e.target.value, "description")}
          />
        </Form.Item>
      </StyledProgramSectionModal>
    );
  }

  if (isMobile) {
    return (
      <Drawer
        onClose={handleCancel}
        open={open}
        placement="bottom"
        height={"65%"}
        closable={false}
        style={{
          borderTopLeftRadius:
            GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.BORDER_RADIUS,
          borderTopRightRadius:
            GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.BORDER_RADIUS,
        }}
        footer={
          <div className="flex items-center justify-center gap-2">
            <Button style={ButtonInlineStyles} block onClick={handleCancel}>
              Cancel
            </Button>
            <Button
              type="primary"
              style={ButtonInlineStyles}
              block
              onClick={handleSubmit}
              disabled={loading}
            >
              {id ? "Update" : "Add"}
            </Button>
          </div>
        }
        title={
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              {SideMenuIcons.SETTINGS()}
              <Typography.Title level={5}>
                {getTitle(mode, id)}
              </Typography.Title>
            </div>
            <Button onClick={handleCancel} shape="circle">
              <CloseOutlined />
            </Button>
          </div>
        }
      >
        {getBody()}
      </Drawer>
    );
  }

  return (
    <GeneralModal
      open={open}
      onCancel={handleCancel}
      customTitle={getTitle(mode, id)}
      titleIcon={SideMenuIcons.SETTINGS()}
      footer={[
        <Button key="cancel" onClick={handleCancel}>
          Cancel
        </Button>,
        <Button
          type="primary"
          key="create"
          onClick={handleSubmit}
          disabled={loading}
        >
          {id ? "Update" : "Add"}
        </Button>,
      ]}
    >
      {getBody()}
    </GeneralModal>
  );
};

export default AddEditPlanModal;
