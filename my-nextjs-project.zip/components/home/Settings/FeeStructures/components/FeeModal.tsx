"use client";

import {
  Button,
  Drawer,
  Form,
  Input,
  InputNumber,
  Select,
  Typography,
} from "antd";
import { SideMenuIcons } from "@/components/home/Sidebar/Icons";
import GeneralModal from "@/components/reusable/Modal/GeneralModal/Modal";
import HELPERS from "@/lib/helpers";
import { useEffect, useState } from "react";
import { StyledProgramSectionModal } from "../../Program/Styles.Program";
import apiClient from "@/lib/apiClient";
import { useGlobalValues } from "@/lib/hooks/useGlobalValues";
import MultiSelectWithSelectAll from "@/components/reusable/DynamicSelect/MultiSelectWithSelectAll";
import { GLOBAL_CONSTANTS } from "@/constants";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";
import { ButtonInlineStyles } from "@/components/common/styles.common";
import { CloseOutlined } from "@ant-design/icons";

function getTitle(mode = "", id = "") {
  return `${id ? "Update" : "Add"} ${mode?.toLowerCase()}`;
}

const FeeModal = ({
  id = "",
  open = false,
  mode = "",
  academicYearId = "",
  onCancel = () => {},
  taskAfterSubmit = () => {},
}: {
  id?: string;
  open?: boolean;
  mode?: string;
  academicYearId?: string;
  onCancel?: () => void;
  taskAfterSubmit?: () => void;
}) => {
  const { CURRENT_ACADEMIC_YEAR, BRANCHES_OPTIONS } = useGlobalValues();
  const [loading, setLoading] = useState(false);
  const [details, setDetails] = useState<DiscountDataTypes>();

  const isMobile = useIsSmallDevice();

  function handleCancel() {
    setLoading(false);
    setDetails({});
    onCancel();
  }

  async function handleSubmit() {
    if (!details?.name) {
      return HELPERS.messageAlert({ error: "Please provide name" });
    }
    if (!details?.branchIds && details?.branchIds?.length === 0) {
      return HELPERS.messageAlert({
        error: "Please select alteast one branch",
      });
    }
    if (!details?.value) {
      return HELPERS.messageAlert({ error: "Please add discount percentage" });
    }
    if (!details?.type) {
      return HELPERS.messageAlert({ error: "Please select fee type" });
    }
    try {
      setLoading(true);
      const body = {
        ...(details || {}),
        academicYearId: academicYearId || CURRENT_ACADEMIC_YEAR,
      };
      if (id) {
        await apiClient.put("/fee/discount", body);
        HELPERS.messageAlert({ success: "Updated successfully" });
      } else {
        await apiClient.post("/fee/discount", body);
        HELPERS.messageAlert({ success: "Added successfully" });
      }
      taskAfterSubmit();
    } finally {
      setLoading(false);
    }
  }

  function handleChange(value: string | number | string[] | null, key = "") {
    setDetails((prev) => {
      return {
        ...(prev || {}),
        [key]: value,
      };
    });
  }

  async function getDetails() {
    if (!id) return;
    if (mode === "DISCOUNT") {
      try {
        setLoading(true);
        const res = await apiClient.get(`/fee//discount/${id}`);
        setDetails(res?.data);
      } finally {
        setLoading(false);
      }
    }
  }

  useEffect(() => {
    getDetails();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  function getBody() {
    return (
      <StyledProgramSectionModal>
        <Form.Item label="Discount name" labelCol={{ span: 24 }} required>
          <Input
            value={details?.name}
            onChange={(e) => handleChange(e.target.value, "name")}
          />
        </Form.Item>
        <Form.Item label="Branches" labelCol={{ span: 24 }} required>
          <MultiSelectWithSelectAll
            value={details?.branchIds || []}
            options={BRANCHES_OPTIONS || []}
            onChange={(val) => handleChange(val, "branchIds")}
            style={{
              width: "100%",
            }}
          />
        </Form.Item>
        <Form.Item label="Fee type" labelCol={{ span: 24 }} required>
          <Select
            value={details?.type}
            onChange={(val) => handleChange(val, "type")}
            options={GLOBAL_CONSTANTS.FEE_TYPES_OPTIONS}
          />
        </Form.Item>
        <Form.Item label="Percentage (%)" labelCol={{ span: 24 }} required>
          <InputNumber
            value={details?.value}
            suffix="%"
            onChange={(val) => handleChange(val, "value")}
            style={{ width: "100%" }}
          />
        </Form.Item>
      </StyledProgramSectionModal>
    );
  }

  if (isMobile) {
    return (
      <Drawer
        onClose={handleCancel}
        open={open}
        placement="bottom"
        height={"85%"}
        closable={false}
        style={{
          borderTopLeftRadius:
            GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.BORDER_RADIUS,
          borderTopRightRadius:
            GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.BORDER_RADIUS,
        }}
        footer={
          <div className="flex items-center justify-center gap-2">
            <Button style={ButtonInlineStyles} block onClick={handleCancel}>
              Cancel
            </Button>
            <Button
              type="primary"
              style={ButtonInlineStyles}
              block
              onClick={handleSubmit}
              disabled={loading}
            >
              {id ? "Update" : "Add"}
            </Button>
          </div>
        }
        title={
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              {SideMenuIcons.SETTINGS()}
              <Typography.Title level={5}>
                {getTitle(mode, id)}
              </Typography.Title>
            </div>
            <Button onClick={handleCancel} shape="circle">
              <CloseOutlined />
            </Button>
          </div>
        }
      >
        {getBody()}
      </Drawer>
    );
  }

  return (
    <GeneralModal
      open={open}
      onCancel={handleCancel}
      customTitle={getTitle(mode, id)}
      titleIcon={SideMenuIcons.SETTINGS()}
      footer={[
        <Button key="cancel" onClick={handleCancel}>
          Cancel
        </Button>,
        <Button
          type="primary"
          key="create"
          onClick={handleSubmit}
          disabled={loading}
        >
          {id ? "Update" : "Add"}
        </Button>,
      ]}
    >
      {getBody()}
    </GeneralModal>
  );
};

export default FeeModal;
