import { Button } from "antd";
import { AiOutlinePlus } from "react-icons/ai";
import { GLOBAL_CONSTANTS } from "@/constants";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";

const CreateButton = ({
  mode = "",
  onClick = () => {},
}: {
  mode: string;
  onClick: (mode: string) => void;
}) => {

  const isMobile = useIsSmallDevice();

  return (
    <Button
      type="primary"
      icon={<AiOutlinePlus />}
      onClick={() => onClick(mode)}
      block={!!isMobile}
    >
      {
        GLOBAL_CONSTANTS.FEE_TYPES?.[
          mode as keyof typeof GLOBAL_CONSTANTS.FEE_TYPES
        ]
      }
    </Button>
  );
};

export default CreateButton;
