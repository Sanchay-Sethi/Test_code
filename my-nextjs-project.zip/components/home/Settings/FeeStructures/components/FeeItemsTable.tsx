"use client";

import {
  Table,
  Input,
  DatePicker,
  InputNumber,
  Button,
  Popconfirm,
  Tooltip,
  theme,
  TableColumnsType,
} from "antd";
import { CheckOutlined, CloseOutlined, PlusOutlined } from "@ant-design/icons";
import dayjs from "dayjs";
import { useEffect, useState } from "react";
import { HiOutlinePencil } from "react-icons/hi";
import { BiTrashAlt } from "react-icons/bi";
import { StyledFeeItemsTable } from "../Styles.FeeStructures";
import { calculateTotalAmount } from "../Helpers.FeeStructures";
import VirtualSwiper from "@/components/reusable/Swiper/virtual/VirtualVerticalSwiper";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";
import { FeeItemCard } from "@/components/reusable/cards/GeneralCards";

const FeeItemsTable = ({
  value = [],
  onChange,
}: {
  value?: feeItemType[];
  onChange?: (items: feeItemType[]) => void;
}) => {
  const { token } = theme.useToken();
  const isMobile = useIsSmallDevice();

  const [feeItems, setFeeItems] = useState<feeItemType[]>(value || []);
  const [editingKey, setEditingKey] = useState<string | null>(null);
  const [newItem, setNewItem] = useState<boolean>(false);
  const [editableRow, setEditableRow] = useState<feeItemType | null>(null);
  const [errors, setErrors] = useState<
    Partial<Record<keyof feeItemType, string>>
  >({});

  const isEditing = (record: feeItemType) =>
    editingKey !== null && record.id === editingKey;

  const handleAdd = () => {
    if (editingKey) return;
    const newRow: feeItemType = {
      id: `${Date.now()}_new`,
      name: "",
      dueDate: dayjs().format("YYYY-MM-DD"),
      amount: undefined,
    };
    setFeeItems([...feeItems, newRow]);
    setEditableRow(newRow);
    setEditingKey(newRow.id!);
    setNewItem(true);
  };

  const handleEdit = (record: feeItemType) => {
    setEditableRow({ ...record });
    setEditingKey(record.id!);
    setNewItem(false);
    setErrors({});
  };

  const handleDelete = (id: string) => {
    const updated = feeItems?.filter((item) => item.id !== id);
    setFeeItems(updated);
    onChange?.(updated);
  };

  const handleSave = () => {
    const errs: typeof errors = {};
    if (!editableRow?.name?.trim()) errs.name = "Please enter a name.";
    if (!editableRow?.dueDate) errs.dueDate = "Please select a due date.";
    if (editableRow?.amount == null || editableRow.amount < 0)
      errs.amount = "Please enter a valid amount.";

    if (Object.keys(errs).length > 0) {
      setErrors(errs);
      return;
    }

    const updated = [...feeItems];
    const index = updated.findIndex((item) => item.id === editableRow?.id);

    if (index > -1 && editableRow) {
      updated[index] = editableRow;
    }

    setFeeItems(updated);
    onChange?.(updated);
    setEditingKey(null);
    setEditableRow(null);
    setNewItem(false);
    setErrors({});
  };

  const handleCancel = () => {
    if (newItem && editableRow?.id) {
      setFeeItems(feeItems?.filter((item) => item.id !== editableRow.id));
    }
    setEditingKey(null);
    setEditableRow(null);
    setNewItem(false);
    setErrors({});
  };

  const columns: TableColumnsType<feeItemType> = [
    {
      title: "Fee Items",
      dataIndex: "name",
      width: 300,
      render: (_: unknown, record: feeItemType) =>
        isEditing(record) ? (
          <div className="flex-col items-start w-full">
            <Input
              value={editableRow?.name}
              placeholder="eg. Term x fee"
              onChange={(e) => {
                setErrors((prev) => ({ ...prev, name: "" }));
                setEditableRow((prev) => ({ ...prev!, name: e.target.value }));
              }}
              status={errors?.name ? "error" : ""}
            />
            <div style={{ color: "red", fontSize: 12, height: 15 }}>
              {errors.name}
            </div>
          </div>
        ) : (
          record.name
        ),
    },
    {
      title: "Due Dates",
      dataIndex: "dueDate",
      width: 250,
      render: (_: unknown, record: feeItemType) =>
        isEditing(record) ? (
          <div className="flex-col items-start w-full">
            <DatePicker
              value={
                editableRow?.dueDate ? dayjs(editableRow?.dueDate) : undefined
              }
              format="MMM D, YYYY"
              onChange={(date, dateStr) => {
                setErrors((prev) => ({ ...prev, dueDate: "" }));
                setEditableRow((prev) => ({
                  ...prev!,
                  dueDate:
                    typeof dateStr === "string" ? dateStr : dateStr[0] || "",
                }));
              }}
              style={{
                width: "100%",
              }}
              status={errors?.dueDate ? "error" : ""}
            />
            <div style={{ color: "red", fontSize: 12, height: 15 }}>
              {errors?.dueDate}
            </div>
          </div>
        ) : (
          dayjs(record?.dueDate).format("MMM D, YYYY")
        ),
    },
    {
      title: "Fee",
      dataIndex: "amount",
      width: 200,
      render: (_: unknown, record: feeItemType) =>
        isEditing(record) ? (
          <div className="flex-col items-start w-full">
            <InputNumber
              min={0}
              value={editableRow?.amount}
              placeholder="Rs. XXXX"
              onChange={(val) => {
                setErrors((prev) => ({ ...prev, amount: "" }));
                setEditableRow((prev) => ({
                  ...prev!,
                  amount: val === null ? undefined : val,
                }));
              }}
              status={errors?.amount ? "error" : ""}
              style={{ width: "100%" }}
            />
            <div style={{ color: "red", fontSize: 12, height: 15 }}>
              {errors?.amount}
            </div>
          </div>
        ) : (
          `Rs ${record.amount?.toLocaleString()}`
        ),
    },
    {
      title: "Actions",
      width: 300,
      // fixed: "right",
      render: (_: unknown, record: feeItemType) => {
        const editable = isEditing(record);
        return editable ? (
          <div className="flex items-center gap-4 mb-4">
            <Tooltip title="Confirm">
              <Button
                type="text"
                color="green"
                variant="outlined"
                onClick={handleSave}
                icon={<CheckOutlined />}
                shape={"circle"}
                size="small"
              />
            </Tooltip>
            <Tooltip title="Cancel">
              <Button
                type="text"
                color={"danger"}
                variant="outlined"
                onClick={handleCancel}
                icon={<CloseOutlined />}
                shape={"circle"}
                size="small"
              />
            </Tooltip>
          </div>
        ) : (
          <div className="flex items-center gap-2">
            <Button
              type="text"
              icon={<HiOutlinePencil />}
              color="primary"
              variant="filled"
              onClick={() => handleEdit(record)}
              disabled={!!editingKey}
            >
              Edit
            </Button>
            {record.id && (
              <Popconfirm
                title="Delete fee item"
                description="Are you sure to delete this item?"
                onConfirm={() => handleDelete(record.id!)}
                okText="Yes"
                cancelText="No"
                disabled={!!editingKey}
              >
                <Button
                  type="text"
                  icon={<BiTrashAlt />}
                  color="danger"
                  variant="filled"
                  disabled={!!editingKey}
                >
                  Delete
                </Button>
              </Popconfirm>
            )}
          </div>
        );
      },
    },
  ];

  useEffect(() => {
    setFeeItems(value);
  }, [value]);

  if (isMobile) {
    return (
      <>
        {feeItems?.length === 0 ? (
          <div className="flex flex-col items-center justify-center gap-3 p-6">
            <Button
              onClick={handleAdd}
              icon={<PlusOutlined />}
              color="primary"
              variant="outlined"
            >
              Add fee item
            </Button>
          </div>
        ) : (
          <VirtualSwiper
            items={feeItems}
            getKey={(data) => data?.id || ""}
            containerHeight="calc(100vh - 415px)"
            cardEstimateWidth={130}
            renderItem={(data) => (
              <FeeItemCard
                data={data}
                isEditing={isEditing(data)}
                onSave={handleSave}
                onCancel={handleCancel}
                onEdit={() => handleEdit(data)}
                onDelete={() => handleDelete(data.id!)}
                editableRow={editableRow}
                onChange={(
                  key = "",
                  value: string | string[] | number | null
                ) => {
                  if (key === "dueDate") {
                    setErrors((prev) => ({ ...prev, dueDate: "" }));
                    setEditableRow((prev) => ({
                      ...prev!,
                      dueDate:
                        typeof value === "string"
                          ? value
                          : (Array.isArray(value) && value?.[0]) || "",
                    }));
                  } else if (key === "amount") {
                    setErrors((prev) => ({ ...prev, amount: "" }));
                    setEditableRow((prev) => ({
                      ...prev!,
                      amount: typeof value === "number" ? value : undefined,
                    }));
                  } else {
                    setErrors((prev) => ({ ...prev, [key]: "" }));
                    setEditableRow((prev) => ({ ...prev!, [key]: value }));
                  }
                }}
                errors={errors}
              />
            )}
          />
        )}
        {!editingKey && feeItems.length > 0 && (
          <Button
            onClick={handleAdd}
            icon={<PlusOutlined />}
            color="primary"
            variant="outlined"
          >
            New fee item
          </Button>
        )}
      </>
    );
  }

  return (
    <StyledFeeItemsTable token={token}>
      <Table
        dataSource={feeItems}
        columns={columns}
        rowKey="id"
        pagination={false}
        scroll={{ x: "max-content" }}
        rowClassName={(record) => (isEditing(record) ? "editable-row" : "")}
        summary={() => {
          return (
            <>
              {!editingKey && feeItems.length > 0 && (
                <Table.Summary.Row>
                  <Table.Summary.Cell index={0} colSpan={columns?.length || 4}>
                    <div className="add-new-item-button">
                      <Button
                        onClick={handleAdd}
                        icon={<PlusOutlined />}
                        color="primary"
                        variant="outlined"
                      >
                        New fee item
                      </Button>
                    </div>
                  </Table.Summary.Cell>
                </Table.Summary.Row>
              )}
              {feeItems.length > 0 && (
                <Table.Summary.Row>
                  <Table.Summary.Cell index={0} colSpan={2}>
                    <strong>Total</strong>
                  </Table.Summary.Cell>
                  <Table.Summary.Cell index={0} colSpan={2}>
                    <strong>
                      Rs.{" "}
                      {calculateTotalAmount(
                        feeItems as feeItemType[]
                      )?.toLocaleString()}
                    </strong>
                  </Table.Summary.Cell>
                </Table.Summary.Row>
              )}
            </>
          );
        }}
        locale={{
          emptyText: (
            <div className="flex flex-col items-center justify-center gap-3 p-6">
              <Button
                onClick={handleAdd}
                icon={<PlusOutlined />}
                color="primary"
                variant="outlined"
              >
                Add fee item
              </Button>
            </div>
          ),
        }}
      />
    </StyledFeeItemsTable>
  );
};

export default FeeItemsTable;
