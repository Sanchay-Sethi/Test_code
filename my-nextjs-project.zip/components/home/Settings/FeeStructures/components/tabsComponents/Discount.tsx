"use client"

import { useMemo } from "react";
import { Button, Popconfirm, Table, theme } from "antd";
import { StyledFeeStructureTable } from "../../Styles.FeeStructures";
import { HiOutlinePencil } from "react-icons/hi";
import { BiTrashAlt } from "react-icons/bi";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";
import GeneralSkeleton from "@/components/reusable/Loader/Skeleton/GeneralSkeleton";
import { GENERAL_COMPONENTS } from "@/components/common";
import VirtualSwiper from "@/components/reusable/Swiper/virtual/VirtualVerticalSwiper";
import { FeeStructureCard } from "@/components/reusable/cards/GeneralCards";

const Discount = ({
  loading = false,
  listingData = [],
  handleDelete = () => {},
  handleEdit = () => {},
}: {
  loading?: boolean;
  listingData: FeeStructureData[];
  handleDelete: (id: string) => void;
  handleEdit: (id: string) => void;
}) => {
  const { token } = theme.useToken();

  const isMobile = useIsSmallDevice();

  function handleAction(id = "", type = "") {
    if (type === "DELETE") {
      handleDelete(id);
    } else if (type === "EDIT") {
      handleEdit(id);
    }
  }

  const columns = useMemo(
    () => [
      {
        title: "Discount name",
        dataIndex: "name",
        ellipsis: true,
      },
      {
        title: "Fee type",
        dataIndex: "type",
        ellipsis: true,
      },
      {
        title: "Branches",
        dataIndex: "branchIdNameMap",
        ellipsis: true,
        render: (branchIdNameMap: { [key: string]: string }) => {
          return Object?.values(branchIdNameMap || {})?.join(", ");
        },
      },
      {
        title: "Percentage",
        dataIndex: "value",
        ellipsis: true,
        render: (value: number) => {
          return `${value} %`;
        },
      },
      {
        title: "Action",
        dataIndex: "id",
        ellipsis: true,
        render: (id = "") => {
          return (
            <div className="flex items-center gap-2">
              <Button
                type="text"
                icon={<HiOutlinePencil />}
                color="primary"
                variant="filled"
                onClick={() => handleAction(id, "EDIT")}
              >
                Edit
              </Button>
              <Popconfirm
                title="Delete discount"
                description="Are you sure to delete this discount?"
                onConfirm={() => handleAction(id, "DELETE")}
                okText="Yes"
                cancelText="No"
              >
                <Button
                  type="text"
                  icon={<BiTrashAlt />}
                  color="danger"
                  variant="filled"
                >
                  Delete
                </Button>
              </Popconfirm>
            </div>
          );
        },
      },
    ],
    // eslint-disable-next-line react-hooks/exhaustive-deps
    []
  );

  if (isMobile) {
    return (
      <>
        {loading ? (
          <GeneralSkeleton
            countSmall={0}
            countLarge={10}
            isLargeWrapped
            largeBoxHeight={100}
          />
        ) : listingData?.length === 0 && !loading ? (
          <GENERAL_COMPONENTS.NoResult />
        ) : (
          <VirtualSwiper
            items={listingData || []}
            getKey={(data) => data?.id || ""}
            cardEstimateWidth={125}
            containerHeight={"calc(100vh - 240px)"}
            renderItem={(data) => (
              <FeeStructureCard
                data={data}
                onEdit={() => handleAction(data?.id, "EDIT")}
                onDelete={() => handleAction(data?.id, "DELETE")}
                isDiscount
              />
            )}
          />
        )}
      </>
    );
  }

  return (
    <StyledFeeStructureTable token={token}>
      <Table
        dataSource={listingData}
        columns={columns}
        loading={loading}
        scroll={{ y: 100 * 5 }}
      />
    </StyledFeeStructureTable>
  );
};

export default Discount;
