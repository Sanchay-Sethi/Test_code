"use client";

import { useEffect, useRef, useState } from "react";
import { StyledEditFeePlan } from "../Styles.FeeStructures";
import {
  DESC_EDIT_ICON,
  ROLE_EDIT_ICON,
} from "../../UserRoles/Icons.UserRoles";
import { Button, Divider, Select, Space, theme, Typography } from "antd";
import { CheckOutlined, PlusOutlined } from "@ant-design/icons";
import HELPERS from "@/lib/helpers";
import MultiSelectWithSelectAll from "@/components/reusable/DynamicSelect/MultiSelectWithSelectAll";
import { useGlobalValues } from "@/lib/hooks/useGlobalValues";
import { ButtonInlineStyles, StyledMobileSpacedFancyContainer } from "@/components/common/styles.common";
import { useNavigation } from "@/lib/context/NavigationContext";
import FeeItemsTable from "./FeeItemsTable";
import { cloneDeep } from "lodash";
import apiClient from "@/lib/apiClient";
import { calculateTotalAmount } from "../Helpers.FeeStructures";
import AddEditPlanModal from "./AddEditPlanModal";

function updateFeeItems(feeItems: feeItemType[] = []) {
  return feeItems?.map((item) => {
    if (item?.id?.includes("_new")) {
      // eslint-disable-next-line @typescript-eslint/no-unused-vars
      const { id, ...rest } = item;
      return rest;
    }
    return item;
  });
}

const EditFeePlan = ({
  id = "",
  mode = "",
  plans = [],
  planLoading = false,
  feeData = {},
  updateTableData = () => {},
  getPlans = () => {},
}: {
  id?: string;
  mode?: string;
  plans?: OptionsTypes[];
  planLoading?: boolean;
  feeData?: FeeDataTypes;
  updateTableData?: () => void;
  getPlans?: () => void;
}) => {
  const { CURRENT_ACADEMIC_YEAR } = useGlobalValues();
  const { token } = theme.useToken();
  const { navigate } = useNavigation();
  const { BRANCHES_OPTIONS } = useGlobalValues();

  const initializedRef = useRef(false);

  const [editableFeeData, setEditableFeeData] = useState<FeeDataTypes>();
  const [inputChange, setInputChange] = useState(false);
  const [loading, setLoading] = useState(false);
  const [addPlanModal, setAddPlanModal] = useState(false);

  function handleModalCancel() {
    setAddPlanModal(false);
  }

  function handleChange(
    value: string | string[] | boolean | feeItemType[] | null,
    key = ""
  ) {
    setInputChange(true);
    setEditableFeeData((prev) => {
      return {
        ...(prev || {}),
        [key]: value,
      };
    });
  }

  function handleCancel() {
    navigate(`/settings/fee-structures?mode=${mode}`);
  }

  async function handleSubmit() {
    let clonedEditableFeeData = cloneDeep(editableFeeData || {});
    if (!editableFeeData?.planId) {
      return HELPERS.messageAlert({ error: "Please select plan" });
    }
    if (
      !editableFeeData?.branchIds ||
      editableFeeData?.branchIds?.length === 0
    ) {
      return HELPERS.messageAlert({
        error: "Please select atleast one branch",
      });
    }
    const feeItems = updateFeeItems(editableFeeData?.feeItems);
    clonedEditableFeeData = {
      ...(clonedEditableFeeData || {}),
      feeItems,
      type: mode,
      academicYearId: CURRENT_ACADEMIC_YEAR,
      totalAmount: calculateTotalAmount(feeItems as feeItemType[]),
    };

    try {
      setLoading(true);
      if (!id) {
        const res = await apiClient.post("/fee", clonedEditableFeeData);
        HELPERS.messageAlert({ success: "Created successfully" });
        navigate(`/settings/fee-structures/${mode}/${res?.data?.id}`);
      } else {
        await apiClient.put("/fee", clonedEditableFeeData);
        HELPERS.messageAlert({ success: "Updated successfully" });
        updateTableData();
      }
    } finally {
      setInputChange(false);
      setLoading(false);
    }
  }

  function handleTaskAfterSubmit() {
    setAddPlanModal(false);
    getPlans();
  }

  useEffect(() => {
    if (feeData && !initializedRef.current) {
      setEditableFeeData(feeData);
      initializedRef.current = true;
    }
  }, [feeData]);

  return (
    <StyledMobileSpacedFancyContainer token={token} height="calc(100vh - 182px)">
      <StyledEditFeePlan token={token}>
        <div className="role-title-description">
          <div className="single-t-d-container">
            <div className="icon-title-wrapper">
              <div className="edit-icon-container">
                <ROLE_EDIT_ICON />
              </div>
              <p className="role-title">Plan</p>
            </div>
            <Select
              value={editableFeeData?.planId}
              options={plans}
              allowClear
              onChange={(val) => handleChange(val, "planId")}
              style={{
                width: "200px",
              }}
              popupRender={(menu) => {
                return (
                  <>
                    {menu}
                    {["TRANSPORT", "HOSTEL", "ADMISSION"]?.includes(mode) && (
                      <>
                        <Divider style={{ margin: "8px 0" }} />
                        <Space style={{ padding: "0 8px 4px" }}>
                          <Button
                            icon={<PlusOutlined />}
                            color="primary"
                            variant="text"
                            size="small"
                            onClick={() => setAddPlanModal(true)}
                          >
                            Add new plan
                          </Button>
                        </Space>
                      </>
                    )}
                  </>
                );
              }}
            />
          </div>
          <div className="single-t-d-container">
            <div className="icon-title-wrapper">
              <div className="edit-icon-container">
                <DESC_EDIT_ICON />
              </div>
              <p className="role-title">Branches</p>
            </div>
            <MultiSelectWithSelectAll
              value={editableFeeData?.branchIds || []}
              options={BRANCHES_OPTIONS}
              onChange={(val) => handleChange(val, "branchIds")}
              style={{
                width: "200px",
              }}
            />
          </div>
        </div>
        <div className="role-permissions">
          <Typography.Title level={5}>Payable fees</Typography.Title>
          <FeeItemsTable
            value={editableFeeData?.feeItems || []}
            onChange={(updatedItems: feeItemType[]) =>
              handleChange(updatedItems, "feeItems")
            }
          />
        </div>
        <div className="footer-permission-buttons">
          <Button style={ButtonInlineStyles} onClick={handleCancel}>
            Cancel
          </Button>
          <Button
            style={ButtonInlineStyles}
            icon={<CheckOutlined />}
            type="primary"
            onClick={handleSubmit}
            disabled={!inputChange || planLoading || loading}
          >
            {feeData?.id ? "Update" : "Create"}
          </Button>
        </div>
        <AddEditPlanModal
          open={addPlanModal}
          mode={mode}
          onCancel={handleModalCancel}
          taskAfterSubmit={handleTaskAfterSubmit}
        />
      </StyledEditFeePlan>
    </StyledMobileSpacedFancyContainer>
  );
};

export default EditFeePlan;
