"use client";

import { commonContainerMobileExtraStyles, mobileNavbarExtraStyles } from "@/components/common/styles.common";
import { GLOBAL_CONSTANTS } from "@/constants";
import { StyledContextProps } from "@/types";
import styled from "styled-components";

export const StyledFeeStructures = styled.div<StyledContextProps>`
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 20px;

  ${commonContainerMobileExtraStyles}

  .mobile-create-footer {
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    z-index: 10;
    background: ${({ token }) => token?.colorBgBase};
    padding: 10px 14px;
  }
`;

export const StyledNavbar = styled.div<StyledContextProps>`
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 15px;
  flex-wrap: wrap;

  .nav-studentlist-actions {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 10px;
  }

  ${mobileNavbarExtraStyles};
`;

export const StyledFeeStructureTable = styled.div<StyledContextProps>`
  width: 100%;

  .ant-pagination {
    position: sticky;
    bottom: 0px;
    background-color: ${({ token }) => token?.colorBgBase};
    padding: 12px 20px;
    margin: 0px;
    z-index: 10;
  }

  .ant-table-thead > tr > th {
    background: transparent;
    font-weight: 500;
    text-transform: uppercase;
  }

  .ant-table-tbody > tr > td,
  .ant-table-wrapper tfoot > tr > td {
    padding: 8px 16px;
  }
`;

export const StyledFeeStructuresMode = styled.div`
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 20px;

  ${commonContainerMobileExtraStyles}
`;

export const StyledEditFeePlan = styled.div<StyledContextProps>`
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 20px;

  .role-title-description {
    display: flex;
    flex-direction: column;
    gap: 18px;
    padding: 20px;
  }

  .single-t-d-container {
    display: flex;
    align-items: center;
    gap: 15px;
    flex-wrap: wrap;
  }

  .icon-title-wrapper {
    width: 150px;
    display: flex;
    align-items: center;
    gap: 5px;
  }

  .edit-icon-container {
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 6px 9px;
    border-radius: 10px;
    background: ${({ token }) => token?.colorGreyCard};
  }

  .role-title {
    color: ${({ token }) => token?.colorGreyPrimary};
    font-weight: 600;
  }

  .role-permissions {
    padding: 10px 20px;
    display: flex;
    flex-direction: column;
    gap: 15px;
  }

  .permission-container {
    display: flex;
    flex-direction: column;
  }

  .single-permission-container {
    width: 100%;
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 10px 0px;
    border-top: 1px solid ${({ token }) => token?.colorBorder};
  }

  .perm-last-elem {
    border-bottom: 1px solid ${({ token }) => token?.colorBorder};
  }

  .permission-box {
    flex: 1 1 calc(100% - 1px);
  }

  .footer-permission-buttons {
    position: sticky;
    bottom: -30px;
    width: 100%;
    display: flex;
    justify-content: flex-end;
    gap: 10px;
    background: ${({ token }) => token?.colorBgBase};
    z-index: 10;
    padding: 20px 0;
  }

  @media (max-width: ${GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.RESPONSIVE_WIDTH}px) {
    gap: 12px;

    .role-title-description {
      padding: 12px 0;
    }

    .role-permissions {
      padding: 10px 0;
    }

    .icon-title-wrapper {
      width: 105px;
    }

    .footer-permission-buttons {
      position: fixed;
      left: 0;
      bottom: 0;
      right: 0;
      padding: 10px 14px;
    }
  }
`;

export const StyledFeeItemsTable = styled.div<StyledContextProps>`
  width: 100%;
  transition: 0.3s all ease-in-out;

  .add-new-item-button {
    width: 100%;
  }

  .ant-table-thead > tr > th {
    background: ${({ token }) => token?.colorBgBase};
    font-weight: 500;
    text-transform: uppercase;
  }

  .ant-table-tbody > tr > td,
  .ant-table-wrapper tfoot > tr > td {
    padding: 8px 16px;
  }
`;
