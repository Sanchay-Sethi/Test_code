"use client";
import { useEffect, useState } from "react";
import apiClient from "@/lib/apiClient";
import Navbar from "./components/Navbar";
import { StyledFeeStructuresMode } from "./Styles.FeeStructures";
import GeneralSkeleton from "@/components/reusable/Loader/Skeleton/GeneralSkeleton";
import EditFeePlan from "./components/EditFeePlan";
import { StyledMobileSpacedContainer } from "@/components/common/styles.common";

function getOptions(options: OptionsTypes[]) {
  return options?.map((option) => {
    return {
      label: option?.name || option?.label,
      value: option?.id || option?.value,
      _original: option,
    };
  });
}

const FeeStructuresMode = ({
  mode = "",
  id = "",
}: {
  mode?: string;
  id?: string;
}) => {
  const [loading, setLoading] = useState(false);
  const [planLoading, setPlanLoading] = useState(false);
  const [feeData, setFeeData] = useState<FeeDataTypes>();
  const [plans, setPlans] = useState<OptionsTypes[]>();

  async function getPlans() {
    if (mode === "PROGRAM") {
      try {
        setPlanLoading(true);
        const res = await apiClient.get("/program");
        setPlans(getOptions(res?.data));
      } finally {
        setPlanLoading(false);
      }
    } else {
      try {
        setPlanLoading(true);
        const res = await apiClient.get(`/fee/plan?feeType=${mode}`);
        setPlans(getOptions(res?.data));
      } finally {
        setPlanLoading(false);
      }
    }
  }

  async function getFeeData() {
    if (!id) return;
    try {
      setLoading(true);
      const res = await apiClient.get(`/fee/${id}`);
      setFeeData(res?.data);
    } finally {
      setLoading(false);
    }
  }

  function getTitle() {
    return plans?.find((plan) => plan.value === feeData?.planId)?.label || "";
  }

  useEffect(() => {
    getFeeData();
    getPlans();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (loading) {
    return <StyledMobileSpacedContainer><GeneralSkeleton /></StyledMobileSpacedContainer>;
  }

  return (
    <StyledFeeStructuresMode>
      <Navbar isEdit mode={mode} loading={false} title={getTitle()} />
      <EditFeePlan
        id={id}
        mode={mode}
        plans={plans}
        planLoading={planLoading}
        feeData={feeData}
        updateTableData={getFeeData}
        getPlans={getPlans}
      />
    </StyledFeeStructuresMode>
  );
};

export default FeeStructuresMode;
