"use client";

import { useEffect, useMemo, useState } from "react";
import { useSearchParams } from "next/navigation";
import { Tabs, theme } from "antd";
import { useNavigation } from "@/lib/context/NavigationContext";
import Navbar from "./components/Navbar";
import Programs from "./components/tabsComponents/Programs";
import Admission from "./components/tabsComponents/Admission";
import Transport from "./components/tabsComponents/Transport";
import Hostel from "./components/tabsComponents/Hostel";
// import Discount from "./components/tabsComponents/Discount";
import CreateButton from "./components/CreateButton";
import { StyledFeeStructures } from "./Styles.FeeStructures";
import apiClient from "@/lib/apiClient";
import { useGlobalValues } from "@/lib/hooks/useGlobalValues";
import HELPERS from "@/lib/helpers";
import FeeModal from "./components/FeeModal";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";
import { StyledMobileSpacedContainer } from "@/components/common/styles.common";

const TAB_KEYS = ["PROGRAM", "ADMISSION", "TRANSPORT", "HOSTEL", "DISCOUNT"];
const FeeStructures = () => {
  const searchParams = useSearchParams();
  const { navigate } = useNavigation();
  const { CURRENT_ACADEMIC_YEAR } = useGlobalValues();

  const [loading, setLoading] = useState(false);
  const [mode, setMode] = useState("");
  const [listingData, setListingData] = useState<FeeStructureData[]>([]);
  const [feeModal, setFeeModal] = useState(false);
  const [activeId, setActiveId] = useState("");

  const paramMode = searchParams.get("mode");

  const isMobile = useIsSmallDevice();

  const {token} = theme.useToken();

  const academicYearId =
    searchParams.get("academicYearId") || CURRENT_ACADEMIC_YEAR;

  function handleModalCancel() {
    setFeeModal(false);
    setActiveId("");
  }

  async function getTableListing(academicYearId = "", type = "") {
    try {
      setLoading(true);
      let response;
      if (type !== "DISCOUNT") {
        response = await apiClient.get(
          `/fee/list?academicYearId=${academicYearId}&type=${type}`
        );
      } else {
        response = await apiClient.get(
          `/fee/discount/list?academicYearId=${academicYearId}`
        );
      }
      setListingData(response?.data);
    } finally {
      setLoading(false);
    }
  }

  async function handleDelete(id: string) {
    try {
      await apiClient.delete(
        mode === "DISCOUNT" ? `/fee/discount/${id}` : `/fee/${id}`
      );
      HELPERS.messageAlert({ success: "Delete successfully" });
    } finally {
      getTableListing(academicYearId, mode);
    }
  }

  async function handleEdit(id: string) {
    if (["PROGRAM", "TRANSPORT", "HOSTEL", "ADMISSION"]?.includes(mode)) {
      navigate(`/settings/fee-structures/${mode}/${id}`);
    } else {
      setFeeModal(true);
      setActiveId(id);
    }
  }

  function handleCreateButtonClick(mode = "") {
    if (["PROGRAM", "TRANSPORT", "HOSTEL", "ADMISSION"]?.includes(mode)) {
      navigate(`/settings/fee-structures/${mode}`);
    } else {
      setFeeModal(true);
    }
  }

  const handleTabChange = (key: string) => {
    setMode(key);
    const params = new URLSearchParams(searchParams?.toString());
    params.set("mode", key?.trim());
    navigate(`?${params.toString()}`);
  };

  const handleTaskAfterSubmit = () => {
    handleModalCancel();
    getTableListing(academicYearId, mode);
  }

  useEffect(() => {
    if (paramMode && TAB_KEYS?.includes(paramMode)) {
      setMode(paramMode);
    } else {
      setMode("PROGRAM");
    }
  }, [paramMode]);

  useEffect(() => {
    if (mode && academicYearId) {
      getTableListing(academicYearId, mode);
    }
  }, [mode, academicYearId]);

  const items = useMemo(
    () => [
      {
        key: "PROGRAM",
        label: "Programs",
        children: (
          <Programs
            listingData={listingData}
            loading={loading}
            handleDelete={handleDelete}
            handleEdit={handleEdit}
          />
        ),
      },
      {
        key: "ADMISSION",
        label: "Admission",
        children: (
          <Admission
            listingData={listingData}
            loading={loading}
            handleDelete={handleDelete}
            handleEdit={handleEdit}
          />
        ),
      },
      {
        key: "TRANSPORT",
        label: "Transport",
        children: (
          <Transport
            listingData={listingData}
            loading={loading}
            handleDelete={handleDelete}
            handleEdit={handleEdit}
          />
        ),
      },
      {
        key: "HOSTEL",
        label: "Hostel",
        children: (
          <Hostel
            listingData={listingData}
            loading={loading}
            handleDelete={handleDelete}
            handleEdit={handleEdit}
          />
        ),
      },
      // {
      //   key: "DISCOUNT",
      //   label: "Discount",
      //   children: (
      //     <Discount
      //       listingData={listingData}
      //       loading={loading}
      //       handleDelete={handleDelete}
      //       handleEdit={handleEdit}
      //     />
      //   ),
      // },
    ],
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [mode, listingData]
  );

  return (
    <StyledFeeStructures token={token}>
      <Navbar />
      <StyledMobileSpacedContainer>
        <Tabs
          activeKey={mode}
          items={items}
          onChange={handleTabChange}
          tabBarExtraContent={
            isMobile ? null : <CreateButton mode={mode} onClick={handleCreateButtonClick} />
          }
          tabBarStyle={
            isMobile
              ? {
                  background: token?.colorBgBase,
                  // padding: "0px 2px 0px 12px",
                  paddingLeft: 6,
                  borderRadius: 12,
                  overflow: "auto",
                }
              : {}
          }
        />
      </StyledMobileSpacedContainer>
      <FeeModal
        id = {activeId}
        open={feeModal}
        onCancel={handleModalCancel}
        mode={mode}
        academicYearId={academicYearId}
        taskAfterSubmit={handleTaskAfterSubmit}
      />
      {
        isMobile &&
        <div className="mobile-create-footer">
          <CreateButton mode={mode} onClick={handleCreateButtonClick}/>
        </div>
      }
    </StyledFeeStructures>
  );
};

export default FeeStructures;
