"use client";

import React, { useEffect, useState } from "react";
import {
  Form,
  Input,
  DatePicker,
  Select,
  Button,
  Popconfirm,
  Space,
  Switch,
  theme,
  Spin,
  Tag,
  Drawer,
  Typography,
} from "antd";
import dayjs from "dayjs";
import { CloseOutlined } from "@ant-design/icons";
import { EventInput } from "@fullcalendar/core";
import { CALENDER } from "../Icons";
import { CATEGORY_COLOR } from "./MyCalendar";
import GeneralModal from "@/components/reusable/Modal/GeneralModal/Modal";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";
import { GLOBAL_CONSTANTS } from "@/constants";
import { StyledCalenderForm } from "../styles";

const { RangePicker } = DatePicker;
const { Option } = Select;

interface EventModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (event: EventInput) => void;
  onDelete: (eventId: string) => void;
  event: EventInput | null;
  selectedDateInfo: {
    startStr?: string;
    endStr?: string;
    allDay?: boolean;
  };
  loading: boolean;
  isStudent: boolean;
}

export default function EventModal({
  isOpen,
  onClose,
  onSave,
  onDelete,
  event,
  selectedDateInfo,
  loading,
  isStudent,
}: EventModalProps) {
  const [form] = Form.useForm();
  const isNewEvent = !event?.id;
  const [eventType, setEventType] = useState("");

  const isMobile = useIsSmallDevice();

  function handleClose() {
    setEventType("");
    onClose();
  }

  useEffect(() => {
    if (isOpen) {
      if (event) {
        // Editing an existing event
        form.setFieldsValue({
          title: event?.title,
          description: event?.extendedProps?.description || "",
          type: event?.extendedProps?.type || "",
          staffOnly: event.extendedProps?.staffOnly ?? false,
          dates: [
            dayjs(event?.start || event?.startDate),
            dayjs(event?.end || event?.endDate),
          ],
        });
        setEventType(event?.extendedProps?.type || "");
      } else if (selectedDateInfo) {
        // Creating a new event
        form.setFieldsValue({
          dates: [
            dayjs(selectedDateInfo?.startStr),
            dayjs(selectedDateInfo?.endStr),
          ],
          staffOnly: false,
        });
      }
    } else {
      form.resetFields();
    }
  }, [isOpen, event, selectedDateInfo, form]);

  const handleFinish = (values: EventInput) => {
    if (isStudent) return;
    const [start, end] = values?.dates;
    const eventToSave: EventInput = {
      id: event?.id || "",
      title: values?.title,
      startDate: start?.toDate(),
      endDate: end?.toDate(),
      allDay: selectedDateInfo?.allDay ?? true,

      extendedProps: {
        description: values?.description,
        type: values?.type,
        staffOnly: values?.staffOnly,
      },
    };
    onSave(eventToSave);
  };

  function handleMobileFinish() {
    form.validateFields().then((values) => {
      handleFinish(values);
    });
  }

  const handleDelete = () => {
    if (event?.id) {
      onDelete(event?.id);
    }
  };

  if (isMobile) {
    return (
      <Drawer
        onClose={handleClose}
        open={isOpen}
        placement="bottom"
        height={isStudent ? "40%" : "90%"}
        closable={false}
        style={{
          borderTopLeftRadius:
            GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.BORDER_RADIUS,
          borderTopRightRadius:
            GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.BORDER_RADIUS,
        }}
        footer={
          <>
            {!isStudent && (
              <div
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                }}
              >
                <div>
                  {!isNewEvent && (
                    <Popconfirm
                      title="Delete the event"
                      description="Are you sure you want to delete this event?"
                      onConfirm={handleDelete}
                      okText="Yes"
                      cancelText="No"
                    >
                      <Button danger>Delete</Button>
                    </Popconfirm>
                  )}
                </div>
                <Space>
                  <Button onClick={handleClose}>Cancel</Button>
                  <Button
                    type="primary"
                    htmlType="submit"
                    onClick={handleMobileFinish}
                  >
                    {isNewEvent ? "Create" : "Update"}
                  </Button>
                </Space>
              </div>
            )}
          </>
        }
        title={
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <CALENDER width="18" height="18" />
              <Typography.Title level={5}>
                {isStudent
                  ? "Event"
                  : isNewEvent
                  ? "Create Event"
                  : "Edit Event"}
              </Typography.Title>
              {isStudent && eventType && (
                <Tag
                  color={
                    CATEGORY_COLOR?.[eventType as keyof typeof CATEGORY_COLOR]
                  }
                >
                  {eventType?.[0] + eventType?.slice(1)?.toLowerCase()}
                </Tag>
              )}
            </div>
            <Button onClick={handleClose} shape="circle">
              <CloseOutlined />
            </Button>
          </div>
        }
      >
        <Spin spinning={loading}>
          <StyledCalenderForm token={theme.useToken()?.token}>
            {isStudent ? (
              <div className="flex flex-col w-full">
                <div className="flex items-center w-full gap-2 justify-between border-b-1 border-gray-200 py-3">
                  <Typography.Paragraph style={{ fontWeight: 600 }}>
                    Title
                  </Typography.Paragraph>
                  <Typography.Paragraph>
                    {form?.getFieldValue("title")}
                  </Typography.Paragraph>
                </div>
                <div className="flex items-center w-full gap-2 justify-between border-b-1 border-gray-200 py-3">
                  <Typography.Paragraph style={{ fontWeight: 600 }}>
                    Description
                  </Typography.Paragraph>
                  <Typography.Paragraph>
                    {form?.getFieldValue("description") || "None"}
                  </Typography.Paragraph>
                </div>
                <div className="flex items-center w-full gap-2 justify-between border-b-0 border-gray-200 py-3">
                  <Typography.Paragraph style={{ fontWeight: 600 }}>
                    Event date
                  </Typography.Paragraph>
                  <Typography.Paragraph>
                    {event?.start || event?.startDate} to{" "}
                    {event?.end || event?.endDate}
                  </Typography.Paragraph>
                </div>
              </div>
            ) : (
              <Form form={form} layout="vertical" onFinish={handleFinish}>
                <Form.Item
                  name="title"
                  label="Event title"
                  rules={[{ required: true, message: "Please enter a title" }]}
                >
                  <Input readOnly={isStudent} />
                </Form.Item>

                <Form.Item
                  name="description"
                  label={isStudent ? "Description" : "Description (optional)"}
                >
                  <Input.TextArea rows={3} readOnly={isStudent} />
                </Form.Item>

                {!isStudent && (
                  <Form.Item
                    name="type"
                    label="Category"
                    initialValue=""
                    rules={[
                      { required: true, message: "Please select category" },
                    ]}
                  >
                    <Select>
                      <Option value="HOLIDAY">Holiday</Option>
                      <Option value="EXAM">Exam</Option>
                      <Option value="OTHER">Other</Option>
                    </Select>
                  </Form.Item>
                )}

                {!isStudent && (
                  <div style={{ marginBottom: 20, paddingLeft: "5px" }}>
                    <label style={{ fontWeight: 400, userSelect: "none" }}>
                      Visibility
                    </label>
                    <div className="flex items-center gap-2">
                      <Form.Item
                        name="staffOnly"
                        valuePropName="checked"
                        style={{ marginBottom: 0 }}
                      >
                        <Switch size="small" />
                      </Form.Item>
                      <span className="calender-extra-small-text">
                        ( For staff only )
                      </span>
                    </div>
                  </div>
                )}

                <Form.Item
                  name="dates"
                  label="From - To"
                  rules={[
                    { required: true, message: "Please select a date range" },
                  ]}
                >
                  <RangePicker style={{ width: "100%" }} disabled={isStudent} />
                </Form.Item>
              </Form>
            )}
          </StyledCalenderForm>
        </Spin>
      </Drawer>
    );
  }

  return (
    <GeneralModal
      customTitle={
        <div className="flex items-center gap-2">
          <CALENDER width="18" height="18" />{" "}
          {isStudent ? "Event" : isNewEvent ? "Create Event" : "Edit Event"}
          {isStudent && eventType && (
            <Tag
              color={CATEGORY_COLOR?.[eventType as keyof typeof CATEGORY_COLOR]}
            >
              {eventType?.[0] + eventType?.slice(1)?.toLowerCase()}
            </Tag>
          )}
        </div>
      }
      open={isOpen}
      onCancel={handleClose}
      footer={null}
      {...{ destroyOnHidden: true }}
    >
      <Spin spinning={loading}>
        <StyledCalenderForm token={theme.useToken()?.token}>
          {isStudent ? (
            <div className="flex flex-col w-full">
              <div className="flex items-center w-full gap-2 justify-between border-b-1 border-gray-200 py-3">
                <Typography.Paragraph style={{ fontWeight: 600 }}>
                  Title
                </Typography.Paragraph>
                <Typography.Paragraph>
                  {form?.getFieldValue("title")}
                </Typography.Paragraph>
              </div>
              <div className="flex items-center w-full gap-2 justify-between border-b-1 border-gray-200 py-3">
                <Typography.Paragraph style={{ fontWeight: 600 }}>
                  Description
                </Typography.Paragraph>
                <Typography.Paragraph>
                  {form?.getFieldValue("description") || "None"}
                </Typography.Paragraph>
              </div>
              <div className="flex items-center w-full gap-2 justify-between border-b-0 border-gray-200 py-3">
                <Typography.Paragraph style={{ fontWeight: 600 }}>
                  Event date
                </Typography.Paragraph>
                <Typography.Paragraph>
                  {event?.start || event?.startDate} to{" "}
                  {event?.end || event?.endDate}
                </Typography.Paragraph>
              </div>
            </div>
          ) : (
            <Form form={form} layout={"vertical"} onFinish={handleFinish}>
              <Form.Item
                name="title"
                label="Event title"
                rules={[{ required: true, message: "Please enter a title" }]}
              >
                <Input readOnly={isStudent} />
              </Form.Item>

              <Form.Item
                name="description"
                label={isStudent ? "Description" : "Description (optional)"}
              >
                <Input.TextArea rows={3} readOnly={isStudent} />
              </Form.Item>

              {!isStudent && (
                <Form.Item
                  name="type"
                  label="Category"
                  initialValue=""
                  rules={[
                    { required: true, message: "Please select category" },
                  ]}
                >
                  <Select>
                    <Option value="HOLIDAY">Holiday</Option>
                    <Option value="EXAM">Exam</Option>
                    <Option value="OTHER">Other</Option>
                  </Select>
                </Form.Item>
              )}

              {!isStudent && (
                <div style={{ marginBottom: 20, paddingLeft: "5px" }}>
                  <label style={{ fontWeight: 400, userSelect: "none" }}>
                    Visibility
                  </label>
                  <div className="flex items-center gap-2">
                    <Form.Item
                      name="staffOnly"
                      valuePropName="checked"
                      style={{ marginBottom: 0 }}
                    >
                      <Switch size="small" />
                    </Form.Item>
                    <span className="calender-extra-small-text">
                      ( For staff only )
                    </span>
                  </div>
                </div>
              )}

              <Form.Item
                name="dates"
                label="From - To"
                rules={[
                  { required: true, message: "Please select a date range" },
                ]}
              >
                <RangePicker style={{ width: "100%" }} disabled={isStudent} />
              </Form.Item>

              {!isStudent && (
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    marginTop: "24px",
                  }}
                >
                  <div>
                    {!isNewEvent && (
                      <Popconfirm
                        title="Delete the event"
                        description="Are you sure you want to delete this event?"
                        onConfirm={handleDelete}
                        okText="Yes"
                        cancelText="No"
                      >
                        <Button danger>Delete</Button>
                      </Popconfirm>
                    )}
                  </div>
                  <Space>
                    <Button onClick={handleClose}>Cancel</Button>
                    <Button type="primary" htmlType="submit">
                      {isNewEvent ? "Create" : "Update"}
                    </Button>
                  </Space>
                </div>
              )}
            </Form>
          )}
        </StyledCalenderForm>
      </Spin>
    </GeneralModal>
  );
}
