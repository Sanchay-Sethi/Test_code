"use client";

import { useEffect, useState } from "react";
import { useParams, useSearchParams } from "next/navigation";
import { Button, Drawer, Input, Spin, Tooltip, Typography } from "antd";
import { RiSearch2Line } from "react-icons/ri";
import { CloseOutlined } from "@ant-design/icons";
import { useDebounce } from "@/lib/hooks/useDebounce";
import apiClient from "@/lib/apiClient";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";
import { useThemeContext } from "@/lib/context/ThemeContext";
import { GLOBAL_CONSTANTS } from "@/constants";
import GeneralModal from "@/components/reusable/Modal/GeneralModal/Modal";
import { INFO } from "../Icons";
import { CATEGORY_COLOR } from "./MyCalendar";
import { StyledCalenderEvent } from "../styles";

const SearchEvent = ({
  onEventClick = () => {},
  callBack = () => {},
  isStudent = false,
}: {
  onEventClick: (event: { id: string; start: string | Date }) => void;
  callBack?: () => void;
  isStudent: boolean;
}) => {
  const [modalOpen, setModalOpen] = useState(false);
  const [searchValue, setSearchValue] = useState("");
  const [loading, setLoading] = useState(false);
  const [searchedEvents, setSearchedEvents] = useState([]);

  const isDarkTheme = useThemeContext().mode === "dark";
  const isMobile = useIsSmallDevice();

  const { branchid } = useParams();
  const searchParams = useSearchParams();

  const debouncedSearch = useDebounce(searchValue, 500);

  function handleClick(flag = false) {
    setModalOpen(flag);
  }

  async function handleSearch(
    title = "",
    branchid?: string,
    params?: Record<string, string>
  ) {
    if (!title?.trim()) return;
    setLoading(true);
    try {
      const queryString = params
        ? "&" + new URLSearchParams(params).toString()
        : "";
      const res = await apiClient.get(
        `/calendar?branchId=${branchid}&title=${title?.trim()}${queryString}`
      );

      const finalRes = (res?.data || [])?.filter(
        (event: { staffOnly: boolean }) => {
          if (isStudent && !event?.staffOnly) {
            return event;
          }
          return event;
        }
      );

      setSearchedEvents(finalRes || []);
    } finally {
      setLoading(false);
    }
  }

  function handleClickEvent(event: { id: string; start: string | Date }) {
    setModalOpen(false);
    onEventClick?.(event);
    callBack();
  }

  useEffect(() => {
    const params: Record<string, string> = {};
    for (const [key, value] of searchParams?.entries()) {
      params[key] = value;
    }
    if (Object?.keys(params)?.length > 0) {
      handleSearch(debouncedSearch, branchid as string, params);
    } else {
      handleSearch(debouncedSearch, branchid as string);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debouncedSearch, branchid, searchParams]);

  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if ((e.key === "k" || e.key === "K") && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        handleClick(!modalOpen);
      }
    };

    document.addEventListener("keydown", down);
    return () => document.removeEventListener("keydown", down);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <>
      <Button onClick={() => handleClick(true)} block={isMobile}>
        <div className="flex items-center gap-1.5">
          <RiSearch2Line style={{ color: "gray" }} />{" "}
          <p className="text-gray-600">Search event</p>
          {!isMobile && (
            <kbd
              className={`ml-auto pointer-events-none inline-flex h-5 select-none items-center gap-1 rounded border border-gray-200 bg-muted px-1.5 font-mono text-[10px] font-medium text-muted-foreground ${
                isDarkTheme ? "border-gray-700" : ""
              }`}
            >
              <span className="text-gray-400">&#8984; + K</span>
            </kbd>
          )}
        </div>
      </Button>
      {isMobile ? (
        <Drawer
          onClose={() => handleClick(false)}
          open={modalOpen}
          placement="bottom"
          height={"70%"}
          closable={false}
          style={{
            borderTopLeftRadius:
              GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.BORDER_RADIUS,
            borderTopRightRadius:
              GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.BORDER_RADIUS,
          }}
          footer={null}
          title={
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Typography.Title level={5}>Search event</Typography.Title>
              </div>
              <Button onClick={() => handleClick(false)} shape="circle">
                <CloseOutlined />
              </Button>
            </div>
          }
        >
          <div className="flex flex-col gap-5">
            <Input
              value={searchValue}
              onChange={(e) => setSearchValue(e.target.value)}
              placeholder="Search by name"
              style={{ width: "100%" }}
              allowClear
            />
            <Spin spinning={loading}>
              {debouncedSearch && searchedEvents?.length > 0 && (
                <div className="flex flex-col gap-3">
                  {searchedEvents?.map(
                    (event: {
                      type: string;
                      id: string;
                      title: string;
                      description: string;
                      startDate: string;
                    }) => {
                      return (
                        <StyledCalenderEvent
                          color={
                            CATEGORY_COLOR?.[
                              event?.type as keyof typeof CATEGORY_COLOR
                            ]
                          }
                          key={event?.id}
                          onClick={() =>
                            handleClickEvent({
                              id: event?.id,
                              start: event?.startDate,
                            })
                          }
                        >
                          <Typography.Text style={{ color: "#fff" }}>
                            {event?.title}
                          </Typography.Text>
                          {event?.description && (
                            <Tooltip
                              title={event?.description}
                              placement="right"
                            >
                              <div className="cursor-pointer">
                                <INFO />
                              </div>
                            </Tooltip>
                          )}
                        </StyledCalenderEvent>
                      );
                    }
                  )}
                </div>
              )}
            </Spin>
          </div>
        </Drawer>
      ) : (
        <GeneralModal
          customTitle="Search event"
          titleIcon={<RiSearch2Line />}
          open={modalOpen}
          onCancel={() => handleClick(false)}
          footer={null}
        >
          <div className="flex flex-col gap-5">
            <Input
              value={searchValue}
              onChange={(e) => setSearchValue(e.target.value)}
              placeholder="Search by name"
              style={{ width: "100%" }}
              allowClear
            />
            <Spin spinning={loading}>
              {debouncedSearch && searchedEvents?.length > 0 && (
                <div className="flex flex-col gap-3">
                  {searchedEvents?.map(
                    (event: {
                      type: string;
                      id: string;
                      title: string;
                      description: string;
                      startDate: string;
                    }) => {
                      return (
                        <StyledCalenderEvent
                          color={
                            CATEGORY_COLOR?.[
                              event?.type as keyof typeof CATEGORY_COLOR
                            ]
                          }
                          key={event?.id}
                          onClick={() =>
                            handleClickEvent({
                              id: event?.id,
                              start: event?.startDate,
                            })
                          }
                        >
                          <Typography.Text style={{ color: "#fff" }}>
                            {event?.title}
                          </Typography.Text>
                          {event?.description && (
                            <Tooltip
                              title={event?.description}
                              placement="right"
                            >
                              <div className="cursor-pointer">
                                <INFO />
                              </div>
                            </Tooltip>
                          )}
                        </StyledCalenderEvent>
                      );
                    }
                  )}
                </div>
              )}
            </Spin>
          </div>
        </GeneralModal>
      )}
    </>
  );
};

export default SearchEvent;
