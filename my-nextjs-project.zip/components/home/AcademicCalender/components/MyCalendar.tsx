"use client";

import React, { useState, useRef, useEffect } from "react";
import { cloneDeep } from "lodash";
import FullCalendar from "@fullcalendar/react";
import dayGridPlugin from "@fullcalendar/daygrid";
import timeGridPlugin from "@fullcalendar/timegrid";
import interactionPlugin, {
  EventResizeDoneArg,
} from "@fullcalendar/interaction";
import listPlugin from "@fullcalendar/list";
import {
  EventInput,
  EventClickArg,
  EventDropArg,
  DatesSetArg,
  CalendarOptions,
  EventContentArg,
} from "@fullcalendar/core";

import EventModal from "./EventModal";
import {
  Button,
  Popover,
  Typography,
  Tooltip,
  Select,
  theme,
  Spin,
  DatePicker,
  Drawer,
  Tabs,
} from "antd";
import type { Dayjs } from "dayjs";
import { useParams, useSearchParams } from "next/navigation";
import {
  ARROW_LEFT,
  ARROW_RIGHT,
  CALENDER,
  CATEGORY,
  CHEVRON,
  DOWNLOAD,
  INFO,
} from "../Icons";
import { CloseOutlined } from "@ant-design/icons";
import apiClient from "@/lib/apiClient";
import HELPERS from "@/lib/helpers";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";
import { useNavigation } from "@/lib/context/NavigationContext";
import { GLOBAL_CONSTANTS } from "@/constants";
import SearchEvent from "./SearchEvent";
import { StyledFilterDrawer } from "@/components/reusable/Drawers/FilterDrawer/styles.FilterDrawer";
import {
  ButtonInlineSmallStyles,
  ButtonInlineStyles,
} from "@/components/common/styles.common";
import { StyledMyCalender } from "../styles";

interface MyCalendarProps {
  isStudent?: boolean;
}

type SelectArg = Parameters<NonNullable<CalendarOptions["select"]>>[0];

export const CATEGORY_COLOR = {
  HOLIDAY: "#13a02a",
  EXAM: "#635CFF",
  OTHER: "#F65657",
};

export default function MyCalendar({ isStudent = false }: MyCalendarProps) {
  const [events, setEvents] = useState<EventInput[]>([]);
  const [calenderView, setCalenderView] = useState<string>("dayGridMonth");
  const [category, setCategory] = useState<string | null>(null);
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [selectedEvent, setSelectedEvent] = useState<EventInput | null>(null);
  const [selectedDateInfo, setSelectedDateInfo] = useState<SelectArg | null>(
    null
  );
  const [calendarTitle, setCalendarTitle] = useState<string>("");
  const [isPopoverOpen, setIsPopoverOpen] = useState<boolean>(false);

  const [containerWidth, setContainerWidth] = useState(0);
  const [loading, setLoading] = useState(false);

  const [mobileFilter, setMobileFilter] = useState(false);

  const calendarRef = useRef<FullCalendar>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const { branchid } = useParams();
  const searchParams = useSearchParams();
  const { navigate } = useNavigation();

  const isMobile = useIsSmallDevice();

  const { token } = theme.useToken();

  // Update the custom header's title whenever the view or date changes
  const handleDatesSet = (dateInfo: DatesSetArg) => {
    setCalendarTitle(dateInfo.view.title);
  };

  // Navigate FullCalendar when a date is selected in the AntD Calendar popover
  // const handleDateSelect = (date: Dayjs) => {
  //   if (calendarRef.current) {
  //     const calendarApi = calendarRef.current.getApi();
  //     calendarApi.gotoDate(date.toDate());
  //     setIsPopoverOpen(false); // Close the popover after selection
  //   }
  // };

  const handleMonthChange = (date: Dayjs | null) => {
    if (date && calendarRef.current) {
      const calendarApi = calendarRef.current.getApi();
      // Go to selected month & year
      calendarApi.gotoDate(date.startOf("month").toDate());
      setIsPopoverOpen(false);
    }
  };

  // --- Handlers for custom header controls ---
  const goToPrev = () => calendarRef.current?.getApi().prev();
  const goToNext = () => calendarRef.current?.getApi().next();
  const goToToday = () => calendarRef.current?.getApi().today();
  const changeView = (val: string) => {
    setCalenderView(val);
    setMobileFilter(false);
    calendarRef.current?.getApi()?.changeView(val);
  };
  const changeCategory = (val: string | null) => {
    setCategory(val);
    setMobileFilter(false);
    const params = new URLSearchParams(searchParams.toString());
    if (val) {
      params.set("type", val?.trim());
    } else {
      params.delete("type");
    }
    navigate(`?${params.toString()}`);
  };

  // --- Existing handlers for event management ---
  const handleSelect: NonNullable<CalendarOptions["select"]> = (selectInfo) => {
    if (isStudent) return;
    selectInfo.view.calendar.unselect();
    setSelectedEvent(null);
    setSelectedDateInfo(selectInfo);
    setIsModalOpen(true);
  };

  const handleEventClick = (clickInfo: EventClickArg) => {
    setSelectedEvent(clickInfo.event.toPlainObject() as EventInput);
    setSelectedDateInfo(null);
    setIsModalOpen(true);
  };

  const handleSaveEvent = async (eventData: EventInput) => {
    setLoading(true);
    const body = {
      branchId: branchid,
      type: eventData?.extendedProps?.type,
      title: eventData?.title,
      description: eventData?.extendedProps?.description,
      startDate: HELPERS.formatDate(eventData?.startDate || eventData?.start),
      endDate: HELPERS.formatDate(eventData?.endDate || eventData?.end),
      staffOnly: eventData?.extendedProps?.staffOnly || false,
    };
    try {
      let res;
      if (eventData?.id) {
        res = await apiClient.put(`/calendar`, {
          ...(body || {}),
          id: eventData?.id,
        });
      } else {
        res = await apiClient.post(`/calendar`, {
          ...(body || {}),
        });
      }

      let data = cloneDeep(res?.data) || {};

      const start = data?.startDate || data?.start;
      const end = data?.endDate || data?.end;

      if (data?.startDate) {
        delete data?.startDate;
      }
      if (data?.endDate) {
        delete data?.endDate;
      }

      data = {
        ...(data || {}),
        start,
        end,
        color: CATEGORY_COLOR?.[data?.type as keyof typeof CATEGORY_COLOR],
      };

      if (selectedEvent) {
        setEvents((prevEvents) =>
          prevEvents.map((e) => (e.id === data?.id ? data : e))
        );
      } else {
        setEvents((prevEvents) => [...prevEvents, data]);
      }
      // getCalenderEvents(branchid);
    } finally {
      setLoading(false);
      setIsModalOpen(false);
    }
  };

  const handleDeleteEvent = async (eventId: string) => {
    setLoading(true);
    try {
      await apiClient.delete(`/calendar/${eventId}`);
      HELPERS.messageAlert({ success: "Deleted successfully" });
      setEvents((prevEvents) => prevEvents?.filter((e) => e?.id !== eventId));
    } finally {
      setLoading(false);
      setIsModalOpen(false);
    }
  };

  async function getCalenderEvents(
    branchid?: string,
    params?: Record<string, string>
  ) {
    setLoading(true);
    try {
      const queryString = params
        ? "&" + new URLSearchParams(params).toString()
        : "";
      const res = await apiClient.get(
        `/calendar?branchId=${branchid}${queryString}`
      );

      const finalRes = (res?.data || [])?.filter(
        (event: { staffOnly: boolean }) => {
          if (isStudent && !event?.staffOnly) {
            return event;
          }
          return event;
        }
      );

      const data = (finalRes || [])?.map(
        (event: {
          id: string;
          title: string;
          startDate: string;
          endDate: string;
          description: string;
          type: string;
          staffOnly: boolean;
        }) => {
          return {
            id: event?.id,
            title: event?.title,
            start: event?.startDate,
            end: event?.endDate,
            extendedProps: {
              description: event?.description,
              type: event?.type,
              staffOnly: event?.staffOnly,
            },
            color: CATEGORY_COLOR?.[event?.type as keyof typeof CATEGORY_COLOR],
          };
        }
      );
      setEvents(data || {});
    } finally {
      setLoading(false);
    }
  }

  const handleSearchEventClick = (event: {
    id: string;
    start: string | Date;
  }) => {
    setIsPopoverOpen(false);
    setIsModalOpen(false);

    if (!event?.id || !event?.start) {
      console.warn("Event missing id or start date", event);
      return;
    }

    if (calendarRef.current) {
      const calendarApi = calendarRef.current.getApi();

      const eventStart =
        typeof event.start === "string" ? new Date(event.start) : event.start;
      calendarApi.gotoDate(eventStart);

      const calendarEvent = calendarApi.getEventById(event.id);

      if (calendarEvent) {
        setSelectedEvent(calendarEvent.toPlainObject() as EventInput);
        setIsModalOpen(true);
      } else {
        console.warn(`Event with id ${event.id} not found in calendar`);
      }
    }
  };

  const handleEventResize = async (resizeInfo: EventResizeDoneArg) => {
    const { event } = resizeInfo;
    const body = {
      id: event?.id,
      title: event?.title,
      startDate: event?.start,
      endDate: event?.end,
      extendedProps: {
        type: event?.extendedProps?.type,
        description: event?.extendedProps?.description,
        staffOnly: event?.extendedProps?.staffOnly,
      },
    };
    handleSaveEvent(body);
  };

  const handleEventDrop = (dropInfo: EventDropArg) => {
    const { event } = dropInfo;
    const body = {
      id: event?.id,
      title: event?.title,
      startDate: event?.start,
      endDate: event?.end,
      extendedProps: {
        type: event?.extendedProps?.type,
        description: event?.extendedProps?.description,
        staffOnly: event?.extendedProps?.staffOnly,
      },
    };
    handleSaveEvent(body);
  };

  useEffect(() => {
    if (!containerRef.current) return;
    const resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        setContainerWidth(entry.contentRect.width);
      }
    });
    resizeObserver.observe(containerRef.current);
    return () => resizeObserver.disconnect();
  }, []);

  useEffect(() => {
    if (calendarRef.current) {
      calendarRef.current.getApi().updateSize();
    }
  }, [containerWidth]);

  useEffect(() => {
    setCategory(searchParams.get("type") || null);
    const params: Record<string, string> = {};
    for (const [key, value] of searchParams?.entries()) {
      params[key] = value;
    }
    if (Object?.keys(params)?.length > 0) {
      getCalenderEvents(branchid as string, params);
    } else {
      getCalenderEvents(branchid as string);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchParams, branchid]);

  // The content for the Popover
  const calendarPopoverContent = (
    <div style={{ width: 300, borderRadius: "2px" }}>
      {/* <Calendar fullscreen={false} onSelect={handleDateSelect} /> */}
      {isMobile ? (
        <DatePicker
          picker="month"
          onChange={handleMonthChange}
          placeholder="Select Month"
          style={{ width: "100%" }}
          placement={"topRight"}
        />
      ) : (
        <DatePicker
          picker="month"
          onChange={handleMonthChange}
          placeholder="Select Month"
          style={{ width: "100%" }}
          open={isPopoverOpen}
          getPopupContainer={(trigger) =>
            (trigger?.parentNode as HTMLElement) || document.body
          }
        />
      )}
    </div>
  );

  function renderEventContent(arg: EventContentArg) {
    const title = arg?.event?.title;
    const description = arg?.event?.extendedProps?.description;

    if (calenderView === "listMonth") {
      return (
        <div className="flex items-center gap-[6px]">
          <span className="text-[14px]">{title}</span>
        </div>
      );
    }

    return (
      <div className="flex items-center gap-[6px] p-[6px] px-4">
        <Typography.Paragraph ellipsis style={{ color: "#fff" }}>
          {title}
        </Typography.Paragraph>
        {description && !isMobile && (
          <Tooltip title={description}>
            <span style={{ cursor: "pointer", marginLeft: 4 }}>
              <INFO />
            </span>
          </Tooltip>
        )}
      </div>
    );
  }

  if (isMobile) {
    return (
      <StyledMyCalender token={theme.useToken()?.token} ref={containerRef}>
        <div className="calender-header">
          <div className="calender-title gap-4!">
            <Button onClick={goToToday}>Today</Button>
            <div className="calender-title-date gap-1!">
              <CALENDER width="17" height="17" />
              <Drawer
                onClose={() => setIsPopoverOpen(false)}
                open={isPopoverOpen}
                placement="bottom"
                height={"30%"}
                closable={false}
                style={{
                  borderTopLeftRadius:
                    GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.BORDER_RADIUS,
                  borderTopRightRadius:
                    GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.BORDER_RADIUS,
                }}
                footer={null}
                title={
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Typography.Title level={5}>
                        Select Month
                      </Typography.Title>
                    </div>
                    <Button
                      onClick={() => setIsPopoverOpen(false)}
                      shape="circle"
                    >
                      <CloseOutlined />
                    </Button>
                  </div>
                }
              >
                {calendarPopoverContent}
              </Drawer>
              <Typography.Title
                level={5}
                className="flex items-center gap-2 cursor-pointer"
                ellipsis
                onClick={() => setIsPopoverOpen(true)}
              >
                {calendarTitle}
                <CHEVRON />
              </Typography.Title>
            </div>
          </div>
          <Drawer
            onClose={() => setMobileFilter(false)}
            open={mobileFilter}
            placement="bottom"
            height={"60%"}
            closable={false}
            style={{
              borderTopLeftRadius:
                GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.BORDER_RADIUS,
              borderTopRightRadius:
                GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.BORDER_RADIUS,
            }}
            footer={null}
            styles={{
              body: {
                background: token?.colorGreyBgBase,
                padding: 10,
              },
            }}
            title={
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Typography.Title level={5}>Filters</Typography.Title>
                </div>
                <Button onClick={() => setMobileFilter(false)} shape="circle">
                  <CloseOutlined />
                </Button>
              </div>
            }
          >
            <StyledFilterDrawer token={token}>
              <Tabs
                defaultActiveKey="TYPE"
                tabPosition={"left"}
                style={{
                  height: "100%",
                }}
                items={[
                  {
                    label: "View",
                    key: "TYPE",
                    children: (
                      <div className="py-5 pr-5">
                        <Select
                          value={calenderView}
                          defaultValue="dayGridMonth"
                          onChange={changeView}
                          options={[
                            {
                              label: "Month",
                              value: "dayGridMonth",
                            },
                            {
                              label: "List",
                              value: "listMonth",
                            },
                          ]}
                          className="w-[100%]"
                        />
                      </div>
                    ),
                  },
                  {
                    label: "Search",
                    key: "SEARCH",
                    children: (
                      <div className="py-5 pr-5">
                        <SearchEvent
                          isStudent={isStudent}
                          onEventClick={handleSearchEventClick}
                          callBack={() => setMobileFilter(false)}
                        />
                      </div>
                    ),
                  },
                  {
                    label: "Category",
                    key: "CATEGORY",
                    children: (
                      <div className="py-5 pr-5">
                        <Select
                          value={category || "Category"}
                          prefix={<CATEGORY />}
                          placeholder="Category"
                          allowClear
                          onChange={changeCategory}
                          options={[
                            {
                              label: "Holiday",
                              value: "HOLIDAY",
                            },
                            {
                              label: "Exam",
                              value: "EXAM",
                            },
                            {
                              label: "Other",
                              value: "OTHER",
                            },
                          ]}
                          className="w-[100%]"
                        />
                      </div>
                    ),
                  },
                ]}
              />
            </StyledFilterDrawer>
          </Drawer>
        </div>
        <div className="mobile-custom-actions flex justify-between items-center">
          <div className="flex items-center gap-2">
            <div className="calender-title-actions">
              <Button type="text" shape="circle" onClick={goToPrev}>
                <ARROW_LEFT />
              </Button>
              <Button type="text" shape="circle" onClick={goToNext}>
                <ARROW_RIGHT />
              </Button>
            </div>
            <Button onClick={() => setMobileFilter(true)} icon={<CATEGORY />}>
              Filters
            </Button>
          </div>
          {!isStudent && (
            <Button
              type="primary"
              style={ButtonInlineSmallStyles}
              icon={<DOWNLOAD />}
              className="flex items-center gap-1.5 font-bold"
              onClick={() => {
                setSelectedEvent(null);
                setSelectedDateInfo(null);
                setIsModalOpen(true);
              }}
            >
              New event
            </Button>
          )}
        </div>

        <div className="custom-mobile-calender">
          <Spin spinning={loading}>
            <FullCalendar
              ref={calendarRef}
              plugins={[
                dayGridPlugin,
                timeGridPlugin,
                interactionPlugin,
                listPlugin,
              ]}
              headerToolbar={false}
              initialView="dayGridMonth"
              views={{
                listMonth: {
                  type: "listMonth",
                  duration: { months: 1 },
                  buttonText: "month",
                },
              }}
              events={events}
              editable={!isStudent}
              selectable={!isStudent}
              selectMirror={true}
              dayMaxEvents={true}
              weekends={true}
              eventDrop={isStudent ? undefined : handleEventDrop}
              select={isStudent ? undefined : handleSelect}
              eventClick={handleEventClick}
              datesSet={handleDatesSet}
              height="auto"
              eventContent={renderEventContent}
              eventResize={handleEventResize}
            />
          </Spin>
        </div>
        <EventModal
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          onSave={handleSaveEvent}
          onDelete={handleDeleteEvent}
          event={selectedEvent}
          selectedDateInfo={selectedDateInfo || {}}
          loading={loading}
          isStudent={isStudent}
        />
      </StyledMyCalender>
    );
  }

  return (
    <StyledMyCalender token={theme.useToken()?.token} ref={containerRef}>
      {/* Custom Header */}
      <div className="calender-header">
        <div className="calender-title">
          <div className="calender-title-actions">
            <Tooltip title="Go back" placement="top">
              <Button type="text" shape="circle" onClick={goToPrev}>
                <ARROW_LEFT />
              </Button>
            </Tooltip>
            <Tooltip title="Go next" placement="top">
              <Button type="text" shape="circle" onClick={goToNext}>
                <ARROW_RIGHT />
              </Button>
            </Tooltip>
            <Button onClick={goToToday}>Today</Button>
          </div>
          <div className="calender-title-date">
            <CALENDER />
            <Popover
              content={calendarPopoverContent}
              title="Select month"
              trigger="click"
              open={isPopoverOpen}
              onOpenChange={setIsPopoverOpen}
            >
              <Typography.Title
                level={3}
                className="flex items-center gap-2 cursor-pointer"
                ellipsis
              >
                {calendarTitle}
                <CHEVRON />
              </Typography.Title>
            </Popover>
          </div>
        </div>
        <div className="calender-header-actions">
          <SearchEvent
            isStudent={isStudent}
            onEventClick={handleSearchEventClick}
          />
          <Select
            value={category || "Category"}
            prefix={<CATEGORY />}
            placeholder="Category"
            allowClear
            onChange={changeCategory}
            options={[
              {
                label: "Holiday",
                value: "HOLIDAY",
              },
              {
                label: "Exam",
                value: "EXAM",
              },
              {
                label: "Other",
                value: "OTHER",
              },
            ]}
            className="w-[120px]"
          />
          <Select
            value={calenderView}
            defaultValue="dayGridMonth"
            onChange={changeView}
            options={[
              {
                label: "Month",
                value: "dayGridMonth",
              },
              {
                label: "List",
                value: "listMonth",
              },
            ]}
            className="w-[100px]"
          />
          {!isStudent && (
            <Button
              type="primary"
              style={ButtonInlineStyles}
              icon={<DOWNLOAD />}
              className="flex items-center gap-1.5 font-bold"
              onClick={() => {
                setSelectedEvent(null);
                setSelectedDateInfo(null);
                setIsModalOpen(true);
              }}
            >
              New event
            </Button>
          )}
        </div>
      </div>

      <Spin spinning={loading}>
        <FullCalendar
          ref={calendarRef}
          plugins={[
            dayGridPlugin,
            timeGridPlugin,
            interactionPlugin,
            listPlugin,
          ]}
          headerToolbar={false}
          initialView="dayGridMonth"
          views={{
            listMonth: {
              type: "listMonth",
              duration: { months: 1 },
              buttonText: "month",
            },
          }}
          events={events}
          editable={!isStudent}
          selectable={!isStudent}
          selectMirror={true}
          dayMaxEvents={true}
          weekends={true}
          eventDrop={isStudent ? undefined : handleEventDrop}
          select={isStudent ? undefined : handleSelect}
          eventClick={handleEventClick}
          datesSet={handleDatesSet}
          height="auto"
          eventContent={renderEventContent}
          eventResize={handleEventResize}
        />
      </Spin>
      <EventModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSave={handleSaveEvent}
        onDelete={handleDeleteEvent}
        event={selectedEvent}
        selectedDateInfo={selectedDateInfo || {}}
        loading={loading}
        isStudent={isStudent}
      />
    </StyledMyCalender>
  );
}
