"use client";

import styled from "styled-components";
import { StyledContextProps } from "@/types";
import { mobileNavbarExtraStyles } from "@/components/common/styles.common";
import { GLOBAL_CONSTANTS } from "@/constants";

export const StyledMyCalender = styled.div<StyledContextProps>`
  position: relative;
  display: flex;
  flex-direction: column;
  gap: 30px;

  .calender-header {
    width: 100%;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 20px;
    flex-wrap: wrap;

    ${mobileNavbarExtraStyles}
  }

  .calender-title {
    display: flex;
    align-items: center;
    gap: 20px;
  }

  .calender-title-date {
    display: flex;
    align-items: center;
    gap: 15px;
  }

  .calender-title-actions {
    display: flex;
    align-items: center;
    gap: 5px;
  }

  .calender-header-actions {
    display: flex;
    align-items: center;
    gap: 10px;
    flex-wrap: wrap;
  }

  /* Style calender properties */

  .fc-theme-standard .fc-scrollgrid {
    border: 1px solid ${({ token }) => token?.colorBorder};
    overflow: hidden;
    border-radius: 10px;
  }

  .fc-theme-standard td {
    border-color: ${({ token }) => token?.colorBorder};
  }

  .fc-theme-standard th {
    border-color: ${({ token }) => token?.colorBorder};
  }

  .fc .fc-scrollgrid-section-sticky > * {
    background-color: transparent;
  }

  thead {
    background-color: ${({ token }) => token?.colorCalenderHeader};

    .fc-scrollgrid-sync-inner {
      padding: 8px 12px;
      display: flex;
      font-weight: 500;
      font-size: 14px;

      a {
        color: #6f7c8e;
        text-transform: uppercase;
      }
    }
  }

  .fc-daygrid-day-top {
    a {
      color: ${({ token }) => token?.colorText};
      font-size: 14px;
      font-weight: 400;
    }
  }

  .fc .fc-daygrid-day-top {
    justify-content: center;
  }

  .fc .fc-daygrid-day.fc-day-today {
    background-color: ${({ token }) => token?.colorCalenderActive};
  }

  .fc .fc-highlight {
    background: ${({ token }) => token?.colorPrimary};
    opacity: 0.3 !important;
  }

  .fc-theme-standard .fc-list {
    border: 1px solid ${({ token }) => token?.colorBorder};
    border-radius: 12px;
    overflow: hidden;

    a {
      color: ${({ token }) => token?.colorPrimary};
      font-weight: 500;
    }

    td {
      color: ${({ token }) => token?.colorText};
    }
  }

  .fc .fc-list-empty {
    background-color: ${({ token }) => token?.colorBgBase};
    color: ${({ token }) => token?.colorText};
  }

  .fc-theme-standard .fc-list-day-cushion {
    background-color: transparent;
  }

  .fc .fc-cell-shaded,
  .fc .fc-day-disabled {
    background-color: ${({ token }) => token?.colorCalenderListBg};
  }

  .fc-h-event .fc-event-title-container {
    padding: 4px;
  }

  .fc-daygrid-event {
    border-radius: 8px;
  }

  .fc .fc-list-event:hover td,
  .fc .fc-list-event:hover {
    background: ${({ token }) => token?.colorBgTextHover} !important;
    transition: background 0.2s;
  }

  @media (max-width: ${GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.RESPONSIVE_WIDTH}px) {
    gap: 10px;

    .mobile-custom-actions {
        margin: 0 8px;
        padding: 8px;
        border-radius: 18px;
        background: ${({ token }) => token?.colorBgBase}
    }
  }

  .custom-mobile-calender {
    background: ${({ token }) => token?.colorBgBase};
    padding: 15px 12px;
    border-top-left-radius: ${GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.BORDER_RADIUS}px;
    border-top-right-radius: ${GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.BORDER_RADIUS}px;
    height: calc(100vh - 172px);
    overflow: auto;
  }
`;

export const StyledCalenderForm = styled.div<StyledContextProps>`
  .calender-extra-small-text {
    color: ${({ token }) => token?.colorGreySecondary};
    font-size: 12px;
  }
`;

export const StyledCalenderEvent = styled.div<StyledContextProps>`
  display: flex;
  align-items: center;
  width: 100%;
  gap: 5px;
  background-color: ${({ color }) => color || "#635CFF"};
  padding: 5px 12px;
  border-radius: 8px;
  cursor: pointer;
`;
