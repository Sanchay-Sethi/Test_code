"use client";

import MyCalendar from "./components/MyCalendar";

const AcademicCalender = ({ isStudent = false }: { isStudent?: boolean }) => {
  return <MyCalendar isStudent={isStudent} />;
};

export default AcademicCalender;
