"use client";

import { theme } from "antd";
import { StyledHomeParentWrapper } from "./styles.Home";
import { useEffect, useState } from "react";
import BrandLogo from "../reusable/Loader/BrandLogo/BrandLogo";

const HomeParentWrapper = ({
  children,
}: Readonly<{
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  children: any;
}>) => {
  const { token } = theme.useToken();

  return (
    <StyledHomeParentWrapper token={token}>{children}</StyledHomeParentWrapper>
  );
};

export default HomeParentWrapper;

export const ClientHydrationWrapper = ({
  children,
}: {
  children: React.ReactNode;
}) => {
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    setHydrated(true);
  }, []);

  if (!hydrated) {
    return (
      <BrandLogo/>
    );
  }
  return <>{children}</>;
};
