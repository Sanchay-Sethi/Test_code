import { Button, Popover, theme, Typography } from "antd";
import { DownOutlined } from "@ant-design/icons";
import {
  APPLE_PAY_ICON,
  CARD_PAYMENT_LOGO,
  CASH_PAYMENT_LOGO,
  CHEQUE_PAYMENT_LOGO,
  GOOGLE_PAY_ICON,
  MAESTRO_ICON,
  MAKE_PAYMENT,
  MASTERCARD_ICON,
  ONLINE_PAYMENT_LOGO,
  RECORD_PAYMENT,
  UPI_PAYMENT_LOGO,
  VISA_ICON,
} from "../Icons";
import {
  StyledPaymentDropdownButtons,
  StyledPaymentDropdownList,
  StyledPaymentModeLogos,
  StyledRecordPayment,
} from "../Styles.fee";
import { useState } from "react";
import { ButtonInlineStyles } from "@/components/common/styles.common";
import { useNavigation } from "@/lib/context/NavigationContext";
import { useSearchParams } from "next/navigation";

export const PAYMENT_METHODS: Record<PaymentModeType, React.ReactNode> = {
  ONLINE: <ONLINE_PAYMENT_LOGO />,
  UPI: <UPI_PAYMENT_LOGO />,
  CARD: <CARD_PAYMENT_LOGO />,
  CHEQUE: <CHEQUE_PAYMENT_LOGO />,
  CASH: <CASH_PAYMENT_LOGO />,
};

function PaymentModeLogos({ paymentMode = "" }: { paymentMode?: string }) {
  const { token } = theme.useToken();
  return null; // TODO: WILL REMOVE WHEN LOGO IMAGE NEEDED
  if (paymentMode === "CARD") {
    return (
      <StyledPaymentModeLogos token={token}>
        <div className="logo-mode-container">
          <VISA_ICON />
        </div>
        <div className="logo-mode-container">
          <MASTERCARD_ICON />
        </div>
        <div className="logo-mode-container">
          <MAESTRO_ICON />
        </div>
      </StyledPaymentModeLogos>
    );
  } else if (paymentMode === "UPI") {
    return (
      <StyledPaymentModeLogos token={token}>
        <div className="logo-mode-container">
          <GOOGLE_PAY_ICON />
        </div>
        <div className="logo-mode-container">
          <APPLE_PAY_ICON />
        </div>
      </StyledPaymentModeLogos>
    );
  }
  return null;
}

function ModeLogos({ paymentMode }: { paymentMode?: PaymentModeType }) {
  if (paymentMode !== undefined) {
    return PAYMENT_METHODS?.[paymentMode] || "";
  }
  return "";
}

export function PaymentDropdownList({
  paymentMode,
  onSelectPaymentMode = () => {},
  setOpenDropdown = () => {},
  isDrawer = false,
}: {
  paymentMode?: PaymentModeType;
  onSelectPaymentMode?: (str: PaymentModeType) => void;
  setOpenDropdown?: (flag: boolean) => void;
  isDrawer?: boolean,
}) {
  const { token } = theme.useToken();

  function handleItemSelect(mode: PaymentModeType) {
    onSelectPaymentMode(mode as PaymentModeType);
    setOpenDropdown(false);
  }

  return (
    <StyledPaymentDropdownList isDrawer = {isDrawer}>
      {Object.keys(PAYMENT_METHODS || {})?.map((mode, index) => {
        return (
          <StyledPaymentDropdownButtons
            token={token}
            key={mode}
            onClick={() => handleItemSelect(mode as PaymentModeType)}
            isInDropdown
            hideBorderBottom={
              index === Object.keys(PAYMENT_METHODS)?.length - 1
            }
            isHighlighted={paymentMode === mode}
            isDrawer={isDrawer}
          >
            <div className="payment-details">
              <div className="payment-logo">
                <ModeLogos paymentMode={mode as PaymentModeType} />
              </div>
              <div className="payment-title">
                <p>{mode}</p>
                <PaymentModeLogos paymentMode={mode} />
              </div>
            </div>
          </StyledPaymentDropdownButtons>
        );
      })}
    </StyledPaymentDropdownList>
  );
}

const RecordPayment = ({
  selectedRows = [],
  paymentMode,
  onSelectPaymentMode = () => {},
  onRecordPayment = () => {},
  onMakePayment = () => {},
  isStudentPage = false,
}: {
  selectedRows?: FeeLineItems[];
  paymentMode?: PaymentModeType;
  onSelectPaymentMode?: (str: PaymentModeType) => void;
  onRecordPayment?: () => void;
  onMakePayment?: () => void;
  isStudentPage?: boolean;
}) => {
  const { token } = theme.useToken();
  const { navigate } = useNavigation();
    const searchParams = useSearchParams();
  
  const isPaymentsBackUrl = searchParams.get("backurl") === "payments";

  const isEmpty = selectedRows?.length === 0;

  const [openDropdown, setOpenDropdown] = useState(false);

  function handleCancel() {
    navigate(isPaymentsBackUrl ? "/payments/student-payment" : "/fees");
  }

  return (
    <StyledRecordPayment token={token} isEmpty={isEmpty}>
      {!isStudentPage && (
        <>
          <div className="record-payment-title">
            <Typography.Title level={4}>Mode of collection</Typography.Title>
            <Typography.Paragraph>
              Choose how you would like to collect the fee
            </Typography.Paragraph>
          </div>
          <Popover
            content={
              <PaymentDropdownList
                paymentMode={paymentMode}
                onSelectPaymentMode={onSelectPaymentMode}
                setOpenDropdown={setOpenDropdown}
              />
            }
            trigger="click"
            arrow={false}
            open={openDropdown}
            onOpenChange={setOpenDropdown}
          >
            <StyledPaymentDropdownButtons token={token} isEmpty={isEmpty}>
              <div className="payment-details">
                <div className="payment-logo">
                  <ModeLogos paymentMode={paymentMode} />
                </div>
                <div className="payment-title">
                  <p>{paymentMode}</p>
                  <PaymentModeLogos paymentMode={paymentMode} />
                </div>
              </div>
              <DownOutlined rotate={!openDropdown ? 0 : 180} />
            </StyledPaymentDropdownButtons>
          </Popover>
        </>
      )}
      <div className="fee-footer-container">
        {!isStudentPage && (
          <Button style={ButtonInlineStyles} onClick={handleCancel}>
            Cancel
          </Button>
        )}
        <Button
          disabled={isEmpty}
          style={ButtonInlineStyles}
          icon={isStudentPage ? <MAKE_PAYMENT /> : <RECORD_PAYMENT />}
          type="primary"
          onClick={isStudentPage ? onMakePayment : onRecordPayment}
        >
          {isStudentPage ? "Make" : "Record"} payment
        </Button>
      </div>
    </StyledRecordPayment>
  );
};

export default RecordPayment;
