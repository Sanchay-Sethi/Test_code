"use client";

import FormattedDate from "@/components/reusable/Date/FormattedDate";
import apiClient from "@/lib/apiClient";
import { useGlobalValues } from "@/lib/hooks/useGlobalValues";
import { Table } from "antd";
import { useParams, useSearchParams } from "next/navigation";
import { useEffect, useMemo, useState } from "react";
import { DownloadReceipt } from "../../Settings/Payments/components/StudentsPaymentList";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";
import GeneralSkeleton from "@/components/reusable/Loader/Skeleton/GeneralSkeleton";
import VirtualSwiper from "@/components/reusable/Swiper/virtual/VirtualVerticalSwiper";
import { PaymentCard } from "@/components/reusable/cards/GeneralCards";
import { GENERAL_COMPONENTS } from "@/components/common";

const Receipts = ({ id = "", ay = "" }) => {
  const [tableData, setTableData] = useState<PaymentTypes[]>([]);
  const [loading, setLoading] = useState(false);

  const { CURRENT_ACADEMIC_YEAR } = useGlobalValues();
  const searchParams = useSearchParams();
  const { branchid } = useParams();

  const isMobile = useIsSmallDevice();

  async function getTableData(
    branchid?: string,
    params?: Record<string, string>
  ) {
    try {
      setLoading(true);
      const academicYearId = ay || CURRENT_ACADEMIC_YEAR;
      if (params?.academicYearId) {
        delete params?.["academicYearId"];
      }

      const res = await apiClient.get(
        `/payment/listinfo?branchId=${branchid}&academicYearId=${academicYearId}&studentId=${id}`
      );
      const data = res.data;
      setTableData(data);
    } finally {
      setLoading(false);
    }
  }

  const columns = useMemo(
    () => [
      {
        key: "DATE",
        title: "Payment date",
        dataIndex: "paymentDate",
        ellipsis: true,
        width: 150,
        render: (paymentDate: string) => (
          <FormattedDate dateString={paymentDate} />
        ),
      },
      {
        key: "NAME",
        title: "Name",
        dataIndex: "studentName",
        ellipsis: true,
        width: 150,
      },
      {
        key: "ADMISSION_NUMBER",
        title: "Admission Id",
        dataIndex: "admissionNo",
        ellipsis: true,
        width: 150,
      },
      {
        key: "CLASS",
        title: "Class",
        dataIndex: "className",
        ellipsis: true,
        width: 150,
      },
      {
        key: "MODE",
        title: "Mode",
        dataIndex: "mode",
        ellipsis: true,
        width: 150,
      },
      {
        key: "AMOUNT",
        title: "Amount",
        dataIndex: "amount",
        ellipsis: true,
        width: 150,
        render: (amount: number) => amount?.toLocaleString(),
      },
      {
        key: "Action",
        title: "Action",
        dataIndex: "id",
        ellipsis: true,
        width: 150,
        render: (id: string, details: PaymentTypes) => <DownloadReceipt id={details?.id} />,
      },
    ],
    []
  );

  useEffect(() => {
    // This Effect calls when any change in params
    const params: Record<string, string> = {};
    for (const [key, value] of searchParams?.entries()) {
      params[key] = value;
    }
    if (Object?.keys(params)?.length > 0) {
      getTableData(branchid as string, params);
    } else {
      getTableData(branchid as string);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchParams, branchid]);


   if (isMobile) {
    return (
      <>
        {loading ? (
          <GeneralSkeleton
            countSmall={0}
            countLarge={10}
            isLargeWrapped
            largeBoxHeight={100}
          />
        ) : tableData?.length === 0 && !loading ? (
          <GENERAL_COMPONENTS.NoResult />
        ) : (
          <VirtualSwiper
            items={tableData || []}
            getKey={(data) => data?.id || ""}
            cardEstimateWidth={180}
            containerHeight={"calc(100vh - 200px)"}
            renderItem={(details) => (
              <PaymentCard
                data={details}
                extra={<DownloadReceipt id={details?.id} />}
              />
            )}
          />
        )}
      </>
    );
  }

  return (
    <>
      <Table
        dataSource={tableData}
        loading={loading}
        columns={columns}
        sticky={true}
        tableLayout={"fixed"}
        scroll={{ x: "max-content" }}
        pagination={{
          position: ["bottomRight"],
          total: (tableData || [])?.length,
          showTotal: (total) => `Total ${total} items`,
          align: "center",
        }}
      />
    </>
  );
};

export default Receipts;
