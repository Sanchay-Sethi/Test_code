import { Checkbox, Table, theme, Typography } from "antd";
import { StyledPayableFeeTable, StyledPayableMobileFee } from "../Styles.fee";
import { useMemo, useState } from "react";
import { getStudentFeesWithKey } from "../Helpers.fee";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";
import { GENERAL_COMPONENTS } from "@/components/common";
import VirtualSwiper from "@/components/reusable/Swiper/virtual/VirtualVerticalSwiper";
import StudentFeeTermCard from "@/components/reusable/cards/StudentFeeMobileCard/StudentFeeTermCard";

const PayableFeeTable = ({
  studentFeeDetails,
  onRowSelection = () => {},
}: {
  studentFeeDetails?: StudentFeeTypes;
  onRowSelection?: (Arr: FeeLineItems[]) => void;
}) => {
  const isMobile = useIsSmallDevice();
  const { token } = theme.useToken();

  const [selectedRowKeys, setSelectedRowKeys] = useState<string[]>([]);

  const dataSource = useMemo(
    () => getStudentFeesWithKey(studentFeeDetails?.items || []) || [],
    [studentFeeDetails]
  );

  const columns = useMemo(
    () => [
      {
        key: "name",
        title: "Pending fees",
        dataIndex: "name",
        ellipsis: true,
        width: 150,
      },
      {
        key: "dueDate",
        title: "Due dates",
        dataIndex: "dueDate",
        ellipsis: true,
        width: 150,
      },
      {
        key: "dues",
        title: "Dues",
        dataIndex: "dues",
        ellipsis: true,
        width: 150,
      },
      {
        key: "paid",
        title: "Paid",
        dataIndex: "paid",
        ellipsis: true,
        width: 150,
        render: (paid: string) => `Rs. ${paid}`,
      },
      {
        key: "toPay",
        title: "To pay",
        dataIndex: "toPay",
        ellipsis: true,
        width: 150,
        render: (toPay: string) => `Rs. ${toPay}`,
      },
    ],
    []
  );

  function selectTerm(record: FeeLineItems, selected: boolean) {
    const clickedIndex = dataSource.findIndex(
      (item) => item.key === record.key
    );

    let updatedKeys: string[];

    if (selected) {
      updatedKeys = dataSource
        .slice(0, clickedIndex + 1)
        .map((item) => item.key!);
    } else {
      updatedKeys = dataSource.slice(0, clickedIndex).map((item) => item.key!);
    }

    setSelectedRowKeys(updatedKeys);
    onRowSelection(
      dataSource?.filter((item) => updatedKeys.includes(item?.key as string))
    );
  }

  function selectAllTerm(selected: boolean) {
    const updatedKeys = selected ? dataSource.map((item) => item.key!) : [];
    setSelectedRowKeys(updatedKeys);
    onRowSelection(
      dataSource?.filter((item) => updatedKeys.includes(item?.key as string))
    );
  }

  function getIsDisabled(record: FeeLineItems) {
    const index = dataSource.findIndex((item) => item.key === record.key);
    const isDisabled =
      selectedRowKeys.length < index &&
      !selectedRowKeys.includes(record.key || "");
    return isDisabled;
  }

  const rowSelection = {
    selectedRowKeys,
    onSelect: (record: FeeLineItems, selected: boolean) => {
      selectTerm(record, selected);
    },
    onSelectAll: (selected: boolean) => {
      selectAllTerm(selected);
    },
    // getCheckboxProps: (record: FeeLineItems): Partial<CheckboxProps> => {
    //   const index = dataSource.findIndex(item => item.key === record.key);
    //   const isDisabled =
    //     selectedRowKeys.length < index && !selectedRowKeys.includes(record.key || "");
    //   return { disabled: isDisabled };
    // },
  };

  if (isMobile) {
    return (
      <>
        {dataSource?.length === 0 ? (
          <GENERAL_COMPONENTS.NoResult />
        ) : (
          <StyledPayableMobileFee token={token}>
            <div
              className="total-payable-fee-container"
              onClick={() =>
                selectAllTerm(!(selectedRowKeys?.length === dataSource?.length))
              }
            >
              <div className="flex items-center gap-2.5">
                <Checkbox
                  checked={selectedRowKeys?.length === dataSource?.length}
                  onChange={(e) => selectAllTerm(e.target.checked)}
                />
                <Typography.Text strong>PENDING FEES</Typography.Text>
              </div>
              <Typography.Text strong>TO PAY</Typography.Text>
            </div>
            <VirtualSwiper
              items={dataSource || []}
              getKey={(student) => student?.studentId || student?.key || ""}
              cardEstimateWidth={135}
              containerHeight={selectedRowKeys?.length > 0 ? "calc(-360px + 100vh)" : "calc(-265px + 100vh)"}
              renderItem={(studentFee) => (
                <StudentFeeTermCard
                  details={studentFee}
                  onClick={selectTerm}
                  isSelected={selectedRowKeys?.includes(studentFee?.key || "")}
                  isDisabled={getIsDisabled(studentFee)}
                />
              )}
            />
          </StyledPayableMobileFee>
        )}
      </>
    );
  }

  return (
    <StyledPayableFeeTable>
      <Typography.Title level={5}>Payable fees</Typography.Title>
      <Table
        columns={columns}
        dataSource={dataSource}
        sticky
        tableLayout="fixed"
        scroll={{ x: "max-content" }}
        pagination={false}
        rowSelection={rowSelection}
      />
    </StyledPayableFeeTable>
  );
};

export default PayableFeeTable;
