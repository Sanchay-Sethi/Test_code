"use client";

import { Button, Drawer, theme, Typography } from "antd";
import { CHARGE_ICON } from "../Icons";
import { getTotalFeesToPay } from "../Helpers.fee";
import { StyledMobileFeePayment } from "../Styles.fee";
import { useState } from "react";
import { GLOBAL_CONSTANTS } from "@/constants";
import { PaymentDropdownList } from "./RecordPayment";

const MobileFeePayment = ({
  selectedRows = [],
  paymentMode,
  onSelectPaymentMode = () => {},
  onRecordPayment = () => {},
  onMakePayment = () => {},
  isStudentPage = false,
}: {
  selectedRows?: FeeLineItems[];
  paymentMode?: PaymentModeType;
  onSelectPaymentMode?: (str: PaymentModeType) => void;
  onRecordPayment?: () => void;
  onMakePayment?: () => void;
  isStudentPage?: boolean;
}) => {
  const { token } = theme.useToken();

  const [isDrawerOpen, setIsDrawerOpen] = useState(false);

  const showDrawer = () => {
    setIsDrawerOpen(true);
  };

  const onCloseDrawer = () => {
    setIsDrawerOpen(false);
  };

  function handleClick() {
    if (selectedRows?.length === 0) return;
    if (isStudentPage) {
      onMakePayment();
    } else {
      if (isDrawerOpen) {
        if (paymentMode) {
          onRecordPayment();
          setIsDrawerOpen(false);
        }
      } else {
        showDrawer();
      }
    }
  }

  return (
    <StyledMobileFeePayment token={token} show={selectedRows?.length > 0}>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <CHARGE_ICON />
          <Typography.Title level={5} type="secondary" ellipsis>
            Total fee to pay
          </Typography.Title>
        </div>
        <Typography.Title
          level={5}
          ellipsis
          title={getTotalFeesToPay(selectedRows)?.toLocaleString()}
        >
          Rs {getTotalFeesToPay(selectedRows)?.toLocaleString()}
        </Typography.Title>
      </div>
      <Button
        type="primary"
        block
        disabled={isDrawerOpen ? !paymentMode : selectedRows?.length === 0}
        onClick={handleClick}
        style={{
          fontSize: 16,
        }}
      >
        {isStudentPage ? "Pay now" : "Record payment"}
      </Button>
      <Drawer
        closable={false}
        onClose={onCloseDrawer}
        open={isDrawerOpen}
        placement="bottom"
        zIndex={1}
        height={"75%"}
        style={{
          borderTopLeftRadius:
            GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.BORDER_RADIUS,
          borderTopRightRadius:
            GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.BORDER_RADIUS,
        }}
      >
        <div className="flex flex-col gap-8">
          <div className="flex flex-col gap-1">
            <Typography.Title level={5}>Mode of collection</Typography.Title>
            <Typography.Paragraph type="secondary">
              Choose how you would like to collect the fee
            </Typography.Paragraph>
          </div>
          <PaymentDropdownList
            paymentMode={paymentMode}
            onSelectPaymentMode={onSelectPaymentMode}
            isDrawer
          />
        </div>
      </Drawer>
    </StyledMobileFeePayment>
  );
};

export default MobileFeePayment;
