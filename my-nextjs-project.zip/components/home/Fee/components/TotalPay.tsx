import { theme } from "antd";
import { FEE_ICON } from "../../Students/Icons";
import { StyledTotalPay } from "../Styles.fee";
import { getTotalFeesToPay } from "../Helpers.fee";

const TotalPay = ({
  selectedRows = [],
  isStudentPage = false,
}: {
  selectedRows?: FeeLineItems[];
  isStudentPage?: boolean;
}) => {
  const { token } = theme.useToken();

  const isEmpty = selectedRows?.length === 0;

  return (
    <StyledTotalPay isEmpty={isEmpty} token={token}>
      <p className="fee-title">
        <FEE_ICON />{" "}
        {isEmpty
          ? `Select the fee structure above to ${isStudentPage ? "make" : "record"} the payment`
          : "TOTAL FEES TO PAY"}
      </p>
      {!isEmpty && (
        <p className="fee-dues">
          Rs {getTotalFeesToPay(selectedRows)?.toLocaleString()}
        </p>
      )}
    </StyledTotalPay>
  );
};

export default TotalPay;
