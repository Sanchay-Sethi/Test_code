"use client";

import { useEffect, useState } from "react";
import { Button, Popover, Select, theme, Typography } from "antd";
import { useSearchParams } from "next/navigation";
import { CaretDownOutlined } from "@ant-design/icons";
import { GLOBAL_CONSTANTS } from "@/constants";
import { StyledNavbar, StyledStatus } from "../Styles.fee";
import { SideMenuIcons } from "../../Sidebar/Icons";
import { GENERAL_COMPONENTS } from "@/components/common";
import { RightArrow } from "../Icons";
import { useNavigation } from "@/lib/context/NavigationContext";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";

const { Title } = Typography;

// eslint-disable-next-line @typescript-eslint/no-unused-vars
const Status = ({ handleClick = (status?: string) => {} }) => {
  return (
    <StyledStatus>
      {Object.keys(GLOBAL_CONSTANTS.STUDENT_FEE_STATUS)?.map((status) => {
        return (
          <Button
            key={status}
            type="text"
            style={{
              justifyContent: "flex-start",
            }}
            onClick={() => handleClick(status)}
          >
            {
              GLOBAL_CONSTANTS.STUDENT_FEE_STATUS?.[
                status as keyof typeof GLOBAL_CONSTANTS.STUDENT_FEE_STATUS
              ]
            }{" "}
            students
          </Button>
        );
      })}
    </StyledStatus>
  );
};

const Navbar = ({
  academicYearId = "",
  statusInit = "",
  studentName = "",
  studentAdmissionNumber = "",
  academicYearList = [],
  isStudentPage = false,
}: {
  academicYearId?: string;
  statusInit?: string;
  studentName?: string;
  isStudentPage?: boolean;
  studentAdmissionNumber?: string;
  academicYearList?: AcademicYearListTypes[];
}) => {
  const { token } = theme.useToken();
  const { navigate } = useNavigation();
  const searchParams = useSearchParams();

  const isMobile = useIsSmallDevice();

  const isPaymentsBackUrl = searchParams.get("backurl") === "payments";

  const [openDropdown, setOpenDropdown] = useState(false);
  const [status, setStatus] = useState(statusInit);

  function handleOpenChange(newOpen = false) {
    setOpenDropdown(newOpen);
  }

  function handleStatusDropdownOptionChange(status: string = "") {
    if (status === "ALL") {
      setStatus("");
    } else if (status === "overdueOnly") {
      setStatus("true");
    } else {
      setStatus(status);
    }
    setOpenDropdown(false);
  }

  function handleAcadmicYearChange(val = "") {
    const params = new URLSearchParams(searchParams.toString());
    if (val) {
      params.set("academicYearId", val);
      navigate(`?${params.toString()}`);
    }
  }

  useEffect(() => {
    const params = new URLSearchParams(searchParams.toString());
    if (status) {
      params.set("overdueOnly", status?.trim());
    } else {
      params.delete("overdueOnly");
    }

    navigate(`?${params.toString()}`);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [status]);

  return (
    <StyledNavbar token={token}>
      <div className="flex items-center gap-5">
        {studentName && !isStudentPage && (
          <GENERAL_COMPONENTS.BackButton backUrl={isPaymentsBackUrl ? "/payments/student-payment" : "/fees"} />
        )}
        <div className="nav-studentlist-header">
          <div className="nav-header-navtitle flex items-center gap-[10px]">
            <div className="flex items-center gap-2">
              {SideMenuIcons.FEES()}
              <Typography.Paragraph>
                Fee {!isStudentPage && "collection"}
              </Typography.Paragraph>
            </div>
            {studentName && !isStudentPage && (
              <>
                <RightArrow />
                <Typography.Paragraph>Fee</Typography.Paragraph>
              </>
            )}
          </div>
          {studentName ? (
            <div className="nav-studentlist-dropdown-view">
              <Title level={isMobile ? 5 : 3} style={{ marginBottom: 0 }} ellipsis>
                {studentName}
              </Title>
              {studentAdmissionNumber && (
                <div className="tag-container">
                  <Typography.Text>{studentAdmissionNumber}</Typography.Text>
                </div>
              )}
            </div>
          ) : (
            <Popover
              content={
                <Status handleClick={handleStatusDropdownOptionChange} />
              }
              trigger="click"
              arrow={false}
              open={openDropdown}
              onOpenChange={handleOpenChange}
            >
              <div className="nav-studentlist-dropdown">
                {isMobile ? (
                  <Typography.Paragraph>
                    {!status
                      ? "All"
                      : status === "true"
                      ? "Overdue only"
                      : GLOBAL_CONSTANTS.STUDENT_FEE_STATUS?.[
                          status as keyof typeof GLOBAL_CONSTANTS.STUDENT_FEE_STATUS
                        ]}{" "}
                    students
                  </Typography.Paragraph>
                ) : (
                  <Title level={3} style={{ marginBottom: 0 }}>
                    {!status
                      ? "All"
                      : status === "true"
                      ? "Overdue only"
                      : GLOBAL_CONSTANTS.STUDENT_FEE_STATUS?.[
                          status as keyof typeof GLOBAL_CONSTANTS.STUDENT_FEE_STATUS
                        ]}{" "}
                    students
                  </Title>
                )}
                <CaretDownOutlined
                  rotate={openDropdown ? 180 : 0}
                  style={{
                    color: token?.colorIcon,
                    fontSize: isMobile ? "10px" : "16px",
                  }}
                />
              </div>
            </Popover>
          )}
        </div>
      </div>
      {!isStudentPage && !isMobile && (
        <div className="nav-studentlist-actions">
          <Typography.Paragraph>Academic year</Typography.Paragraph>
          <Select
            style={{ width: 120 }}
            value={academicYearId}
            onChange={handleAcadmicYearChange}
            options={academicYearList}
          />
        </div>
      )}
    </StyledNavbar>
  );
};

export default Navbar;
