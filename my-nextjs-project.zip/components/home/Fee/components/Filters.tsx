"use client";

import { useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import { Button, Input } from "antd";
import { SearchOutlined } from "@ant-design/icons";
import { useDebounce } from "@/lib/hooks/useDebounce";
import { StyledFilters } from "../Styles.fee";
import { FILTER_ICON } from "../../Students/Icons";
import { useNavigation } from "@/lib/context/NavigationContext";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";

const Filters = ({ nameSearchInit }: { nameSearchInit: string }) => {
  const { navigate } = useNavigation();
  const searchParams = useSearchParams();
  const isMobile = useIsSmallDevice();

  const [nameSearch, setNameSearch] = useState(nameSearchInit);
  const debouncedSearch = useDebounce(nameSearch, 500);

  function handleChange(key = "", value = "") {
    if (key === "nameSearch") {
      setNameSearch(value);
    }
  }

  useEffect(() => {
    const params = new URLSearchParams(searchParams.toString());
    if (debouncedSearch) {
      params.set("studentNameSearch", debouncedSearch?.trim());
    } else {
      params.delete("studentNameSearch");
    }

    navigate(`?${params.toString()}`);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debouncedSearch]);

  return (
    <StyledFilters>
      <div className="filter-search">
        <Input
          type="text"
          prefix={<SearchOutlined />}
          placeholder="Search by name"
          className="search-input"
          value={nameSearch}
          onChange={(e) => handleChange("nameSearch", e.target.value)}
          size={isMobile ? "small" : "middle"}
          style={
            isMobile
              ? { borderRadius: "8px", padding: "2px 15px", fontSize: 14 }
              : {}
          }
        />
      </div>
      {isMobile ? null : (
        <div className="filter-container">
          <Button
            icon={<FILTER_ICON />}
            shape="circle"
            className="filter-mock-button"
          />
        </div>
      )}
    </StyledFilters>
  );
};

export default Filters;
