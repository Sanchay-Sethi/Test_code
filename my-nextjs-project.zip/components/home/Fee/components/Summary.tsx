import { Skeleton, theme, Typography } from "antd";
import { SwiperSlide } from "swiper/react";
import SwiperContent from "@/components/reusable/Swiper/SwiperContent";
import { StyledSummary, StyledSummaryMobile } from "../Styles.fee";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";
import { StyledMobileSpacedContainer } from "@/components/common/styles.common";

const Summary = ({
  feeListing,
  hide = false,
  loading = false,
}: {
  feeListing?: StudentFeeTypes;
  hide?: boolean;
  loading?: boolean;
}) => {
  const { token } = theme.useToken();
  const isMobile = useIsSmallDevice();

  if (isMobile) {
    return (
      <StyledMobileSpacedContainer>
        <StyledSummaryMobile token={token} hide={hide}>
          <div className="summary-single-card-mobile">
            <Typography.Text
              style={{
                fontSize: 18,
                fontWeight: 500,
              }}
              ellipsis
            >
              {loading ? (
                <Skeleton.Node style={{ height: "20px" }} active />
              ) : (
                <>₹ {feeListing?.totalDues?.toLocaleString()}</>
              )}
            </Typography.Text>
            <Typography.Paragraph ellipsis style={{ fontSize: "12px" }}>
              Total dues
            </Typography.Paragraph>
          </div>
          <div className="summary-single-card-mobile">
            <Typography.Text
              style={{
                fontSize: 18,
                fontWeight: 500,
              }}
              ellipsis
            >
              {loading ? (
                <Skeleton.Node style={{ height: "20px" }} active />
              ) : (
                <>₹ {feeListing?.totalPaid?.toLocaleString()}</>
              )}
            </Typography.Text>
            <Typography.Paragraph ellipsis style={{ fontSize: "12px" }}>
              Collected till date
            </Typography.Paragraph>
          </div>
          <div className="summary-single-card-mobile">
            <Typography.Text
              style={{
                fontSize: 18,
                fontWeight: 500,
              }}
            >
              {loading ? (
                <Skeleton.Node style={{ height: "20px" }} active />
              ) : (
                <>{feeListing?.totalOverdue?.toLocaleString()}</>
              )}
            </Typography.Text>
            <Typography.Paragraph ellipsis style={{ fontSize: "12px" }}>
              Total overdue
            </Typography.Paragraph>
          </div>
          <div className="summary-single-card-mobile">
            <Typography.Text
              style={{
                fontSize: 18,
                fontWeight: 500,
              }}
            >
              {loading ? (
                <Skeleton.Node style={{ height: "20px" }} active />
              ) : (
                <>{feeListing?.overDueStudents?.toLocaleString()}</>
              )}
            </Typography.Text>
            <Typography.Paragraph ellipsis style={{ fontSize: "12px" }}>
              Overdue students
            </Typography.Paragraph>
          </div>
        </StyledSummaryMobile>
      </StyledMobileSpacedContainer>
    );
  }

  return (
    <StyledSummary token={token}>
      <Typography.Title level={5}>Payment summary</Typography.Title>
      <SwiperContent>
        <SwiperSlide>
          <div className="payment-specific-slide">
            <Typography.Text
              style={{
                fontSize: 24,
                fontWeight: 500,
              }}
              ellipsis
            >
              {loading ? (
                <Skeleton.Node style={{ height: "20px" }} active />
              ) : (
                <>₹ {feeListing?.totalDues?.toLocaleString()}</>
              )}
            </Typography.Text>
            <Typography.Paragraph ellipsis>Total dues</Typography.Paragraph>
          </div>
        </SwiperSlide>
        <SwiperSlide>
          <div className="payment-specific-slide">
            <Typography.Text
              style={{
                fontSize: 24,
                fontWeight: 500,
              }}
              ellipsis
            >
              {loading ? (
                <Skeleton.Node style={{ height: "20px" }} active />
              ) : (
                <>₹ {feeListing?.totalPaid?.toLocaleString()}</>
              )}
            </Typography.Text>
            <Typography.Paragraph ellipsis>
              Collected till date
            </Typography.Paragraph>
          </div>
        </SwiperSlide>
        <SwiperSlide>
          <div className="payment-specific-slide">
            <Typography.Text
              style={{
                fontSize: 24,
                fontWeight: 500,
              }}
            >
              {loading ? (
                <Skeleton.Node style={{ height: "20px" }} active />
              ) : (
                <>{feeListing?.totalOverdue?.toLocaleString()}</>
              )}
            </Typography.Text>
            <Typography.Paragraph ellipsis>Total overdue</Typography.Paragraph>
          </div>
        </SwiperSlide>
        <SwiperSlide>
          <div className="payment-specific-slide">
            <Typography.Text
              style={{
                fontSize: 24,
                fontWeight: 500,
              }}
            >
              {loading ? (
                <Skeleton.Node style={{ height: "20px" }} active />
              ) : (
                <>{feeListing?.overDueStudents?.toLocaleString()}</>
              )}
            </Typography.Text>
            <Typography.Paragraph ellipsis>
              Overdue students
            </Typography.Paragraph>
          </div>
        </SwiperSlide>
      </SwiperContent>
    </StyledSummary>
  );
};

export default Summary;
