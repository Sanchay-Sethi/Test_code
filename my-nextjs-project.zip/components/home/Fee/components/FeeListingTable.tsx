"use client";

import { useMemo, useState } from "react";
import { Table } from "antd";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";
import { useNavigation } from "@/lib/context/NavigationContext";
import { StyledMobileSpacedContainer } from "@/components/common/styles.common";
import GeneralSkeleton from "@/components/reusable/Loader/Skeleton/GeneralSkeleton";
import { GENERAL_COMPONENTS } from "@/components/common";
import VirtualSwiper from "@/components/reusable/Swiper/virtual/VirtualVerticalSwiper";
import StudentFeeMobileCard from "@/components/reusable/cards/StudentFeeMobileCard/StudentFeeMobileCard";

const FeeListingTable = ({
  loading = false,
  offsetInit = "",
  limitInit = "",
  sortInit = "",
  orderInit = "",
  feeListing = [],
  onExtra = () => {},
}: {
  loading: boolean;
  offsetInit: string;
  limitInit: string;
  sortInit: string;
  orderInit: string;
  feeListing: FeeLineItems[];
  onExtra?: (flag: boolean) => void;
}) => {
  const isSmallDevice = useIsSmallDevice(900);
  const isMobile = useIsSmallDevice();
  const { navigate } = useNavigation();

  const [dynamicContainerHeight, setDynamicContainerHeight] = useState(
    "calc(-318px + 100vh)"
  );

  const columns = useMemo(
    () => [
      {
        key: "ADMISSION_NUMBER",
        title: "Admission Id",
        dataIndex: "admissionNumber",
        ellipsis: true,
        width: 150,
      },
      {
        key: "NAME",
        title: "Name",
        dataIndex: "studentName",
        ellipsis: true,
        width: 150,
      },
      {
        key: "PROGRAM_NAME",
        title: "Program",
        dataIndex: "programName",
        ellipsis: true,
        width: 150,
      },
      {
        key: "DUES",
        title: "Dues",
        dataIndex: "dues",
        ellipsis: true,
        width: 150,
      },
      {
        key: "PAID",
        title: "Collected",
        dataIndex: "paid",
        ellipsis: true,
        width: 150,
        render: (paid: string) => `Rs. ${paid}`,
      },
      {
        key: "OVERDUE",
        title: "Overdue amount",
        dataIndex: "overdue",
        ellipsis: true,
        width: 150,
        render: (overdue: string) => `Rs. ${overdue}`,
      },
      {
        key: "MAX_OVERDUE_DAYS",
        title: "Overdue days",
        dataIndex: "maxOverdueDays",
        ellipsis: true,
        width: 150,
      },
    ],
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [sortInit, orderInit]
  );

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const handleRowClick = (record: any) => {
    if (record?.studentId) {
      navigate(`/fees/${record?.studentId}`);
    }
  };

  if (isMobile) {
    return (
      <StyledMobileSpacedContainer>
        {loading ? (
          <GeneralSkeleton
            countSmall={0}
            countLarge={10}
            isLargeWrapped
            largeBoxHeight={100}
          />
        ) : feeListing?.length === 0 && !loading ? (
          <GENERAL_COMPONENTS.NoResult />
        ) : (
          <VirtualSwiper
            items={feeListing || []}
            getKey={(student) => student?.studentId || student?.key || ""}
            cardEstimateWidth={182}
            containerHeight={dynamicContainerHeight}
            onScrollChange={(isScrolling) => {
              if (isScrolling) {
                setDynamicContainerHeight("calc(-150px + 100vh)");
              } else {
                setDynamicContainerHeight("calc(-318px + 100vh)");
              }
              onExtra(isScrolling);
            }}
            renderItem={(studentFee) => (
              <StudentFeeMobileCard
                details={studentFee}
                onClick={handleRowClick}
              />
            )}
          />
        )}
      </StyledMobileSpacedContainer>
    );
  }

  return (
    <Table
      loading={loading}
      columns={columns}
      dataSource={feeListing || []}
      sticky={true}
      tableLayout={"fixed"}
      onRow={(record) => ({
        onClick: () => handleRowClick(record),
      })}
      rowClassName={() => "student-clickable-row"}
      scroll={{ x: "max-content" }}
      pagination={{
        position: ["bottomRight"],
        total: (feeListing || [])?.length,
        showTotal: (total) => `Total ${total} items`,
        showSizeChanger: true,
        showQuickJumper: true,
        defaultCurrent: offsetInit ? parseInt(offsetInit) : 1,
        defaultPageSize: limitInit ? parseInt(limitInit) : 10,
        // hideOnSinglePage: true,
        size: isSmallDevice ? "small" : "default",
        align: "center",
      }}
      // summary={(pageData) => {
      //   let totalDues = 0;
      //   let totalPaid = 0;
      //   let totalMaxOverdueDays = 0;

      //   pageData?.forEach(({ paid, dues, maxOverdueDays }) => {
      //     totalDues += dues || 0;
      //     totalPaid += paid || 0;
      //     totalMaxOverdueDays += maxOverdueDays || 0;
      //   });

      //   if (feeListing?.length <= 1) return null;

      //   return (
      //     <Table.Summary.Row>
      //       <Table.Summary.Cell index={0} colSpan={3}>
      //         <strong>Total</strong>
      //       </Table.Summary.Cell>
      //       <Table.Summary.Cell index={3}>
      //         <strong>Rs {totalPaid.toLocaleString()}</strong>
      //       </Table.Summary.Cell>
      //       <Table.Summary.Cell index={4}>
      //         <strong>Rs {totalDues.toLocaleString()}</strong>
      //       </Table.Summary.Cell>
      //       <Table.Summary.Cell index={5}>
      //         <strong>{totalMaxOverdueDays.toLocaleString()} days on avg</strong>
      //       </Table.Summary.Cell>
      //     </Table.Summary.Row>
      //   );
      // }}
    />
  );
};

export default FeeListingTable;
