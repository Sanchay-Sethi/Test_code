import apiClient from "@/lib/apiClient";

export async function getNecessaryPayload(academicYearId = "", setAcademicYearId: (id: string) => void, params?: Record<string, string>) {
    try {
        if (params?.academicYearId) {
            const ay = params?.academicYearId;
            delete params?.academicYearId;
            setAcademicYearId(ay);
            return {
                academicYearId: ay,
                params
            }
        }
        let academicYearIdRes;
        if (!academicYearId) {
            academicYearIdRes = await apiClient.get("/ay");
            academicYearIdRes = academicYearIdRes?.data?.id;
            setAcademicYearId(academicYearIdRes);
            return {
                academicYearId: academicYearIdRes,
                params
            }
        }
        setAcademicYearId(academicYearId);
        return {
            academicYearId: academicYearId,
            params
        }

    } catch (error) {
        throw error;
    }
}

export function getStudentFeesWithKey(items: StudentFeeLineItemTypes[]): FeeLineItems[] {
  return (items || [])
    ?.filter(item => item?.toPay !== 0)
    ?.map((item, index) => ({
      key: `${item?.name ?? 'item'}_${index}_${item?.type ?? 'type'}`,
      name: item?.name ?? '',
      type: item?.type ?? '',
      dueDate: item?.dueDate ?? '',
      overdueDays: item?.overdueDays ?? 0,
      dues: item?.dues ?? 0,
      paid: item?.paid ?? 0,
      toPay: item?.toPay ?? 0,
    }));
}
export function getTotalFeesToPay(selectedRows: FeeLineItems[]) {
    return selectedRows?.reduce((sum, item) => sum + (item?.toPay || 0), 0);
}