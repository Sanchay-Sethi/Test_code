"use client";

import styled, { css } from "styled-components";
import { StyledContextProps } from "@/types";
import { GLOBAL_CONSTANTS } from "@/constants";
import { AddInlineMobilePadding, mobileNavbarExtraStyles } from "@/components/common/styles.common";

export const StyledFee = styled.div<StyledContextProps>`
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  gap: ${({ gap }) => (gap ? `${gap}px` : "20px")};

  ${({ disabled }) => disabled && css`
    pointer-events: none;
    opacity: 0.4;
  `}

  .ant-table-thead > tr > th {
    background: transparent;
    font-weight: 500;
    text-transform: uppercase;
  }

  .ant-table-tbody > tr > td,
  .ant-table-wrapper tfoot > tr > td {
    padding: 12px 16px;
  }

  .sort-icon {
    opacity: 0;
    transition: opacity 0.2s ease-in-out;
  }

  .sortable-column:hover .sort-icon {
    opacity: 1;
  }

  .student-clickable-row {
    cursor: pointer;
    transition: color 0.4s ease;
  }

  .student-clickable-row:hover td {
    color: ${({ token }) => token?.colorLink};
  }

  .ant-table-wrapper {
    height: ${({ feeHeightTable }) =>
      feeHeightTable ? "100%" : "calc(100vh - 165px)"};
    overflow: auto;

    .ant-pagination {
      position: sticky;
      bottom: 0px;
      background-color: ${({ token }) => token?.colorBgBase};
      padding: 12px 20px;
      margin: 0px;
      z-index: 10;
    }
  }

  @media (max-width: ${GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.RESPONSIVE_WIDTH}px) {
    .ant-pagination {
      display: flex;
      justify-content: center;
    }

    gap: 12px;
  }
`;

export const StyledNavbar = styled.div<StyledContextProps>`
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 15px;
  flex-wrap: wrap;

  .ant-typography {
    margin-bottom: 0;
  }

  .tag-container {
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 4px 6px;
    background-color: ${({ token }) => token?.colorCustomTag};
    border-radius: 8px;
    font-weight: 500;
  }

  .nav-header-navtitle {
    display: flex;
    align-items: center;
    gap: 5px;
  }

  .nav-studentlist-header {
    display: flex;
    flex-direction: column;
    gap: 5px;
    flex-wrap: wrap;
  }

  .nav-studentlist-dropdown {
    display: flex;
    align-items: center;
    gap: 10px;
    cursor: pointer;
  }

  .nav-studentlist-dropdown-view {
    display: flex;
    align-items: center;
    gap: 10px;
  }

  .nav-studentlist-actions {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 10px;
  }

  ${mobileNavbarExtraStyles};

  @media (max-width: ${GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.RESPONSIVE_WIDTH}px) {
    .nav-studentlist-dropdown {
      border-radius: 20px;
      padding: 2px 12px;
      border: 1px solid ${({ token }) => token?.colorBorder};
    }

    .nav-studentlist-header {
      flex-direction: row;
      gap: 8px;
    }
  }

`;

export const StyledStatus = styled.div`
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 10px;
`;

export const StyledFilters = styled.div`
  display: flex;
  align-items: center;
  gap: 20px;
  flex-wrap: wrap;

  .filter-container {
    display: flex;
    align-items: center;
    gap: 15px;
    flex-wrap: wrap;
  }

  .search-input {
    .ant-input-prefix {
      svg {
        color: #697386;
      }
    }
  }

  ${AddInlineMobilePadding}
`;

export const StyledSummaryMobile = styled.div<StyledContextProps>`
  width: 100%;
  display: flex;
  flex-wrap: wrap;
  align-items: stretch;
  gap: 1px;
  border-radius: 10px;
  overflow: hidden;

  .summary-single-card-mobile {
    width: 49.8%;
    display: flex;
    flex-direction: column;
    gap: 1px;
    justify-content: center;
    align-items: center;
    padding: 15px 20px;
    background-color: ${({ token }) => token?.colorBgCard};
  }

  overflow: hidden;
  transition:
    opacity 0.6s cubic-bezier(0.65, 0, 0.35, 1),
    transform 0.6s cubic-bezier(0.65, 0, 0.35, 1),
    max-height 0.6s cubic-bezier(0.65, 0, 0.35, 1);

  opacity: ${({ hide }) => (hide ? 0 : 1)};
  transform: ${({ hide }) =>
    hide ? "translateY(-20px)" : "translateY(0)"};
  max-height: ${({ hide }) => (hide ? "0px" : "500px")};
  
  @media (max-width: 280px) {
    .summary-single-card-mobile {
      width: 100%;
    }
  }
`;

export const StyledSummary = styled.div<StyledContextProps>`
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 10px;

  .ant-typography {
    margin-bottom: 0px;
  }

  .payment-specific-slide {
    width: 100%;
    box-shadow: 0px 1px 16px 0px #0000000f;
    border-radius: 8px;
    display: flex;
    flex-direction: column;
    gap: 5px;
    justify-content: center;
    align-items: center;
    padding: 16px 20px;
    background-color: ${({ token }) => token?.colorBgCard};
  }
`;

export const StyledPayableFeeTable = styled.div`
  display: flex;
  flex-direction: column;
  gap: 10px;
`;

export const StyledPayableMobileFee = styled.div<StyledContextProps>`
  display: flex;
  flex-direction: column;
  gap: 12px;

  .total-payable-fee-container {
    background-color: ${({ token }) => token?.colorBgBase};
    padding: 10px 15px;
    border-radius: 8px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 2px;
  }
`

export const StyledTotalPay = styled.div<StyledContextProps>`
  display: flex;
  flex-direction: column;

  .fee-title {
    display: flex;
    align-items: center;
    gap: 10px;
    color: ${({ token }) => token?.colorGreySecondary};
    font-size: 13px;
    ${({ isEmpty }) =>
      isEmpty &&
      css`
        font-size: 14px;
        font-weight: 600;
      `};
  }

  .fee-dues {
    color: ${({ token }) => token?.colorText};
    font-size: 24px;
    font-weight: 700;
  }
`;

export const StyledRecordPayment = styled.div<StyledContextProps>`
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 10px;

  .fee-footer-container {
    padding: 10px 0px;
    border-radius: 20px;
    background-color: ${({ token }) => token?.colorBgBase};
    display: flex;
    align-items: center;
    gap: 12px;
  }

  ${({ isEmpty }) =>
    isEmpty &&
    css`
      .record-payment-title {
        pointer-events: none;
        opacity: 0.3;
      }
    `};
`;

export const StyledPaymentDropdownButtons = styled.div<StyledContextProps>`
  width: ${({ isInDropdown }) => (isInDropdown ? "100%" : "50%")};
  display: flex;
  justify-content: space-between;
  align-items: center;
  cursor: pointer;
  transition: ${({ isDrawer }) => !isDrawer && "0.3s all ease"};
  padding: 6px 10px;
  ${({ isInDropdown, token }) =>
    !isInDropdown &&
    css`
      border-top: 1px solid ${token?.colorBorder};
    `}
  ${({ hideBorderBottom, token }) =>
    !hideBorderBottom &&
    css`
      border-bottom: 1px solid ${token?.colorBorder};
    `}

    ${({ isEmpty }) =>
    isEmpty &&
    css`
        pointer-events: none;
        opacity: 0.3;
    `};

  .payment-details {
    display: flex;
    align-items: center;
    gap: 12px;

    .payment-title {
      display: flex;
      flex-direction: column;
      gap: 4px;

      p {
        color: ${({ token }) => token?.colorText};
        font-weight: 600;
      }
    }
  }

  ${({ isHighlighted, token, isDrawer }) =>
    isHighlighted &&
    css`
      background-color: ${isDrawer ? token?.colorPrimaryBgHover : token?.colorBgTextHover};
      border: 1px solid ${isDrawer ? token?.colorPrimary : "transparent"};
      border-radius: ${isDrawer ? "4px" : "0px"};
    `}

  &:hover {
    background-color: ${({ token, isDrawer }) => !isDrawer && token?.colorPrimaryBgHover};
  }
`;

export const StyledPaymentModeLogos = styled.div<StyledContextProps>`
  display: flex;
  align-items: stretch;
  gap: 2px;

  .logo-mode-container {
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 4px 8px;
    border-radius: 4px;
    border: 1px solid ${({ token }) => token?.colorBorder};
  }
`;

export const StyledPaymentDropdownList = styled.div<StyledContextProps>`
  display: flex;
  flex-direction: column;
  width: ${({ isDrawer }) => isDrawer ? "100%" : "400px"};
`;

export const StyledMobileFeePayment = styled.div<StyledContextProps>`
  padding: 18px 18px;
  display: flex;
  flex-direction: column;
  gap: 15px;
  background-color: ${({ token }) => token?.colorBgBase};
  box-shadow: 0px 1px 12px 0px #0000003D;
  z-index: 2;
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  width: 100%;
  border-top-right-radius: ${GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.BORDER_RADIUS}px;
  border-top-left-radius: ${GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.BORDER_RADIUS}px;
  transform: ${({ show }) => (show ? 'translateY(0)' : 'translateY(100%)')};
  transition: transform 0.4s cubic-bezier(0.68, -0.55, 0.27, 1.55);
`;
