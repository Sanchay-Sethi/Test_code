"use client";

import { useEffect, useState } from "react";
import { useParams, useSearchParams } from "next/navigation";
import apiClient from "@/lib/apiClient";
import { StyledFee } from "./Styles.fee";
import { getNecessaryPayload } from "./Helpers.fee";
import Navbar from "./components/Navbar";
import Filters from "./components/Filters";
import Summary from "./components/Summary";
import FeeListingTable from "./components/FeeListingTable";
import { theme } from "antd";

const Fee = () => {
  const searchParams = useSearchParams();
  const { token } = theme.useToken();
  const { branchid = "" } = useParams();

  const [hideSummary, setHideSummary] = useState(false);

  const [loading, setLoading] = useState(false);
  const [feeListing, setFeeListing] = useState<StudentFeeTypes>({});
  const [academicYearId, setAcademicYearId] = useState("");
  const [academicYearList, setAcademicYearList] = useState<
    AcademicYearListTypes[]
  >([]);

  async function fetchFeeListing(
    branchid: string,
    params?: Record<string, string>
  ) {
    try {
      setLoading(true);
      if (academicYearList?.length === 0) {
        const academicYearList = await apiClient.get("/ay/list");
        const academicYearOptions = academicYearList?.data?.map(
          (data: { name?: string; id?: string }) => {
            return {
              label: data?.name,
              value: data?.id,
            };
          }
        );
        setAcademicYearList(academicYearOptions);
      }

      const payload = await getNecessaryPayload(
        academicYearId,
        setAcademicYearId,
        params
      );

      const queryString = payload?.params
        ? "&" + new URLSearchParams(payload?.params).toString()
        : "";

      const res = await apiClient.get(
        `/fee/calc/list/${payload?.academicYearId}?branchId=${branchid}${queryString}`
      );
      const data = res?.data;
      setFeeListing(data);
    } finally {
      setLoading(false);
      setHideSummary(false);
    }
  }

  function handleHideUnhideSummary(isScrolling = false) {
    if (isScrolling === true) {
      setHideSummary(true);
    } else {
      setHideSummary(false);
    }
  }

  useEffect(() => {
    const params: Record<string, string> = {};
    for (const [key, value] of searchParams?.entries()) {
      params[key] = value;
    }
    if (Object?.keys(params)?.length > 0) {
      fetchFeeListing(branchid as string, params);
    } else {
      fetchFeeListing(branchid as string);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchParams]);

  return (
    <StyledFee token={token}>
      <Navbar
        academicYearId={academicYearId}
        academicYearList={academicYearList}
        statusInit={
          searchParams.get("overdueOnly")
            ? searchParams.get("overdueOnly")?.toString()
            : ""
        }
      />
      <Filters nameSearchInit={searchParams.get("studentNameSearch") || ""} />
      <Summary feeListing={feeListing} hide = {hideSummary} loading={loading}/>
      <FeeListingTable
        loading={loading}
        feeListing={feeListing?.items || []}
        offsetInit={searchParams.get("offset") || ""}
        limitInit={searchParams.get("limit") || ""}
        sortInit={searchParams.get("sort") || ""}
        orderInit={searchParams.get("order") || ""}
        onExtra={handleHideUnhideSummary}
      />
    </StyledFee>
  );
};

export default Fee;
