interface FeeLineItems {
    key?: string,
    type: string;
    studentId?: string,
    studentName?: string,
    admissionNumber?: string,
    programName?: string,
    sectionName?: string,
    dues?: number,
    paid?: number,
    toPay?: number,
    overdue?: number,
    maxOverdueDays?: number,
    name?: string,
    dueDate?: string,
}

interface StudentFeeTypes {
    totalDues?: number,
    totalPaid?: number,
    totalToPay?: number,
    totalOverdue?: number,
    totalOverdueDays?: number,
    overDueStudents?: number,
    averageOverdueDays?: number,
    items?: FeeLineItems[]
}

interface AcademicYearListTypes {
  label?: string;
  value?: string;
}

interface StudentDetailsTypes {
    branchName?: string,
    className?: string,
    hostelPlanName?: string,
    transportPlanName?: string,
    profile: {
        id?: string,
        branchId?: string,
        status?: string,
        name?: string,
        phoneNumber?: string,
        secondaryPhoneNumber?: string,
        email?: string,
        dateOfBirth?: string,
        gender?: string,
        admissionNumber?: string,
        admissionYear?: string,
        address?: string,
        fatherName?: string,
        motherName?: string,
        createdAt?: string,
        updatedAt?: string,
        image?: string,
    },
    enrolment: {
        id?: string,
        studentId?: string,
        academicYearId?: string,
        classId?: string,
        newAdmission?: boolean,
        transportPlanId?: string,
        hostelPlanId?: string,
        discountIds?: Array[],
        previousDues?: BigInteger,
        createdAt?: string,
        updatedAt?: string,
    }
}

type PaymentModeType = 'ONLINE' | 'CASH' | 'UPI' | 'CHEQUE' | 'CARD';

