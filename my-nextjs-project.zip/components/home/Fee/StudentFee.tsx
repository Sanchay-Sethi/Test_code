"use client";

import { Button, Empty, Spin, Tabs, theme, Typography } from "antd";
import { StyledFee } from "./Styles.fee";
import Navbar from "./components/Navbar";
import { useGlobalContext } from "@/lib/context/GlobalContext";
import apiClient from "@/lib/apiClient";
import { useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import GeneralSkeleton from "@/components/reusable/Loader/Skeleton/GeneralSkeleton";
import PayableFeeTable from "./components/PayableFeeTable";
import TotalPay from "./components/TotalPay";
import RecordPayment from "./components/RecordPayment";
import { getStudentFeesWithKey, getTotalFeesToPay } from "./Helpers.fee";
import HELPERS from "@/lib/helpers";
import { useNavigation } from "@/lib/context/NavigationContext";
import { handleMakePaymentRazorpay } from "@/lib/razorpay/studentFeePayment";
import { StyledMobileSpacedContainer } from "@/components/common/styles.common";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";
import MobileFeePayment from "./components/MobileFeePayment";
import Receipts from "./components/Receipts";
import { useGetAcademicYearByStudent } from "@/lib/hooks/useGetAcademicYearByStudent";

const TAB_KEYS = ["FEES", "RECEIPT", "STATEMENT"];

const StudentFee = ({
  id = "",
  isStudentPage = false,
}: {
  id?: string;
  isStudentPage?: boolean;
}) => {
  const isMobile = useIsSmallDevice();
  const { token } = theme.useToken();
  const searchParams = useSearchParams();
  const { state } = useGlobalContext();
  const { navigate } = useNavigation();

  const { data } = useGetAcademicYearByStudent(id);

  const paramMode = searchParams.get("mode");

  const [mode, setMode] = useState("");

  const [loading, setLoading] = useState(false);
  const [studentFeeDetails, setStudentFeeDetails] = useState<StudentFeeTypes>(
    {}
  );
  const [studentDetails, setStudentDetails] = useState<StudentDetailsTypes>();
  const [selectedRows, setSelectedRows] = useState<FeeLineItems[]>();
  const [paymentMode, setPaymentMode] = useState<PaymentModeType>("CASH");
  const [recording, setRecording] = useState(false);
  const [paymentLoader, setPaymentLoader] = useState(false);

  const isEmptyRecord =
    getStudentFeesWithKey(studentFeeDetails?.items as FeeLineItems[])
      ?.length === 0;

  function handleRowSelection(rows: FeeLineItems[]) {
    setSelectedRows(rows);
  }

  function handleSelectPaymentMode(mode: PaymentModeType) {
    setPaymentMode(mode);
  }

  async function getFeeDetails(params?: Record<string, string>) {
    try {
      setLoading(true);
      const ay = params?.academicYearId || state?.academicYear?.academicYearId;
      if (ay) {
        const studentFee = await apiClient.get(`/fee/calc/student/${ay}/${id}`);
        setStudentFeeDetails(studentFee?.data);
      }
      const student = await apiClient.get(`/student/${id}`);
      setStudentDetails(student?.data);
    } finally {
      setLoading(false);
    }
  }

  function resetPage() {
    setSelectedRows([]);
    const params: Record<string, string> = {};
    for (const [key, value] of searchParams?.entries()) {
      params[key] = value;
    }
    if (Object?.keys(params)?.length > 0) {
      getFeeDetails(params);
    } else {
      getFeeDetails();
    }
  }

  function callBackAfterPayment() {
    resetPage();
  }

  async function handleMakePayment() {
    if (!selectedRows || selectedRows.length === 0) {
      HELPERS.messageAlert({ error: "Please select at least one fee to pay." });
      return;
    }
    const academicYearId =
      searchParams.get("academicYearId") || state.academicYear.academicYearId;
    await handleMakePaymentRazorpay({
      amount: getTotalFeesToPay(selectedRows as FeeLineItems[]),
      studentId: id,
      academicYearId,
      callback: () => callBackAfterPayment(),
      setLoader: setPaymentLoader,
    });
  }

  async function handleRecordPayment() {
    try {
      setRecording(true);
      const academicYearId =
        searchParams.get("academicYearId") || state.academicYear.academicYearId;
      const studentId = id;
      const amount = getTotalFeesToPay(selectedRows as FeeLineItems[]);
      const mode = paymentMode;

      const res = await apiClient.post("/payment", {
        academicYearId,
        studentId,
        amount,
        mode,
      });

      if (res?.data) {
        HELPERS.messageAlert({ success: "Record added successfully" });
        resetPage();
      }
    } finally {
      setRecording(false);
    }
  }

  function handleBackClick() {
    navigate("/fees");
  }

  const handleTabChange = (key: string) => {
    setMode(key);
    const params = new URLSearchParams(searchParams?.toString());
    params.set("mode", key?.trim());
    navigate(`?${params.toString()}`);
  };

  const items = [
    {
      key: "FEES",
      label: "Fees",
      children: (
        <div className="flex flex-col gap-10">
          {loading ? (
            <StyledMobileSpacedContainer>
              <GeneralSkeleton />
            </StyledMobileSpacedContainer>
          ) : (
            <>
              {isEmptyRecord ? (
                <Empty
                  style={{
                    padding: "50px 0px",
                  }}
                  description={
                    <Typography.Text>All fees have been paid!</Typography.Text>
                  }
                >
                  {!isStudentPage && (
                    <Button type="primary" onClick={handleBackClick}>
                      Back to listing
                    </Button>
                  )}
                </Empty>
              ) : (
                <>
                  <PayableFeeTable
                    studentFeeDetails={studentFeeDetails}
                    onRowSelection={handleRowSelection}
                  />
                  {isMobile ? (
                    <MobileFeePayment
                      isStudentPage={isStudentPage}
                      paymentMode={paymentMode}
                      onSelectPaymentMode={handleSelectPaymentMode}
                      onRecordPayment={handleRecordPayment}
                      onMakePayment={handleMakePayment}
                      selectedRows={selectedRows}
                    />
                  ) : (
                    <>
                      <TotalPay
                        selectedRows={selectedRows}
                        isStudentPage={isStudentPage}
                      />
                      <RecordPayment
                        selectedRows={selectedRows}
                        paymentMode={paymentMode}
                        onSelectPaymentMode={handleSelectPaymentMode}
                        onRecordPayment={handleRecordPayment}
                        onMakePayment={handleMakePayment}
                        isStudentPage={isStudentPage}
                      />
                    </>
                  )}
                  <Spin size="large" fullscreen spinning={paymentLoader} />
                </>
              )}
            </>
          )}
        </div>
      ),
    },
    {
      key: "RECEIPT",
      label: "Receipts",
      children: (
        <Receipts
          id={id}
          ay={
            searchParams.get("academicYearId") ||
            state.academicYear.academicYearId
          }
        />
      ),
    },
  ];

  useEffect(() => {
    if (paramMode && TAB_KEYS?.includes(paramMode)) {
      setMode(paramMode);
    } else {
      setMode("FEES");
    }
  }, [paramMode]);

  useEffect(() => {
    const params: Record<string, string> = {};
    for (const [key, value] of searchParams?.entries()) {
      params[key] = value;
    }
    if (Object?.keys(params)?.length > 0) {
      getFeeDetails(params);
    } else {
      getFeeDetails();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchParams, state?.academicYear]);

  return (
    <StyledFee token={token} gap={40} feeHeightTable disabled={recording}>
      <Navbar
        academicYearId={
          searchParams.get("academicYearId") ||
          state.academicYear.academicYearId
        }
        academicYearList={data || []}
        studentName={studentDetails?.profile?.name}
        studentAdmissionNumber={studentDetails?.profile?.admissionNumber}
        isStudentPage={isStudentPage}
      />
      <StyledMobileSpacedContainer>
        <Tabs
          activeKey={mode}
          items={items}
          onChange={handleTabChange}
          type={isMobile ? "line" : "card"}
          tabBarStyle={
            isMobile
              ? {
                  background: token?.colorBgBase,
                  paddingInline: 16,
                  borderRadius: 12,
                  overflow: "auto",
                }
              : {}
          }
        />
      </StyledMobileSpacedContainer>
    </StyledFee>
  );
};

export default StudentFee;
