interface SchoolsDetailsProps {
    id?: number;
    name?: string;
    displayName?: string;
    features?: string[];
    createdAt?: string;
    updatedAt?: string;
}