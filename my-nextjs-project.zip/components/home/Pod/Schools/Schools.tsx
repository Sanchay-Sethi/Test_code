"use client";
import { useEffect, useState } from "react";
import { message, UploadFile } from "antd";
import { helpers } from "@/lib";
import apiClient from "@/lib/apiClient";
import { useGlobalContext } from "@/lib/context/GlobalContext";
import Navbar from "./components/Navbar";
import SchoolListing from "./components/SchoolListing";
import ImportModal from "@/components/reusable/Upload/ImportModal";
import { StyledCommonContainer } from "@/components/common/styles.common";

const Schools = () => {
  const { updateOrgs } = useGlobalContext();
  const [details, setDetails] = useState<SchoolsDetailsProps[]>();
  const [loading, setLoading] = useState(false);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);

  async function getDetails() {
    try {
      setLoading(true);
      const res = await apiClient.get("/org");
      setDetails(res?.data);
      updateOrgs(res?.data);
    } finally {
      setLoading(false);
    }
  }

  async function handleUpload(files: UploadFile[]) {
    if (files?.length === 0) {
      message.error("File is not selected, please select again");
      return;
    }
    setLoading(true);
    try {
      if (files?.[0]?.originFileObj) {
        const formData = new FormData();
        formData.append("file", files?.[0]?.originFileObj);
        const res = await apiClient.post(`/upload`, formData);
        helpers.messageAlert({info: (res?.data || [])?.map((x : string) => ` ${x} `)?.toString()})
        getDetails();
      }
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    getDetails();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <StyledCommonContainer>
      <Navbar
        getListingData={getDetails}
        onImportClick={() => setIsImportModalOpen(true)}
      />
      <SchoolListing
        loading={loading}
        listingData={details}
        getListingData={getDetails}
      />
      <ImportModal
        open={isImportModalOpen}
        onClose={() => setIsImportModalOpen(false)}
        onUpload={handleUpload}
        accept=".xlsx,.xls"
      />
    </StyledCommonContainer>
  );
};

export default Schools;
