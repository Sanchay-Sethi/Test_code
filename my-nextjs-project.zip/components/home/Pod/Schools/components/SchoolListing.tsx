"use client";

import { useMemo, useState } from "react";
import { Button, Table, TableColumnsType, theme } from "antd";
import { BiTrashAlt } from "react-icons/bi";
import { HiOutlinePencil } from "react-icons/hi";
import apiClient from "@/lib/apiClient";
import HELPERS from "@/lib/helpers";
import FormattedDate from "@/components/reusable/Date/FormattedDate";
import SchoolModal from "./SchoolModal";
import {
  StyledListingTable,
  StyledMobileSpacedContainer,
} from "@/components/common/styles.common";
import { useParams } from "next/navigation";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";
import GeneralSkeleton from "@/components/reusable/Loader/Skeleton/GeneralSkeleton";
import { GENERAL_COMPONENTS } from "@/components/common";
import VirtualSwiper from "@/components/reusable/Swiper/virtual/VirtualVerticalSwiper";
import { SchoolCard } from "@/components/reusable/cards/GeneralCards";
import ConfirmDeleteModal from "@/components/reusable/Modal/common/ConfirmDeleteModal";

const SchoolListing = ({
  loading = false,
  listingData = [],
  getListingData = () => {},
}: {
  loading?: boolean;
  listingData?: SchoolsDetailsProps[];
  getListingData?: () => void;
}) => {
  const { orgid } = useParams();
  const { token } = theme.useToken();
  const [activeId, setActiveId] = useState("");
  const [deleteModal, setDeleteModal] = useState("");

  const isMobile = useIsSmallDevice();

  function taskAfterSubmit() {
    setActiveId("");
    getListingData();
  }

  async function handleAction(id: string | number | undefined, key = "") {
    if (!id) return;
    if (key === "EDIT") {
      setActiveId(`${id}`);
    } else if (key === "DELETE") {
      if (`${orgid}` === `${id}`)
        return HELPERS.messageAlert({ error: "Action not allowed" });
      try {
        await apiClient.delete(`/org/${id}`);
        HELPERS.messageAlert({ error: "Deleted successfully" });
      } finally {
        getListingData();
        setDeleteModal("");
      }
    }
  }

  const columns: TableColumnsType<SchoolsDetailsProps> = useMemo(
    () => [
      {
        title: "Name",
        dataIndex: "name",
        ellipsis: true,
        width: 150,
      },
      {
        title: "Display Name",
        dataIndex: "displayName",
        ellipsis: true,
        width: 200,
      },
      {
        title: "Created at",
        dataIndex: "createdAt",
        ellipsis: true,
        render: (createdAt: string) => {
          return <FormattedDate dateString={createdAt} />;
        },
        width: 150,
      },
      {
        title: "Updated at",
        dataIndex: "updatedAt",
        ellipsis: true,
        render: (updatedAt: string) => {
          return <FormattedDate dateString={updatedAt} />;
        },
        width: 150,
      },
      {
        title: "Action",
        dataIndex: "id",
        ellipsis: true,
        width: 100,
        fixed: "right",
        render: (id = "") => {
          return (
            <div className="flex items-center gap-2">
              <Button
                type="text"
                icon={<HiOutlinePencil />}
                color="primary"
                variant="filled"
                onClick={() => handleAction(id, "EDIT")}
              >
                Edit
              </Button>
              {`${orgid}` !== `${id}` && (
                <>
                  <Button
                    type="text"
                    icon={<BiTrashAlt />}
                    color="danger"
                    variant="filled"
                    onClick={() => setDeleteModal(id)}
                  >
                    Delete
                  </Button>
                </>
              )}
            </div>
          );
        },
      },
    ],
    // eslint-disable-next-line react-hooks/exhaustive-deps
    []
  );

  if (isMobile) {
    return (
      <StyledMobileSpacedContainer>
        {loading ? (
          <GeneralSkeleton
            countSmall={0}
            countLarge={10}
            isLargeWrapped
            largeBoxHeight={100}
          />
        ) : listingData?.length === 0 && !loading ? (
          <GENERAL_COMPONENTS.NoResult />
        ) : (
          <VirtualSwiper
            items={listingData}
            getKey={(data) => data?.id || ""}
            containerHeight="calc(100vh - 130px)"
            cardEstimateWidth={120}
            renderItem={(data) => (
              <SchoolCard
                data={data}
                onEdit={() => handleAction(data?.id, "EDIT")}
                onDelete={() => handleAction(data?.id, "DELETE")}
                deleteShown={`${orgid}` !== `${data?.id}`}
              />
            )}
          />
        )}
        <SchoolModal
          id={activeId}
          open={!!activeId}
          onCancel={() => setActiveId("")}
          taskAfterSubmit={taskAfterSubmit}
        />
      </StyledMobileSpacedContainer>
    );
  }

  return (
    <StyledListingTable token={token}>
      <Table
        dataSource={listingData}
        columns={columns}
        loading={loading}
        scroll={{ x: "max-content", y: 100 * 5 }}
      />
      <SchoolModal
        id={activeId}
        open={!!activeId}
        onCancel={() => setActiveId("")}
        taskAfterSubmit={taskAfterSubmit}
      />
      <ConfirmDeleteModal
        open={!!deleteModal}
        onConfirm={() => handleAction(deleteModal, "DELETE")}
        onCancel={() => setDeleteModal("")}
      />
    </StyledListingTable>
  );
};

export default SchoolListing;
