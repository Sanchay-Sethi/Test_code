"use client"

import { useState } from "react";
import { Button, theme, Typography } from "antd";
import { AiOutlineImport } from "react-icons/ai";
import { AiOutlinePlus } from "react-icons/ai";
import { SideMenuIcons } from "@/components/home/Sidebar/Icons";
import SchoolModal from "./SchoolModal";
import { StyledCommonNavbar } from "@/components/common/styles.common";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";

const Navbar = ({
  getListingData = () => {},
  onImportClick = () => {},
}: {
  getListingData?: () => void;
  onImportClick?: () => void;
}) => {
  const [openModal, setOpenModal] = useState(false);

  const { token } = theme.useToken();
  const isMobile = useIsSmallDevice();

  function taskAfterSubmit() {
    setOpenModal(false);
    getListingData();
  }

  return (
    <StyledCommonNavbar token={token}>
      <div className="flex-col gap-1.5">
        <div className="flex items-center gap-1.5">
          {SideMenuIcons.POD()}
          <Typography.Paragraph>Pod</Typography.Paragraph>
        </div>
        <Typography.Title level={isMobile ? 5 : 2}>Schools</Typography.Title>
      </div>
      <div className="flex items-center gap-1.5">
        <Button
          icon={<AiOutlineImport />}
          onClick={onImportClick}
        >
          Import
        </Button>
        <Button
          type="primary"
          icon={<AiOutlinePlus />}
          onClick={() => setOpenModal(true)}
        >
          Create school
        </Button>
      </div>
      <SchoolModal
        open={openModal}
        onCancel={() => setOpenModal(false)}
        taskAfterSubmit={taskAfterSubmit}
      />
    </StyledCommonNavbar>
  );
};

export default Navbar;
