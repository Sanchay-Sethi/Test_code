"use client";

import { useState } from "react";
import { Button, theme, Typography } from "antd";
import { AiOutlinePlus } from "react-icons/ai";
import { SideMenuIcons } from "@/components/home/Sidebar/Icons";
import { StyledCommonNavbar } from "@/components/common/styles.common";
import AdminModal from "./AdminModal";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";

const Navbar = ({
  getListingData = () => {},
}: {
  getListingData?: () => void;
}) => {
  const [openModal, setOpenModal] = useState(false);

  const { token } = theme.useToken();

  const isMobile = useIsSmallDevice();

  function taskAfterSubmit() {
    setOpenModal(false);
    getListingData();
  }

  return (
    <StyledCommonNavbar token={token}>
      <div className="flex-col gap-1.5">
        <div className="flex items-center gap-1.5">
          {SideMenuIcons.POD()}
          <Typography.Paragraph>Pod</Typography.Paragraph>
        </div>
        <Typography.Title level={isMobile ? 5 : 2}>Admins</Typography.Title>
      </div>
      <Button
        type="primary"
        icon={<AiOutlinePlus />}
        onClick={() => setOpenModal(true)}
      >
        Create pod admin
      </Button>
      <AdminModal
        open={openModal}
        onCancel={() => setOpenModal(false)}
        taskAfterSubmit={taskAfterSubmit}
      />
    </StyledCommonNavbar>
  );
};

export default Navbar;
