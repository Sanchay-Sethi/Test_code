"use client";

import { useMemo, useState } from "react";
import { Button, Popconfirm, Table, TableColumnsType, theme } from "antd";
import { BiTrashAlt } from "react-icons/bi";
import { HiOutlinePencil } from "react-icons/hi";
import apiClient from "@/lib/apiClient";
import HELPERS from "@/lib/helpers";
import FormattedDate from "@/components/reusable/Date/FormattedDate";
import {
  StyledListingTable,
  StyledMobileSpacedContainer,
} from "@/components/common/styles.common";
import AdminModal from "./AdminModal";
import { useGlobalContext } from "@/lib/context/GlobalContext";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";
import GeneralSkeleton from "@/components/reusable/Loader/Skeleton/GeneralSkeleton";
import { GENERAL_COMPONENTS } from "@/components/common";
import VirtualSwiper from "@/components/reusable/Swiper/virtual/VirtualVerticalSwiper";
import { AdminCard } from "@/components/reusable/cards/GeneralCards";

const AdminListing = ({
  loading = false,
  listingData = [],
  getListingData = () => {},
}: {
  loading?: boolean;
  listingData?: PodAdminProps[];
  getListingData?: () => void;
}) => {
  const { state } = useGlobalContext();
  const { token } = theme.useToken();
  const [activeId, setActiveId] = useState("");

  const isMobile = useIsSmallDevice();

  const loggedInUserId = state?.user?.accessMap?.userId;

  function taskAfterSubmit() {
    setActiveId("");
    getListingData();
  }

  async function handleAction(id = "", key = "") {
    if (key === "EDIT") {
      setActiveId(id);
    } else if (key === "DELETE") {
      if (id === loggedInUserId) return;
      try {
        await apiClient.delete(`/user/podadmin/${id}`);
        HELPERS.messageAlert({ error: "Deleted successfully" });
      } finally {
        getListingData();
      }
    }
  }

  const columns: TableColumnsType<PodAdminProps> = useMemo(
    () => [
      {
        title: "Name",
        dataIndex: "name",
        ellipsis: true,
        width: 100,
      },
      {
        title: "Phone number",
        dataIndex: "mobile",
        ellipsis: true,
        width: 150,
      },
      {
        title: "Email",
        dataIndex: "email",
        ellipsis: true,
        width: 170,
      },
      {
        title: "Created at",
        dataIndex: "createdAt",
        ellipsis: true,
        render: (createdAt: string) => {
          return <FormattedDate dateString={createdAt} />;
        },
        width: 150,
      },
      {
        title: "Updated at",
        dataIndex: "updatedAt",
        ellipsis: true,
        render: (updatedAt: string) => {
          return <FormattedDate dateString={updatedAt} />;
        },
        width: 150,
      },
      {
        title: "Action",
        dataIndex: "id",
        ellipsis: true,
        width: 100,
        fixed: "right",
        render: (id = "") => {
          return (
            <div className="flex items-center gap-2">
              <Button
                type="text"
                icon={<HiOutlinePencil />}
                color="primary"
                variant="filled"
                onClick={() => handleAction(id, "EDIT")}
              >
                Edit
              </Button>
              {`${loggedInUserId}` !== `${id}` && (
                <Popconfirm
                  title="Delete school"
                  description="Are you sure to delete this school?"
                  onConfirm={() => handleAction(id, "DELETE")}
                  okText="Yes"
                  cancelText="No"
                >
                  <Button
                    type="text"
                    icon={<BiTrashAlt />}
                    color="danger"
                    variant="filled"
                  >
                    Delete
                  </Button>
                </Popconfirm>
              )}
            </div>
          );
        },
      },
    ],
    // eslint-disable-next-line react-hooks/exhaustive-deps
    []
  );

  if (isMobile) {
    return (
      <StyledMobileSpacedContainer>
        {loading ? (
          <GeneralSkeleton
            countSmall={0}
            countLarge={10}
            isLargeWrapped
            largeBoxHeight={100}
          />
        ) : listingData?.length === 0 && !loading ? (
          <GENERAL_COMPONENTS.NoResult />
        ) : (
          <VirtualSwiper
            items={listingData}
            getKey={(data) => data?.id || ""}
            containerHeight="calc(100vh - 130px)"
            cardEstimateWidth={120}
            renderItem={(data) => (
              <AdminCard
                data={data}
                onEdit={() => handleAction(data?.id, "EDIT")}
                onDelete={() => handleAction(data?.id, "DELETE")}
                deleteShown={`${loggedInUserId}` !== `${data?.id}`}
              />
            )}
          />
        )}
        <AdminModal
          id={activeId}
          open={!!activeId}
          onCancel={() => setActiveId("")}
          taskAfterSubmit={taskAfterSubmit}
        />
      </StyledMobileSpacedContainer>
    );
  }

  return (
    <StyledListingTable token={token}>
      <Table
        dataSource={listingData}
        columns={columns}
        loading={loading}
        scroll={{ x: "max-content", y: 100 * 5 }}
      />
      <AdminModal
        id={activeId}
        open={!!activeId}
        onCancel={() => setActiveId("")}
        taskAfterSubmit={taskAfterSubmit}
      />
    </StyledListingTable>
  );
};

export default AdminListing;
