"use client";
import { useEffect, useState } from "react";
import apiClient from "@/lib/apiClient";
import { useGlobalContext } from "@/lib/context/GlobalContext";
import { StyledCommonContainer } from "@/components/common/styles.common";
import AdminListing from "./components/AdminListing";
import Navbar from "./components/Navbar";

const Admins = () => {
  const { state, updateLoggedInUser } = useGlobalContext();
  const [details, setDetails] = useState<PodAdminProps[]>();
  const [loading, setLoading] = useState(false);

  async function getDetails() {
    try {
      setLoading(true);
      const res = await apiClient.get("/user/podadmin");
      setDetails(res?.data);

      const user = (res?.data || [])?.find(
        (detail: { id: "string" }) =>
          detail?.id === state?.user?.accessMap?.userId
      );
      if (user) {
        updateLoggedInUser(user?.id, user?.name);
      }
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    getDetails();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <StyledCommonContainer>
      <Navbar getListingData={getDetails} />
      <AdminListing
        loading={loading}
        listingData={details}
        getListingData={getDetails}
      />
    </StyledCommonContainer>
  );
};

export default Admins;
