interface PodAdminProps {
    id?: string;
    name?: string;
    mobile?: string;
    email?: string;
    podAdmin?: boolean;
    createdAt?: string;
    updatedAt?: string;
}