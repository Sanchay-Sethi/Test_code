"use client";

import { useEffect, useState } from "react";
import Navbar from "./components/Navbar";
import { StyledAnnouncements } from "./Styles";
import { useParams, useSearchParams } from "next/navigation";
import { theme } from "antd";
import apiClient from "@/lib/apiClient";
import Filters from "./components/Filters";
import AnnounceList from "./components/AnnounceList";
import AnnouncementForm from "./components/AnnouncementForm";
import { useNavigation } from "@/lib/context/NavigationContext";

const Announcements = ({ id = "", isStudent = false }: { id?: string, isStudent?: boolean }) => {
  const searchParams = useSearchParams();
  const { token } = theme.useToken();
  const { branchid = "" } = useParams();
  const { navigate } = useNavigation();

  const [loading, setLoading] = useState(false);
  const [announceListing, setAnnounceListing] = useState<AnnounceTypes[]>([]);

  async function getAnnounceListing(
    branchid: string,
    params?: Record<string, string>
  ) {
    try {
      setLoading(true);
      const queryString = params
        ? "?" + new URLSearchParams(params).toString()
        : "";

      const res = await apiClient.get(
        `/announce/list/${branchid}${queryString}`
      );
      const data = res.data;
      setAnnounceListing(data);
    } finally {
      setLoading(false);
    }
  }

  function handleCancel() {
    navigate(isStudent ? "/student-view/announcements" : "/announcements");
  }

  function getAnnoucementListingDetails() {
    const params: Record<string, string> = {};
    for (const [key, value] of searchParams?.entries()) {
      params[key] = value;
    }
    if (Object?.keys(params)?.length > 0) {
      getAnnounceListing(branchid as string, params);
    } else {
      getAnnounceListing(branchid as string);
    }
  }

  useEffect(() => {
    if (!id) {
        getAnnoucementListingDetails();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchParams]);

  return (
    <StyledAnnouncements token={token}>
      <Navbar id={id} isStudent = {isStudent}/>
      {!id && <Filters nameSearchInit={searchParams.get("title") || ""} />}
      {id ? (
        <AnnouncementForm id={id} onCancel={handleCancel} isStudent={isStudent}/>
      ) : (
        <AnnounceList
          data={announceListing}
          loading={loading}
          callBack={getAnnoucementListingDetails}
          isStudent={isStudent}
        />
      )}
    </StyledAnnouncements>
  );
};

export default Announcements;
