"use client";

import { useEffect, useState } from "react";
import {
  Button,
  Drawer,
  Form,
  Input,
  message,
  Spin,
  theme,
  Typography,
  Upload,
  UploadFile,
} from "antd";
import apiClient from "@/lib/apiClient";
import { CloseOutlined, PlusOutlined } from "@ant-design/icons";
import {
  StyledAnnouncementForm,
  StyledAnnouncementMobileForm,
} from "../Styles";
import {
  ButtonInlineStyles,
  StyledMobileSpacedContainer,
} from "@/components/common/styles.common";
import { useParams } from "next/navigation";
import HELPERS from "@/lib/helpers";
import { useNavigation } from "@/lib/context/NavigationContext";
import { RcFile } from "antd/es/upload";
import { SideMenuIcons } from "../../Sidebar/Icons";
import GeneralModal from "@/components/reusable/Modal/GeneralModal/Modal";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";
import { GLOBAL_CONSTANTS } from "@/constants";
import { useThemeContext } from "@/lib/context/ThemeContext";

const { TextArea } = Input;

const MAX_FILE_SIZE_MB = 5;

const AnnouncementForm = ({
  id = "",
  onCancel = () => {},
  isStudent = false,
}) => {
  const [formDetails, setFormDetails] = useState<AnnounceTypes>({});
  const [loading, setLoading] = useState(false);
  const [fileList, setFileList] = useState<UploadFile[]>([]);

  const { token } = theme.useToken();
  const { branchid = "" } = useParams();
  const { navigate } = useNavigation();
  const isMobile = useIsSmallDevice();
  const isDark = useThemeContext().mode === "dark";

  const getMimeType = (filename: string): string => {
    const ext = filename?.split(".")?.pop();
    const map: Record<string, string> = {
      png: "image/png",
      jpg: "image/jpeg",
      jpeg: "image/jpeg",
      pdf: "application/pdf",
      xls: "application/vnd.ms-excel",
      xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    };

    if (!ext) {
      return "application/octet-stream";
    }

    return map[ext?.toLowerCase()] || "application/octet-stream";
  };

  async function getFormDetails(id = "") {
    setLoading(true);
    try {
      const res = await apiClient.get(`/announce/${id}`);
      setFormDetails(res?.data);

      const data = res?.data;
      const attachments = data?.attachments;

      const files: UploadFile[] = await Promise.all(
        Object.entries(attachments).map(async ([id, filename]) => {
          const nameStr =
            typeof filename === "string" ? filename : "unknownfile";

          const fileRes = await apiClient.get(`/file/${id}`, {
            responseType: "arraybuffer",
          });
          const mimeType = getMimeType(nameStr);

          // Create File for RcFile compatibility
          const file = new File([new Uint8Array(fileRes.data)], nameStr, {
            type: mimeType,
            lastModified: Date.now(),
          }) as RcFile;

          const url = URL.createObjectURL(file);

          return {
            uid: id,
            name: nameStr,
            status: "done",
            url,
            type: mimeType,
            originFileObj: file,
          };
        })
      );

      setFileList(files);
    } finally {
      setLoading(false);
    }
  }

  function handleChange(value: string | number | null, key = "") {
    setFormDetails((prev) => {
      return {
        ...(prev || {}),
        [key]: value,
      };
    });
  }

  const handleFileChange = ({
    fileList: newFileList,
  }: {
    fileList: UploadFile[];
  }) => {
    setFileList(newFileList);
  };

  const beforeUpload = (file: File) => {
    if (window.ReactNativeWebView && window.ReactNativeWebView.postMessage) {
      window.ReactNativeWebView.postMessage(
        JSON.stringify({ type: "REQUEST_UPLOAD_PERMISSION" })
      );
    }

    const isAllowedType =
      file.type === "application/pdf" ||
      file.type === "image/jpeg" ||
      file.type === "image/png" ||
      file.type ===
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" || // .xlsx
      file.type === "application/vnd.ms-excel"; // .xls

    if (!isAllowedType) {
      message.error(`${file.name} is not a supported file type`);
      return Upload.LIST_IGNORE;
    }

    const isLt5M = file.size / 1024 / 1024 < MAX_FILE_SIZE_MB;
    if (!isLt5M) {
      message.error(`${file.name} must be smaller than ${MAX_FILE_SIZE_MB}MB`);
      return Upload.LIST_IGNORE;
    }

    return false; // prevent auto-upload
  };

  const handleRemove = async (file: UploadFile) => {
    if (id === "NEW") return true;
    setLoading(true);
    try {
      await apiClient.delete(`/file/${file?.uid}`);
      return true;
    } catch {
      message.error("Failed to delete file");
      return false;
    } finally {
      setLoading(false);
    }
  };

  const handlePreview = async (file: UploadFile) => {
    try {
      if (window?.ReactNativeWebView && window?.ReactNativeWebView?.postMessage) {
        let fileBlob;
        if (file?.originFileObj) {
          fileBlob = file?.originFileObj;
        } else if (file?.url) {
          const response = await fetch(file?.url);
          fileBlob = await response.blob();
        }

        if (fileBlob) {
          const reader = new FileReader();
          reader.onloadend = () => {
            const base64Data = (reader.result as string)?.split(",")[1]; // strip "data:*/*;base64,"
            window?.ReactNativeWebView?.postMessage(
              JSON.stringify({
                type: "PREVIEW_FILE",
                fileName: file?.name,
                mimeType: file?.type || "application/octet-stream",
                base64: base64Data,
              })
            );
          };
          reader.readAsDataURL(fileBlob);
        }
      } else {
        // NORMAL BROWSER
        if (file?.url) {
          window.open(file?.url, "_blank");
        } else if (file?.originFileObj) {
          const url = URL.createObjectURL(file?.originFileObj);
          const link = document.createElement("a");
          link.href = url;
          link.download = file?.name;
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
          URL.revokeObjectURL(url);
        }
      }
    } catch (err) {
      message.error("Unable to preview file");
      console.error("Preview error:", err);
    }
  };

  function handleCancel() {
    setFileList([]);
    setFormDetails({});
    onCancel();
  }

  async function handleSubmit() {
    if (!formDetails?.title?.trim()) {
      return message.error("Please provide the title");
    }
    if (!formDetails?.description?.trim()) {
      return message.error("Please provide the description");
    }
    setLoading(true);

    const body = {
      ...(formDetails || {}),
      audienceType: "ALL",
      branchId: branchid,
    };

    try {
      let res;
      if (id === "NEW") {
        res = await apiClient.post("/announce", body);
      } else {
        res = await apiClient.put("/announce", body);
      }
      const data = res?.data;

      // UPLOAD ATTACHMENT
      if (data?.id) {
        const refId = data?.id;
        const refType = "ANNOUNCEMENT";
        // PARALLEL UPLOAD
        await Promise.all(
          fileList?.map(async (file) => {
            if (file?.originFileObj) {
              const fileName = file?.name;
              const renamedFile = new File([file.originFileObj], fileName, {
                type: file.originFileObj.type,
              });
              const formData = new FormData();
              formData.append("file", renamedFile);

              return apiClient.post(
                `/file/${refId}/${refType}/${fileName}`,
                formData
              );
            }
          })
        );
        HELPERS.messageAlert({ success: "Saved successfully" });
        navigate(`/announcements/${data?.id}`);
      }
    } finally {
      setLoading(false);
    }
  }

  function getMobileBody() {
    return (
      <Spin spinning={loading}>
        <StyledAnnouncementMobileForm token={token}>
          <div
            className={`flex items-center w-full gap-2 justify-between border-b-1 ${
              isDark ? "border-gray-700" : "border-gray-200"
            } py-3`}
          >
            <Typography.Paragraph style={{ fontWeight: 600 }}>
              Title
            </Typography.Paragraph>
            <Typography.Paragraph>{formDetails?.title}</Typography.Paragraph>
          </div>
          <div
            className={`flex items-center w-full gap-2 justify-between border-gray-200 py-3 ${
              fileList?.length === 0
                ? "border-b-0"
                : isDark
                ? "border-b-1 border-gray-700"
                : "border-b-1 border-gray-200"
            }`}
          >
            <Typography.Paragraph style={{ fontWeight: 600 }}>
              Description
            </Typography.Paragraph>
            <Typography.Paragraph>
              {formDetails?.description || "None"}
            </Typography.Paragraph>
          </div>
          {fileList?.length > 0 && (
            <div className={`flex flex-col w-full gap-2 py-3 `}>
              <Typography.Paragraph style={{ fontWeight: 600 }}>
                Attachments
              </Typography.Paragraph>
              <Upload
                multiple
                fileList={fileList}
                onChange={handleFileChange}
                beforeUpload={beforeUpload}
                listType="picture"
                onPreview={handlePreview}
                onRemove={handleRemove}
                accept=".pdf,.jpg,.jpeg,.png,.xlsx,.xls"
                disabled={isStudent}
              >
                {!isStudent && (
                  <Button icon={<PlusOutlined />}>Upload Files</Button>
                )}
              </Upload>
            </div>
          )}
        </StyledAnnouncementMobileForm>
      </Spin>
    );
  }

  function getBody() {
    return (
      <StyledMobileSpacedContainer>
        <Spin spinning={loading}>
          <StyledAnnouncementForm token={token}>
            <Form.Item label="Title" labelCol={{ span: 24 }} required>
              <Input
                type={"text"}
                value={formDetails?.title}
                onChange={(e) => handleChange(e.target.value, "title")}
              />
            </Form.Item>
            <Form.Item label="Description" labelCol={{ span: 24 }} required>
              <TextArea
                cols={5}
                value={formDetails?.description}
                onChange={(e) => handleChange(e.target.value, "description")}
                readOnly={isStudent}
              />
            </Form.Item>
            <Form.Item label="Attachment" labelCol={{ span: 24 }}>
              <Upload
                multiple
                fileList={fileList}
                onChange={handleFileChange}
                beforeUpload={beforeUpload}
                listType="picture"
                onPreview={handlePreview}
                onRemove={handleRemove}
                accept=".pdf,.jpg,.jpeg,.png,.xlsx,.xls"
                disabled={isStudent}
              >
                {!isStudent && (
                  <Button icon={<PlusOutlined />}>Upload Files</Button>
                )}
              </Upload>
            </Form.Item>
            {!isStudent && (
              <Form.Item label="" labelCol={{ span: 24 }}>
                <div className="w-full flex justify-end items-center gap-2">
                  <Button style={ButtonInlineStyles} onClick={handleCancel}>
                    Cancel
                  </Button>
                  <Button
                    style={ButtonInlineStyles}
                    type="primary"
                    onClick={handleSubmit}
                  >
                    {id === "NEW" ? "Create" : "Update"}
                  </Button>
                </div>
              </Form.Item>
            )}
          </StyledAnnouncementForm>
        </Spin>
      </StyledMobileSpacedContainer>
    );
  }

  useEffect(() => {
    if (id && id !== "NEW") {
      getFormDetails(id);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  if (isStudent) {
    if (isMobile) {
      return (
        <Drawer
          onClose={handleCancel}
          open={!!id}
          placement="bottom"
          height={"80%"}
          closable={false}
          style={{
            borderTopLeftRadius:
              GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.BORDER_RADIUS,
            borderTopRightRadius:
              GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.BORDER_RADIUS,
          }}
          footer={null}
          title={
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Typography.Title level={5}>Announcement</Typography.Title>
              </div>
              <Button onClick={handleCancel} shape="circle">
                <CloseOutlined />
              </Button>
            </div>
          }
        >
          {getMobileBody()}
        </Drawer>
      );
    }
    return (
      <GeneralModal
        open={!!id}
        onCancel={handleCancel}
        customTitle={"Announcement"}
        titleIcon={SideMenuIcons.ANNOUNCEMENTS()}
        footer={null}
      >
        {getMobileBody()}
      </GeneralModal>
    );
  }

  return <>{getBody()}</>;
};

export default AnnouncementForm;
