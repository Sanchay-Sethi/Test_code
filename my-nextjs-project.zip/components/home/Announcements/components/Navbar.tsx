"use client";

import { Button, theme, Typography } from "antd";
import { SideMenuIcons } from "@/components/home/Sidebar/Icons";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";
import { StyledNavbar } from "../../StudentView/Profile/styles.profile";
import { PLUS_ICON } from "../../Students/Icons";
import { GENERAL_COMPONENTS } from "@/components/common";
import { useNavigation } from "@/lib/context/NavigationContext";

const Navbar = ({ id = "", isStudent = false }) => {
  const { token } = theme.useToken();
  const isMobile = useIsSmallDevice();
  const { navigate } = useNavigation();

  function handleClick() {
    if (isStudent) return;
    navigate("/announcements/NEW");
  }

  function getTitle() {
    if (isStudent) {
      if (id) return "Announcement";
      return "Announcements";
    }
    if (!id) {
      return "Announcements";
    } else if (id && id === "NEW") {
      return "New Announcement";
    }
    return "Update Announcement";
  }

  return (
    <StyledNavbar token={token}>
      <div className="flex items-center gap-3">
        {id && <GENERAL_COMPONENTS.BackButton backUrl={isStudent ?  "/student-view/announcements" :  "/announcements"}/>}
        <div className="flex flex-col">
          {!id && (
            <div className="flex items-center gap-1.5">
              {SideMenuIcons.ANNOUNCEMENTS()}
              <Typography.Paragraph>All</Typography.Paragraph>
            </div>
          )}
          <Typography.Title level={isMobile ? 5 : 2}>
            {getTitle()}
          </Typography.Title>
        </div>
      </div>
      {!id && !isStudent && (
        <Button type="primary" onClick={handleClick}>
          <PLUS_ICON /> New announcement
        </Button>
      )}
    </StyledNavbar>
  );
};

export default Navbar;
