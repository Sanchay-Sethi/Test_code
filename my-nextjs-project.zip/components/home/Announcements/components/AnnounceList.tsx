"use client";

// import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";
import {
  Button,
  Popconfirm,
  Table,
  Tag,
  theme,
  Tooltip,
  Typography,
} from "antd";
import { StyledStudentsPaymentList } from "../../Settings/Payments/styles.Payments";
import FormattedDate from "@/components/reusable/Date/FormattedDate";
import { useMemo } from "react";
import { useNavigation } from "@/lib/context/NavigationContext";
import { HiOutlinePencil } from "react-icons/hi";
import { BiTrashAlt } from "react-icons/bi";
import apiClient from "@/lib/apiClient";
import HELPERS from "@/lib/helpers";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";
import GeneralSkeleton from "@/components/reusable/Loader/Skeleton/GeneralSkeleton";
import { GENERAL_COMPONENTS } from "@/components/common";
import VirtualSwiper from "@/components/reusable/Swiper/virtual/VirtualVerticalSwiper";
import { AnnouncementCard } from "@/components/reusable/cards/GeneralCards";
import { StyledMobileSpacedContainer } from "@/components/common/styles.common";

const AnnounceList = ({
  data,
  loading = false,
  isStudent = false,
  callBack = () => {},
}: {
  data: AnnounceTypes[];
  loading: boolean;
  isStudent?: boolean;
  callBack: () => void;
}) => {
  const { token } = theme.useToken();
  const isMobile = useIsSmallDevice();

  const { navigate } = useNavigation();

  async function handleAction(id = "", key = "") {
    if (key === "EDIT") {
      navigate(
        isStudent ? `/student-view/announcements/${id}` : `/announcements/${id}`
      );
    } else if (key === "DELETE") {
      if (isStudent) return;
      try {
        await apiClient.delete(`/announce/${id}`);
        HELPERS.messageAlert({ success: "Deleted successfully" });
      } finally {
        callBack();
      }
    }
  }

  const handleRowClick = (id: string) => {
    if (!isStudent) return;
    if (id) {
      navigate(`/student-view/announcements/${id}`);
    }
  };

  const columns = useMemo(
    () =>
      isStudent
        ? [
            {
              key: "TITLE",
              title: "Title",
              dataIndex: "title",
              ellipsis: true,
            },
            {
              key: "DATE",
              title: "Date",
              dataIndex: "createdAt",
              ellipsis: true,
              render: (createdAt: string) => (
                <FormattedDate dateString={createdAt} />
              ),
            },
            {
              key: "AUDIENCE",
              title: "Audience",
              dataIndex: "audienceType",
              ellipsis: true,
              width: 150,
            },
            {
              key: "ATTACHMENTS",
              title: "Attachments",
              dataIndex: "attachments",
              ellipsis: true,
              width: 400,
              render: (attachments: { [key: string]: string }) => {
                return (
                  <div className="flex items-center gap-1.5 flex-wrap">
                    {Object.keys(attachments)?.length === 0 ? (
                      <Typography.Paragraph type={"secondary"}>
                        <i>None</i>
                      </Typography.Paragraph>
                    ) : (
                      <>
                        {Object?.keys(attachments)?.map((attachment) => {
                          const name =
                            attachments?.[attachment]?.length > 18
                              ? attachments?.[attachment]?.slice(0, 18) + "..."
                              : attachments?.[attachment];
                          return (
                            <Tooltip
                              key={attachment}
                              title={attachments?.[attachment]}
                            >
                              <Tag style={{ marginInlineEnd: 0 }}>{name}</Tag>
                            </Tooltip>
                          );
                        })}
                      </>
                    )}
                  </div>
                );
              },
            },
          ]
        : [
            {
              key: "TITLE",
              title: "Title",
              dataIndex: "title",
              ellipsis: true,
              width: 200,
            },
            {
              key: "DATE",
              title: "Date",
              dataIndex: "createdAt",
              ellipsis: true,
              width: 200,
              render: (createdAt: string) => (
                <FormattedDate dateString={createdAt} />
              ),
            },
            {
              key: "AUDIENCE",
              title: "Audience",
              dataIndex: "audienceType",
              ellipsis: true,
              width: 150,
            },
            {
              key: "ATTACHMENTS",
              title: "Attachments",
              dataIndex: "attachments",
              ellipsis: true,
              width: 400,
              render: (attachments: { [key: string]: string }) => {
                return (
                  <div className="flex items-center gap-1.5 flex-wrap">
                    {Object.keys(attachments)?.length === 0 ? (
                      <Typography.Paragraph type={"secondary"}>
                        <i>None</i>
                      </Typography.Paragraph>
                    ) : (
                      <>
                        {Object?.keys(attachments)?.map((attachment) => {
                          const name =
                            attachments?.[attachment]?.length > 18
                              ? attachments?.[attachment]?.slice(0, 18) + "..."
                              : attachments?.[attachment];
                          return (
                            <Tooltip
                              key={attachment}
                              title={attachments?.[attachment]}
                            >
                              <Tag style={{ marginInlineEnd: 0 }}>{name}</Tag>
                            </Tooltip>
                          );
                        })}
                      </>
                    )}
                  </div>
                );
              },
            },
            {
              key: "Action",
              title: "Action",
              dataIndex: "id",
              ellipsis: true,
              fixed: "right",
              render: (id = "") => {
                return (
                  <div className="flex items-center gap-2">
                    <Button
                      type="text"
                      icon={<HiOutlinePencil />}
                      color="primary"
                      variant="filled"
                      onClick={(e) => {
                        e?.stopPropagation();
                        handleAction(id, "EDIT");
                      }}
                    >
                      Edit
                    </Button>
                    <Popconfirm
                      title="Delete announcement"
                      description="Are you sure to delete this announcement?"
                      onConfirm={(e) => {
                        e?.stopPropagation();
                        handleAction(id, "DELETE");
                      }}
                      okText="Yes"
                      cancelText="No"
                    >
                      <Button
                        type="text"
                        icon={<BiTrashAlt />}
                        color="danger"
                        variant="filled"
                      >
                        Delete
                      </Button>
                    </Popconfirm>
                  </div>
                );
              },
            },
          ],
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [data]
  );

  if (isMobile) {
    return (
      <StyledMobileSpacedContainer>
        {loading ? (
          <GeneralSkeleton
            countSmall={0}
            countLarge={10}
            isLargeWrapped
            largeBoxHeight={100}
          />
        ) : data?.length === 0 && !loading ? (
          <GENERAL_COMPONENTS.NoResult />
        ) : (
          <VirtualSwiper
            items={data || []}
            getKey={(data) => data?.id || ""}
            cardEstimateWidth={isStudent ? 115 : 125}
            containerHeight={"calc(100vh - 200px)"}
            renderItem={(details) => (
              <AnnouncementCard
                data={details}
                onDelete={() => handleAction(details?.id, "DELETE")}
                onEdit={() => handleAction(details?.id, "EDIT")}
                isStudent={isStudent}
              />
            )}
          />
        )}
      </StyledMobileSpacedContainer>
    );
  }

  return (
    <StyledStudentsPaymentList token={token}>
      <Table
        dataSource={data}
        loading={loading}
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-expect-error
        columns={columns}
        sticky={true}
        tableLayout={"fixed"}
        onRow={(record) => ({
          onClick: () => handleRowClick(record?.id || ""),
        })}
        rowClassName={() => (!isStudent ? "" : "clickable-row")}
        scroll={{ x: "max-content" }}
        pagination={{
          position: ["bottomRight"],
          total: (data || [])?.length,
          showTotal: (total) => `Total ${total} items`,
          align: "center",
        }}
      />
    </StyledStudentsPaymentList>
  );
};

export default AnnounceList;
