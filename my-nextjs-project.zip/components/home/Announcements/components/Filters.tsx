"use client";

import { useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import { Input } from "antd";
import { SearchOutlined } from "@ant-design/icons";
import { useDebounce } from "@/lib/hooks/useDebounce";
import { useNavigation } from "@/lib/context/NavigationContext";
import useIsSmallDevice from "@/lib/hooks/useIsSmallDevice";
import { StyledFilters } from "@/components/home/Students/styles.Students";

const Filters = ({
  nameSearchInit,
}: {
  nameSearchInit: string;
}) => {
  const { navigate } = useNavigation();
  const searchParams = useSearchParams();
  const isMobile = useIsSmallDevice();

  const [nameSearch, setNameSearch] = useState(nameSearchInit);
  const debouncedSearch = useDebounce(nameSearch, 500);

  function handleChange(key = "", value = "") {
    if (key === "title") {
      setNameSearch(value);
    }
  }

  useEffect(() => {
    const params = new URLSearchParams(searchParams.toString());
    if (debouncedSearch) {
      params.set("title", debouncedSearch?.trim());
    } else {
      params.delete("title");
    }

    navigate(`?${params.toString()}`);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debouncedSearch]);

  return (
    <StyledFilters>
      <div className="filter-search">
        <Input
          type="text"
          prefix={<SearchOutlined />}
          placeholder="Search by title..."
          className="search-input"
          value={nameSearch}
          size={isMobile ? "small" : "middle"}
          style={
            isMobile
              ? { borderRadius: "8px", padding: "2px 15px", fontSize: 14 }
              : {}
          }
          onChange={(e) => handleChange("title", e.target.value)}
        />
      </div>
    </StyledFilters>
  );
};

export default Filters;
