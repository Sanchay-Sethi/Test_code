interface AnnounceTypes {
    id?: string;
    branchId?: string;
    title?: string;
    description?: string;
    audienceType?: string;
    audienceEntityId?: string;
    attachments?: string[];
    postedBy?: string;
    postedByUserName?: string;
    createdAt?: string;
    updatedAt?: string;
}

