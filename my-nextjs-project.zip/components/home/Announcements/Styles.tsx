"use client";

import styled from "styled-components";
import { StyledContextProps } from "@/types";
import { GLOBAL_CONSTANTS } from "@/constants";

export const StyledAnnouncements = styled.div<StyledContextProps>`
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 20px;
`;

export const StyledAnnouncementForm = styled.div<StyledContextProps>`
  width: 70%;
  display: flex;
  flex-direction: column;
  padding: 15px 20px;
  border-radius: 16px;
  border: 1px solid ${({ token }) => token?.colorBorder};

  @media (max-width: ${GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.RESPONSIVE_WIDTH}px) {
    width: 100%;
    border-radius: 15px;
    padding: 10px 12px;
    border: none;
    background-color: ${({ token }) => token?.colorBgBase};
  }
`;

export const StyledAnnouncementMobileForm = styled.div<StyledContextProps>`
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 10px;
`;

