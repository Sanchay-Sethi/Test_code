"use client";

import { GLOBAL_CONSTANTS } from "@/constants";
import styled from "styled-components";

interface StyledHomeParentWrapperProps {
  iscollapsed?: boolean;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  token?: any;
}

export const StyledHomeParentWrapper = styled.div<StyledHomeParentWrapperProps>`
  width: 100%;
  height: 100vh;
  overflow: auto;
  background: ${({ token }) => token?.colorBgBase};
  padding: ${GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.GENERAL_PADDING}px;

  @media (max-width: ${GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.RESPONSIVE_WIDTH || 600}px) {
    background-color: ${({ token }) => token?.colorGreyBgBase};
    padding: 0px;
    height: calc(100vh - 44px);
  }
`;