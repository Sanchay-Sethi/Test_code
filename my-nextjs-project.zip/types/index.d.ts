import { GlobalToken } from "antd";

interface StyledContextProps {
  gap?: number;
  disabled?: boolean;
  iscollapsed?: boolean;
  hideBorderBottom?: boolean;
  isHighlighted?: boolean;
  isInDropdown?: boolean;
  feeHeightTable?: boolean;
  isEmpty?: boolean;
  nonHovered?: boolean;
  hide?: boolean;
  token?: GlobalToken;
  isSelected?: boolean;
  show?: boolean;
  isDrawer?: boolean;
  height?: string;
  color?: string;
}

interface CommonStylesProps {
  styles?: string;
  alterHeight?: string;
}

interface BranchesMap {
  id: string;
  name: string;
  address?: string;
}

interface StaffMap {
  id: string;
  name: string;
  mobile: string;
  email: string;
  schoolAdmin: boolean;
}

interface StudentMapTypes {
  id?: string;
  loginUserId?: string;
  branchId?: string;
  status?: string;
  name?: string;
  phoneNumber?: string;
  secondaryPhoneNumber?: string;
  email?: string;
  dateOfBirth?: string;
  gender?: string;
  admissionNumber?: string;
  admissionYear?: string;
  address?: string;
  fatherName?: string;
  motherName?: string;
  createdAt?: string;
  updatedAt?: string;
}

interface StudentAccessMapProps {
    "orgId": number | string,
    "userName": string,
    "userId": string,
    "branchId": string,
    "branchesHash":  BranchesMap[],
    "students": StudentMapTypes[] | null,
    "staff": StaffMap | null,
    "staffPermissions": string[] | null,
    "selectedStudent"?: StudentMapTypes,
    "ROLE"?: string;
    "schoolAdmin": boolean,
    "podAdmin": boolean,
    "orgIdNameMap": {
       [key: string]: string
    }
}

interface LabelValueProps {
  label: string,
  value: string,
}
