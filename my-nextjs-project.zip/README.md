
# Skylio web installations and commands.




## Node Installations

    1. Install Node v22.12.0
        Mac installation (Using brew) Recommanded

        1. brew upgrade
        2. brew install nvm
        3. open .bash_profile/.zshrc (based on your shell)
        4. add this commands:
        
        export NVM_DIR="$HOME/.nvm" 
        [ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"  # This loads nvm
        [ -s "$NVM_DIR/bash_completion" ] && \. "$NVM_DIR/bash_completion"  # This loads nvm bash_completion

        5. Save the file then run: source ~/.bash_profile (based on your shell)


        After all these above step check in terminal:

        . nvm --version
        . node --version

        Then install node v22.12.0 via nvm

        . nvm install 22.12.0
        . nvm ls
        . nvm use 22.12.0

        So it will install node 22.12.0. Here we can add multiple versions of node in our system and 
        when we need to switch to another node version we can simply run command nvm use specific_version

        if you want to make 22.12.0 as default version of your system then run command :

        ```nvm alias default 22.12.0```

Install node via nvm is recommanded, but there are other ways to install nodes in your system also

#### Using curl, wget and manual installation.
- Using **cURL**:

```
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
```
- Using **wget**:
```
wget -qO- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
```

Replace `v0.39.7` with the latest version from the [NVM GitHub releases page](https://github.com/nvm-sh/nvm/releases) if needed.

Also after above steps follow the 3rd 4th 5th line of brew installation i.e. add nvm export command in .bash_profile


 ### Using **Manual installation**:

You can simply watch this [Youtube video](https://www.youtube.com/watch?v=0wlchRhoUqU) for manuall installation or follow below steps.

- **Go to the Node.js Downloads Page**  
   Visit: [https://nodejs.org/dist/v22.12.0/](https://nodejs.org/dist/v22.12.0/)

- **Download the Appropriate Binary or Installer**
   - **Windows**: `node-v22.12.0-x64.msi`
   - **macOS**: `node-v22.12.0.pkg`
   - **Linux**: Download and extract the appropriate `.tar.xz` file

- **Run Installer or Extract Manually**
   - **Windows/macOS**: Run the installer and follow the prompts.
   - **Linux/macOS** (Manual Setup):
     ```bash
     tar -xf node-v22.12.0-linux-x64.tar.xz
     sudo mv node-v22.12.0-linux-x64 /usr/local/node-v22.12.0
     sudo ln -s /usr/local/node-v22.12.0/bin/node /usr/local/bin/node
     sudo ln -s /usr/local/node-v22.12.0/bin/npm /usr/local/bin/npm
     ```








# Install and run web skylio in localhost.

- Navigate to frontend/web/skylio folder.
- Run command:
```
yarn cache clean
yarn install
```

- if yarn not installed globally in your system via
```
npm install --global yarn
```

Above commands install all the packages needed for skylio web.
Then run command to open localhost

```
yarn run dev
or
npm run dev
```