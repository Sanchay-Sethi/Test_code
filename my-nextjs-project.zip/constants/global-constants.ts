const BASE_LOCAL_URL = "http://localhost";

const OTP_MAX_LENGTH = 4;

const HOME_DEFAULT_VALUES = {
    SIDEBAR: {
        WIDTH: 270
    },
    GENERAL_PADDING: 28,
    GENERAL_PADDING_MOBILE: {
        INLINE: 15,
        VERTICAL: 12,
    },
    BORDER_RADIUS: 20,
    RESPONSIVE_WIDTH: 600,
}

const TAG_STATUS_COLOR = {
    "ACTIVE": "green",
    "EXITED": "red",
    "WILL_EXIT": "orange",
    "ALL": "blue"
}

const STUDENT_STATUS = {
    "ALL" : "All",
    "ACTIVE": "Active",
    "EXITED": "Exited",
    "WILL_EXIT": "Will exit",
}

const STUDENT_FEE_STATUS = {
    "ALL" : "All",
    "overdueOnly": "Overdue Only",
}

const ACADEMIC_YEAR_STATE = {
    "CURRENT" : "Current",
    "UPCOMING": "Upcoming",
    "CLOSED": "Closed",
}

const ACADEMIC_YEAR_STATE_COLOR = {
    "CURRENT" : "green",
    "UPCOMING": "orange",
    "CLOSED": "grey",
}

const ROLE_PERMISSIONS_MAP = {
    STUDENT : {
        title: "Students",
        id: "STUDENT",
        VIEW: false,
        MANAGE: false,
    },
    FEE: {
        title: "Fee collection",
        id: "FEE",
        VIEW: false,
        MANAGE: false,
    },
    PAYMENT: {
        title: "Payments",
        id: "PAYMENT",
        VIEW: false,
        MANAGE: false,
    },
    ATTENDANCE: {
        title: "Attendance",
        id: "ATTENDANCE",
        VIEW: false,
        MANAGE: false,
    },
    CALENDAR: {
        title: "Calendar",
        id: "CALENDAR",
        VIEW: false,
        MANAGE: false,
    },
    ANNOUNCEMENT: {
        title: "Announcement",
        id: "ANNOUNCEMENT",
        VIEW: false,
        MANAGE: false,
    },
    HOMEWORK: {
        title: "Homework",
        id: "HOMEWORK",
        VIEW: false,
        MANAGE: false,
    },
}

const FEE_TYPES = {
  PROGRAM: "New program",
  ADMISSION: "New Admission plan",
  TRANSPORT: "New transport plan",
  HOSTEL: "New hostel plan",
  DISCOUNT: "New discount",
};

const FEE_TYPES_OPTIONS = [
    {
        label: "Program",
        value: "PROGRAM",
    },
    {
        label: "Admission",
        value: "ADMISSION",
    },
    {
        label: "Transport",
        value: "TRANSPORT",
    },
    {
        label: "Hostel",
        value: "HOSTEL",
    },
    {
        label: "Meal",
        value: "MEAL",
    },
    {
        label: "Previous dues",
        value: "PREVIOUS_DUES",
    },
]

const GLOBAL_CONSTANTS = {
    BASE_LOCAL_URL,
    OTP_MAX_LENGTH,
    HOME_DEFAULT_VALUES,
    TAG_STATUS_COLOR,
    STUDENT_STATUS,
    STUDENT_FEE_STATUS,
    ACADEMIC_YEAR_STATE,
    ACADEMIC_YEAR_STATE_COLOR,
    ROLE_PERMISSIONS_MAP,
    FEE_TYPES,
    FEE_TYPES_OPTIONS,
}


export default GLOBAL_CONSTANTS;