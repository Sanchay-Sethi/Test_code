import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'

export function middleware(request: NextRequest) {
  const sessionId = request.cookies.get('skylio-session-id')?.value;
  const sessionToken = request.cookies.get('skylio-session-token')?.value;
  const { pathname, search } = request.nextUrl
  const isAuthPage = pathname.startsWith('/auth/login') || pathname.startsWith('/verify')
  const isProtectedRoute = pathname.startsWith('/home')

  const isLoggedIn = !!sessionId && !!sessionToken;

  // If not authenticated and trying to access protected route
  if (!isLoggedIn && isProtectedRoute) {
    const redirectUrl = new URL('/auth/login', request.url)
    redirectUrl.searchParams.set('redirect', encodeURIComponent(pathname + search))
    return NextResponse.redirect(redirectUrl)
  }

  // If authenticated and on auth page
  if (isLoggedIn && isAuthPage) {
    return NextResponse.redirect(new URL('/home', request.url))
  }

  return NextResponse.next()
}

export const config = {
  matcher: ['/auth/login', '/auth/verify', '/home/:path*'],
}
