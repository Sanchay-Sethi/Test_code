"use client";

import React, { useRef } from "react";
import { StyleProvider } from "@ant-design/cssinjs";
import { createCache } from "@ant-design/cssinjs";

export default function StyledComponentsRegistry({
  children,
}: {
  children: React.ReactNode;
}) {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const cache = useRef<any>(null);
  if (!cache.current) {
    cache.current = createCache();
  }

  return (
    <StyleProvider cache={cache.current}>
      <>{children}</>
    </StyleProvider>
  );
}
