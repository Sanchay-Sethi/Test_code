"use client";

import React, {
  createContext,
  useContext,
  useState,
  useMemo,
  useEffect,
} from "react";
import { theme as antdTheme, ConfigProvider, ThemeConfig } from "antd";
import "antd/es/theme/interface";
import StyledComponentsRegistry from "../antd-registry";

type ThemeMode = "light" | "dark";

interface ThemeContextType {
  mode: ThemeMode;
  toggleTheme: () => void;
  theme: ThemeConfig;
}

declare global {
  interface Window {
    ReactNativeWebView?: {
      postMessage: (message: string) => void;
    };
  }
}

declare module "antd/es/theme/interface" {
  interface AliasToken {
    colorCollapseIcon?: string;
    colorGreyGlobal?: string;
    colorCustomTag?: string;
    colorGreyPrimary?: string;
    colorGreyCard?: string;
    colorGreySecondary?: string;
    colorBgCard?: string;
    colorGreyBgBase?: string;
    colorCalenderHeader?: string;
    colorCalenderActive?: string;
    colorCalenderListBg?: string;
  }
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

const lightTheme: ThemeConfig = {
  algorithm: antdTheme.defaultAlgorithm,
  token: {
    colorBgContainer: "#fff", // Default content background
    colorBgBase: "#fff",
    colorCollapseIcon: "#A2A2A2",
    colorIcon: "#4F566B",
    colorPrimary: "#5469D4",
    colorLink: "#5469D4",
    colorGreyGlobal: "#F6F8FA",
    colorCustomTag: "#F7FAFC",
    colorBorder: "#E3E8EE",
    colorBorderSecondary: "#E3E8EE",
    colorGreyPrimary: "#A3ACB9",
    colorGreySecondary: "#697386",
    colorGreyCard: "#F6F8FA",
    colorBgCard: "#fff",
    // colorGreyBgBase: "#f7f7f7",
    // colorGreyBgBase: "#eaeced",
    colorGreyBgBase: "#f0f2f4",
    colorCalenderHeader: "#f6f7f9",
    colorCalenderActive: "#5469d417",
    colorCalenderListBg: "rgba(0,0,0,0.04)",
  },
  components: {
    Layout: {
      lightSiderBg: "#F7FAFC",
      boxShadowSecondary: "none",
      boxShadow: "none",
    },
  },
};

const darkTheme: ThemeConfig = {
  algorithm: antdTheme.darkAlgorithm,
  token: {
    colorBgContainer: "#03060D", // Dark content background
    colorBgBase: "#03060D",
    colorCollapseIcon: "#fff",
    colorIcon: "#fff",
    colorPrimary: "#635CFF",
    colorLink: "#635CFF",
    colorBorder: "#2F2F2F",
    colorBorderSecondary: "#2F2F2F",
    colorSplit: "#2F2F2F",
    colorGreyGlobal: "rgb(37 37 37)",
    colorCustomTag: "rgb(37 37 37)",
    colorGreyPrimary: "#999999",
    colorGreySecondary: "#697386",
    colorGreyCard: "rgba(65 65 65 / 0.54)",
    colorBgCard: "rgba(65 65 65 / 0.3)",
    colorGreyBgBase: "#11131a",
    colorBgElevated: "#0d0f14",
    colorCalenderHeader: "#000",
    colorCalenderActive: "#8893ca17",
    colorCalenderListBg: "#101014",
  },
  components: {
    Table: {
      borderColor: "#2F2F2F",
      expandIconBg: "#2F2F2F",
    },
    Layout: {
      siderBg: "#080b10", // Custom dark sidebar background
    },
    Menu: {
      darkItemSelectedBg: "#b6b4d824",
      darkSubMenuItemBg: "#5751dc05",
    },
  },
};

export const ThemeProvider = ({ children }: { children: React.ReactNode }) => {
  const [mode, setMode] = useState<ThemeMode>("light");

  useEffect(() => {
    const storedTheme = localStorage.getItem("theme") as ThemeMode | null;
    if (storedTheme) {
      setMode(storedTheme);
    } else {
      // TODO: Will uncomment if needed
      // const systemPrefersDark = window.matchMedia?.(
      //   "(prefers-color-scheme: dark)"
      // ).matches;
      // setMode(systemPrefersDark ? "dark" : "light");
      setMode("light");
    }
  }, []);

  useEffect(() => {
    if (
      typeof window !== "undefined" &&
      typeof window.ReactNativeWebView?.postMessage === "function"
    ) {
      window.ReactNativeWebView?.postMessage(
        JSON.stringify({
          type: "THEME",
          theme: mode,
          topColor:
            mode === "light"
              ? lightTheme?.token?.colorBgBase
              : darkTheme?.token?.colorBgBase,
          bottomColor:
            mode === "light"
              ? lightTheme?.token?.colorBgBase
              : darkTheme?.token?.colorBgBase,
        })
      );
    }
  }, [mode]);

  const toggleTheme = () => {
    setMode((prev) => {
      const next = prev === "light" ? "dark" : "light";
      localStorage.setItem("theme", next);
      return next;
    });
  };

  const theme = useMemo(
    () => (mode === "dark" ? darkTheme : lightTheme),
    [mode]
  );

  return (
    <ThemeContext.Provider value={{ mode, toggleTheme, theme }}>
      {children}
    </ThemeContext.Provider>
  );
};

export const useThemeContext = () => {
  const context = useContext(ThemeContext);
  if (!context)
    throw new Error("useThemeContext must be used inside ThemeProvider");
  return context;
};

export const ThemeWrapper = ({ children }: { children: React.ReactNode }) => {
  const { theme } = useThemeContext();

  return (
    <StyledComponentsRegistry>
      <ConfigProvider theme={theme}>
        <>{children}</>
      </ConfigProvider>
    </StyledComponentsRegistry>
  );
};
