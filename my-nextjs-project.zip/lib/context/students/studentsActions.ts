// students/context/studentsActions.ts

import apiClient from '@/lib/apiClient';
import { StudentsAction } from './studentsTypes';

export function createStudentsActions(dispatch: React.Dispatch<StudentsAction>) {
  return {
    fetchStudents: async (branchid?: string, params?: Record<string, string>) => {
      try {
        dispatch({ type: 'SET_LOADING', payload: true });

        // Convert params to query string
        const queryString = params
          ? "&" + new URLSearchParams(params).toString()
          : '';

        const res = await apiClient.get(`/student?branchId=${branchid}${queryString}`);
        const data = res.data;
        dispatch({ type: 'SET_STUDENTS', payload: data });
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      } catch (error: any) {
        dispatch({ type: 'SET_ERROR', payload: error.message || 'Failed to fetch students' });
      }
    },

    resetStudents: () => {
      dispatch({ type: 'RESET' });
    }

    // Add more action functions here
  };
}
