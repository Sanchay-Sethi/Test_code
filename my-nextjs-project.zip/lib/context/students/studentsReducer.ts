import { StudentsState, StudentsAction } from './studentsTypes';

export const initialStudentsState: StudentsState = {
  studentsListing: [],
  loading: false,
  error: null,
};

export function studentsReducer(state: StudentsState, action: StudentsAction): StudentsState {
  switch (action.type) {
    case 'SET_STUDENTS':
      return { ...state, studentsListing: action.payload, loading: false };
    case 'SET_LOADING':
      return { ...state, loading: action.payload };
    case 'SET_ERROR':
      return { ...state, error: action.payload, loading: false };
    case 'RESET':
      return initialStudentsState;
    default:
      return state;
  }
}
