export interface Student {
  id?: string;
  name?: string;
  admissionNumber?: string;
  programName?: string;
  sectionName?: string;
  status?: string;
  // Add more fields as needed
}

export interface StudentsState {
  studentsListing: Student[];
  loading: boolean;
  error: string | null;
}

export type StudentsAction =
  | { type: 'SET_STUDENTS'; payload: Student[] }
  | { type: 'SET_LOADING'; payload: boolean }
  | { type: 'SET_ERROR'; payload: string | null }
  | { type: 'RESET' };
