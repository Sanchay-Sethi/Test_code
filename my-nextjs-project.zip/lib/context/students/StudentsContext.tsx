'use client';

import React, { createContext, useReducer, useContext, ReactNode } from 'react';
import { studentsReducer, initialStudentsState } from './studentsReducer';
import { StudentsState } from './studentsTypes';
import { createStudentsActions } from './studentsActions';

interface StudentsContextType {
  state: StudentsState;
  actions: ReturnType<typeof createStudentsActions>;
}

const StudentsContext = createContext<StudentsContextType | undefined>(undefined);

export const StudentsProvider = ({ children }: { children: ReactNode }) => {
  const [state, dispatch] = useReducer(studentsReducer, initialStudentsState);
  const actions = createStudentsActions(dispatch);

  return (
    <StudentsContext.Provider value={{ state, actions }}>
      {children}
    </StudentsContext.Provider>
  );
};

export const useStudents = () => {
  const context = useContext(StudentsContext);
  if (!context) {
    throw new Error('useStudents must be used within a StudentsProvider');
  }
  return context;
};
