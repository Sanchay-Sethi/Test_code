"use client";

import React, {
  useTransition,
  useContext,
  createContext,
  ReactNode,
  useCallback,
} from "react";
import { useRouter, usePathname } from "next/navigation";

type NavigationContextType = {
  navigate: (
    url: string,
    options?: { scroll?: boolean; shallow?: boolean }
  ) => void;
  isNavigating: boolean;
};

const NavigationContext = createContext<NavigationContextType | undefined>(
  undefined
);

export const NavigationProvider = ({ children }: { children: ReactNode }) => {
  const router = useRouter();
  const pathname = usePathname();
  const [isPending, startTransition] = useTransition();

  const navigate = useCallback(
    (url: string, options?: { scroll?: boolean; shallow?: boolean }) => {
      const match = pathname.match(/^\/home\/([^/]+)\/([^/]+)/);
      if (!match) {
        console.warn("[NAVIGATE] Invalid current home path, skipping.");
        return;
      }

      const [, orgid, branchid] = match;

      let finalUrl = url;

      const currentUrl = new URL(window.location.href);
      const studentId = currentUrl.searchParams.get("studentId");

      if (url === "?" || url.trim() === "?") {
        // Clear query from current page
        finalUrl = pathname;
      } else if (url.startsWith("?")) {
        // Append query to current path
        finalUrl = `${pathname}${url}`;
      } else {
        // Strip any hardcoded '/home' prefix from navigation target
        const cleanedUrl = url.replace(/^\/home/, "");
        // Ensure leading slash
        const relativePath = cleanedUrl.startsWith("/")
          ? cleanedUrl
          : `/${cleanedUrl}`;
        finalUrl = `/home/${orgid}/${branchid}${relativePath}`;
      }

      // Add studentId if it's missing in the finalUrl
      const finalUrlObj = new URL(finalUrl, window.location.origin);
      if (studentId && !finalUrlObj.searchParams.has("studentId")) {
        finalUrlObj.searchParams.set("studentId", studentId);
      }

      startTransition(() => {
        router.push(finalUrlObj.pathname + finalUrlObj.search, options);
      });
    },
    [pathname, router]
  );

  const value = { navigate, isNavigating: isPending };

  return (
    <NavigationContext.Provider value={value}>
      {children}
    </NavigationContext.Provider>
  );
};

export const useNavigation = () => {
  const context = useContext(NavigationContext);
  if (!context) {
    throw new Error("useNavigation must be used within a NavigationProvider");
  }
  return context;
};
