"use client";

import React, {
  createContext,
  useContext,
  useState,
  ReactNode,
  useEffect,
} from "react";
import GLOBAL_APIS from "../globalAPIS";
import apiClient from "../apiClient";
import { LabelValueOptionTypes } from "../Types";
import { useParams, usePathname, useRouter, useSearchParams } from "next/navigation";
import { BranchesMap, StudentAccessMapProps, StudentMapTypes } from "@/types";
import { useOrgStore } from "../hooks/useOrgStore";
import HELPERS from "../helpers";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
// -------------------- Types --------------------
type GlobalStateType = {
  globalContextLoading: boolean;
  sidebar: {
    collapsed: boolean;
    mobile: {
      open: boolean;
    }
    navs: {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      orgsLists: any[];
      loading: boolean;
    };
  };
  user: {
    accessMap: StudentAccessMapProps;
    loading: boolean;
  };
  academicYear: {
    academicYearId: string;
    academicYearList: LabelValueOptionTypes[];
    loading: boolean;
  };
};

type GlobalContextType = {
  state: GlobalStateType;
  updateState: (newState: PartialDeep<GlobalStateType>) => void;
  updateAcademicYearList: (list: []) => void;
  updateCurrentAcademicYear: (id: string) => void;
  updateOrgs: (list: []) => void;
  updateBranches: (list: []) => void;
  updateLoggedInUser: (id: string, name: string) => void;
};

// -------------------- Deep Partial Type --------------------
type PartialDeep<T> = {
  [P in keyof T]?: T[P] extends object ? PartialDeep<T[P]> : T[P];
};

// -------------------- Default State --------------------
const defaultState: GlobalStateType = {
  globalContextLoading: false,
  sidebar: {
    collapsed: false,
    mobile: {
      open: false,
    },
    navs: {
      orgsLists: [],
      loading: false,
    },
  },
  user: {
    accessMap: {
      orgId: "",
      userName: "",
      userId: "",
      branchId: "",
      branchesHash: [],
      students: [],
      staff: null,
      staffPermissions: [],
      schoolAdmin: false,
      podAdmin: false,
      orgIdNameMap: {},
    },
    loading: true,
  },
  academicYear: {
    academicYearId: "",
    academicYearList: [],
    loading: true,
  },
};

// -------------------- Deep Merge Helper --------------------
function deepMerge<T>(target: T, source: PartialDeep<T>): T {
  const output = { ...target };

  for (const key in source) {
    if (
      source[key] &&
      typeof source[key] === "object" &&
      !Array.isArray(source[key])
    ) {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      output[key] = deepMerge((target as any)[key], (source as any)[key]);
    } else {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      output[key] = source[key] as any;
    }
  }
  return output;
}

// -------------------- Context Setup --------------------
const GlobalContext = createContext<GlobalContextType | undefined>(undefined);

export const GlobalProvider = ({ children }: { children: ReactNode }) => {
  const [state, setState] = useState<GlobalStateType>(defaultState);
  const params = useParams();
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  const [queryClient] = useState(() => new QueryClient());

  const setOrgId = useOrgStore((state) => state?.setOrgId);

  const updateState = (newState: PartialDeep<GlobalStateType>) => {
    setState((prev) => deepMerge(prev, newState));
  };

  function updateAcademicYearList(list = []) {
    const academicYearOptions = list?.map(
      (data: { name?: string; id?: string }) => {
        return {
          label: data?.name,
          value: data?.id,
        };
      }
    );
    updateState({
      academicYear: {
        academicYearList: academicYearOptions,
      },
    });
  }

  function updateCurrentAcademicYear(id = "") {
    updateState({
      academicYear: {
        academicYearId: id,
      },
    });
  }

  function updateBranches(list = []) {
    updateState({
      user: {
        accessMap: {
          branchesHash: list || [],
        },
      },
    });
  }

  function updateLoggedInUser(id = "", name = "") {
    updateState({
      user: {
        accessMap: {
          userId: id,
          userName: name,
        },
      },
    });
  }

  function updateOrgs(list = []) {
    let orgIdNameMap = {};
    list?.forEach((data: { id?: string; name?: string }) => {
      if (data?.id) {
        orgIdNameMap = {
          ...(orgIdNameMap || {}),
          [data?.id]: data?.name,
        };
      }
    });
    updateState({
      user: {
        accessMap: {
          orgIdNameMap,
        },
      },
    });
  }

  const globalContextLoading = state.user.loading || state.academicYear.loading;

  // -------------------- API Calls --------------------
  // const sidebarUpdate = async () => {
  //   updateState({
  //     sidebar: {
  //       navs: {
  //         loading: true,
  //       },
  //     },
  //   });

  //   try {
  //     const res = await GLOBAL_APIS.getOrgsList();
  //     updateState({
  //       sidebar: {
  //         navs: {
  //           orgsLists: res.data || [],
  //           loading: false,
  //         },
  //       },
  //     });
  //   } catch {
  //     updateState({
  //       sidebar: {
  //         navs: {
  //           loading: false,
  //         },
  //       },
  //     });
  //   }
  // };

  const getAcademicYearDetails = async () => {
    updateState({ academicYear: { loading: true } });

    try {
      const academicYearRes = await apiClient.get("/ay");
      const academicYearList = await apiClient.get("/ay/list");

      const academicYearId = academicYearRes?.data?.id || "";
      const academicYearOptions = academicYearList?.data?.map(
        (data: { name?: string; id?: string }) => {
          return {
            label: data?.name,
            value: data?.id,
          };
        }
      );

      updateState({
        academicYear: {
          academicYearId,
          academicYearList: academicYearOptions,
          loading: false,
        },
      });
    } finally {
      updateState({ academicYear: { loading: false } });
    }
  };


  function getURL(orgId: string | number = "", branchId = "", accessMap: StudentAccessMapProps, strictURL = false) {
    const URL = HELPERS.getDefaultPath(accessMap, orgId as string, branchId as string);

    if (!strictURL && URL) return URL;

    const parts = pathname?.split('/');
    const homeIndex = parts?.indexOf('home');

    const before = parts?.slice(0, homeIndex + 1); 
    const after = parts?.slice(homeIndex + 3);

    const updatedPath = [...before, orgId, branchId, ...after]?.join('/');

    const query = searchParams?.toString();
    return query ? `${updatedPath}?${query}` : updatedPath;
  }

  function handleOrgBranchRedirection(accessMap: StudentAccessMapProps) {
    const param_orgid = params?.orgid;
    const param_branchid = params?.branchid;

    if (param_orgid && param_branchid) {
      if (`${param_orgid}` === `${accessMap?.orgId}` && param_branchid === accessMap?.branchId) {
        // THIS CASE FOR NO ORG AND BRANCH CHANGE OR CHANGE ONLY IN BRANCH
        return false;
      } else {
        if (`${param_orgid}` === `${accessMap?.orgId}`) {
          // CASE OF NO CHANGE IN ORG
          if (accessMap?.ROLE === "STUDENT") {
            if (accessMap?.branchId !== param_branchid) {
              window.location.href = getURL(accessMap?.orgId, accessMap?.branchId, accessMap, true);
              return true;
            } else {
              return false;
            }
          } else {
            if (accessMap?.branchesHash?.find(branch => branch?.id === param_branchid)) {
              // THIS CASE NEVER HAPPEN. ADDED FOR SAFETY
              return false;
            } else {
              // CASE FOR CHANGE IN ORG
              window.location.href = getURL(accessMap?.orgId, accessMap?.branchId, accessMap);
              return true;
            }
          }
        } else {
          // CASE OF RANDOM ORG IN PARAM
          window.location.href = getURL(accessMap?.orgId, accessMap?.branchId, accessMap);
          return true;
        }
      }
    } else {
      // THIS WILL SET DEFAULT ORG AND BRANCH ID IN URL
      if (accessMap?.orgId && accessMap?.branchId) {
        window.location.href = getURL(accessMap?.orgId, accessMap?.branchId, accessMap);
        return true;
      } else {
        router.push(`/home`);
        return true;
      }
    }
  }

  function getOrgId(accessMap: StudentAccessMapProps) {
    const orgid = params?.orgid || "";
    const defaultOrgId = Object.keys(accessMap?.orgIdNameMap || {})?.[0] || "";
    if (orgid) {
      if (accessMap?.orgIdNameMap?.[orgid as keyof typeof accessMap]) {
        return orgid ? `${orgid}` : "";
      }
    }
    return defaultOrgId ? `${defaultOrgId}` : "";
  }

  function getBranchId(branchesHash: BranchesMap[] = [], defaultBranchId = "") {
    if (defaultBranchId) return defaultBranchId ? `${defaultBranchId}` : "";
    const branchid = params?.branchid || "";
    const defaultBranch = branchesHash?.[0]?.id;
    if (branchid) {
      if (branchesHash?.find((branch) => branch?.id === branchid)) {
        return branchid ? `${branchid}` : "";
      }
    }
    return defaultBranch ? `${defaultBranch}` : "";
  }

  function getDefaultBranchId(accessRes: StudentAccessMapProps) {
    if (!!accessRes?.students && accessRes?.students?.length > 0) {
      let selectedStudent;
      if (searchParams.get("studentId")) {
        const ID = searchParams.get("studentId");
        const student = accessRes?.students?.find(student => student?.id === ID)
        if (student) {
          selectedStudent = student || {};
        } else {
          selectedStudent = accessRes?.students?.[0] || {};
        }
      } else {
        selectedStudent = accessRes?.students?.[0] || {};
      }
      return selectedStudent?.branchId;
    }
    return ""
  }

  function getAccessMap(accessRes: StudentAccessMapProps, branchesRes: BranchesMap[], orgId: string, branchId: string) {
    let ROLE = "";
    let selectedStudent: StudentMapTypes = {};
    if (accessRes?.podAdmin) {
      ROLE = "POD_ADMIN"
    } else if (!!accessRes?.staff) {
      if (accessRes?.staff?.schoolAdmin === true) {
        ROLE = "STAFF_ADMIN";
      } else {
        ROLE = "STAFF";
      }
    } else if (!!accessRes?.students && accessRes?.students?.length > 0) {
      ROLE = "STUDENT";
      if (searchParams.get("studentId")) {
        const ID = searchParams.get("studentId");
        const student = accessRes?.students?.find(student => student?.id === ID)
        if (student) {
          selectedStudent = student || {};
          accessRes = {
          ...(accessRes || {}),
            userId: student?.id || "",
            userName: student?.name || "",
          }
        } else {
          selectedStudent = accessRes?.students?.[0] || {};
          accessRes = {
            ...(accessRes || {}),
            userId: selectedStudent?.id || "",
            userName: selectedStudent?.name || "",
          }
        }
      } else {
        selectedStudent = accessRes?.students?.[0] || {};
        accessRes = {
          ...(accessRes || {}),
          userId: selectedStudent?.id || "",
          userName: selectedStudent?.name || "",
        }
      }
    }

    return {
      ...(accessRes || {}),
      branchesHash: branchesRes,
      orgId,
      branchId,
      ROLE,
      selectedStudent
    };
  }

  const userAccessUpdate = async () => {
    updateState({ user: { loading: true } });

    try {
      const accessRes = await GLOBAL_APIS.getUserAccessPermissions();

      // React native: Post UserId to app

      if (
        typeof window !== "undefined" &&
        typeof window.ReactNativeWebView?.postMessage === "function"
      ) {
        const userId = accessRes?.data?.userId;
        window.ReactNativeWebView?.postMessage(JSON.stringify({ type: "USER_ID", userId }));
      }

      const orgId = getOrgId(accessRes?.data as StudentAccessMapProps);
      setOrgId(orgId as string);
      const branchesRes = await GLOBAL_APIS.getBranchesList();
      const defaultBranchId = getDefaultBranchId(accessRes?.data);
      const branchId = getBranchId(branchesRes?.data, defaultBranchId);
      const accessMap = getAccessMap(
        accessRes?.data,
        branchesRes?.data,
        orgId,
        branchId
      );
      const redirected = handleOrgBranchRedirection(accessMap);

      if (!redirected) {
        updateState({
          user: {
            accessMap: accessMap || {},
            loading: false,
          },
        });
        setTimeout(() => {
          getAcademicYearDetails();
        }, 300);
      }
    } finally {}
  };

  useEffect(() => {
    userAccessUpdate();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <GlobalContext.Provider
      value={{
        state: { ...state, globalContextLoading },
        updateState,
        updateAcademicYearList,
        updateCurrentAcademicYear,
        updateBranches,
        updateOrgs,
        updateLoggedInUser,
      }}
    >
      <QueryClientProvider client={queryClient}>
        {children}
      </QueryClientProvider>
    </GlobalContext.Provider>
  );
};

// -------------------- Hook --------------------
export const useGlobalContext = () => {
  const context = useContext(GlobalContext);
  if (!context) {
    throw new Error("useGlobalContext must be used within a GlobalProvider");
  }
  return context;
};
