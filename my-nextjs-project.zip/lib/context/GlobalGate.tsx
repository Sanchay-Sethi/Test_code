"use client";

import { useGlobalContext } from "./GlobalContext";
import BrandLogo from "@/components/reusable/Loader/BrandLogo/BrandLogo";
import { useHasMounted } from "../hooks/useHasMounted";
import { useEffect } from "react";
import { redirect, useParams, usePathname } from "next/navigation";
import HELPERS from "../helpers";

function GlobalGate({ children }: { children: React.ReactNode }) {
  const hydrated = useHasMounted();
  const { orgid = "", branchid = "" } = useParams();

  const { state } = useGlobalContext();
  const pathName = usePathname();

  useEffect(() => {
    if (state?.user?.accessMap?.ROLE === "STUDENT") {
      if (!pathName?.includes("student-view")) {
        const defaultPath = HELPERS.getDefaultPath(
          state.user?.accessMap,
          `${orgid}`,
          `${branchid}`
        );
        redirect(defaultPath || `/home/${orgid}/${branchid}/dashboard`);
      }
    }
  }, [
    state?.user?.accessMap?.ROLE,
    pathName,
    branchid,
    orgid,
    state.user?.accessMap,
  ]);

  if (!hydrated || state.globalContextLoading) {
    return <BrandLogo />;
  }

  return <>{children}</>;
}

export default GlobalGate;
