"use client";

import { useEffect } from "react";
import { useReactNativeAppStore } from "../hooks/useReactNativeAppStore";

const ReactNativeAppProvider = ({
  children,
}: {
  children: React.ReactNode;
}) => {
  const setAppName = useReactNativeAppStore((state) => state?.setAppName);

  useEffect(() => {
    const searchParams = new URLSearchParams(window.location.search);
    const appName = searchParams.get("appName");

    if (appName) {
      setAppName(appName);
    }
  }, [setAppName]);

  return <>{children}</>;
};

export default ReactNativeAppProvider;
