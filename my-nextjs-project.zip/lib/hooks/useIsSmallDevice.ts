"use client"
import { GLOBAL_CONSTANTS } from '@/constants';
import { useState, useEffect } from 'react';

const useIsSmallDevice = (breakpoint: number = GLOBAL_CONSTANTS.HOME_DEFAULT_VALUES.RESPONSIVE_WIDTH): boolean => {
  const [isSmallDevice, setIsSmallDevice] = useState(false);

  useEffect(() => {
    // Prevents error during SSR
    if (typeof window === 'undefined') return;

    const checkDeviceSize = () => {
      setIsSmallDevice(window.innerWidth < breakpoint);
    };

    // Initial check
    checkDeviceSize();

    // Add resize listener
    window.addEventListener('resize', checkDeviceSize);
    return () => window.removeEventListener('resize', checkDeviceSize);
  }, [breakpoint]);

  return isSmallDevice;
};

export default useIsSmallDevice;
