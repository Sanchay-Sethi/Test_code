"use client"

import { useGlobalContext } from "../context/GlobalContext"

export function useGlobalValues() {
    const { state } = useGlobalContext();

    const BRANCHES_OPTIONS = (
        state?.user?.accessMap?.branchesHash || []
    )?.map((val) => {
        return {
            label: val?.name,
            value: val?.id,
        };
    });

    const ORG_OPTIONS = Object?.keys(
        state?.user?.accessMap?.orgIdNameMap || {}
    )?.map((key) => {
        return {
            label: state?.user?.accessMap?.orgIdNameMap?.[key],
            value: key,
        };
    });

    const ACADEMIC_YEAR_OPTIONS = state?.academicYear?.academicYearList;

    const CURRENT_ACADEMIC_YEAR = state?.academicYear?.academicYearId;

    return {
        BRANCHES_OPTIONS, ORG_OPTIONS, ACADEMIC_YEAR_OPTIONS, CURRENT_ACADEMIC_YEAR
    }
}