import { useEffect, useRef } from 'react';
import { usePathname, useSearchParams } from 'next/navigation';

export function usePreviousUrl() {
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const previousUrlRef = useRef<string | null>(null);

  useEffect(() => {
    const currentUrl = `${pathname}?${searchParams.toString()}`;
    previousUrlRef.current = currentUrl;
  }, [pathname, searchParams]);

  return previousUrlRef.current;
}
