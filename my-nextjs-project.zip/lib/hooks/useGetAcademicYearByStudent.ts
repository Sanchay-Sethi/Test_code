import { useQuery } from '@tanstack/react-query';
import apiClient from '../apiClient';

const fetchDataById = async (id: string) => {
    if (!id) throw new Error('ID is required');
    try {
        const res = await apiClient.get(`/student/ay/list/${id}`);
        const academicYearOptions = res?.data?.map(
            (data: { name?: string; id?: string }) => {
                return {
                    label: data?.name,
                    value: data?.id,
                };
            }
        );
        return academicYearOptions;
    } finally { }
};

export const useGetAcademicYearByStudent = (id: string) => {
    return useQuery({
        queryKey: ['data', id],
        queryFn: () => fetchDataById(id),
        enabled: !!id,
    });
};
