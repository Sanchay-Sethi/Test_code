import { create } from "zustand";

type AppStore = {
    appName: string | null;
    setAppName: (appName: string) => void;
};

export const useReactNativeAppStore = create<AppStore>((set) => ({
    appName: null,
    setAppName: (appName) => set({ appName }),
}));
