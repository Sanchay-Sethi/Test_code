import { create } from 'zustand';

type OrgStore = {
  orgId: string | null;
  setOrgId: (orgId: string) => void;
};

export const useOrgStore = create<OrgStore>((set) => ({
  orgId: null,
  setOrgId: (orgId) => set({ orgId }),
}));