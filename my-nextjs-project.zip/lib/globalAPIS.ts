import apiClient from "./apiClient";

async function handleLogout() {
    try {
        await apiClient.delete("/session/logout");
        window.location.href = "/auth/login";
    } catch (error) {
        throw error;
    }
}

async function getUserAccessPermissions() {
    try {
        return await apiClient.get("/user/access")
    } catch (error) {
        throw error;
    }
}

async function getOrgsList() {
    try {
        return await apiClient.get("/org")
    } catch (error) {
        throw error;
    }
}

async function getBranchesList() {
    try {
        return await apiClient.get("/org/branch/listbyid")
    } catch (error) {
        throw error;
    }
}

const GLOBAL_APIS = {
    handleLogout,
    getUserAccessPermissions,
    getOrgsList,
    getBranchesList
}

export default GLOBAL_APIS;