import axios from 'axios';
import '@ant-design/v5-patch-for-react-19';
import NProgress from 'nprogress';
import HELPERS from './helpers';
import 'nprogress/nprogress.css';
import { useOrgStore } from './hooks/useOrgStore';

/*
  This will automatically adds notification of error and success,
  If you want to use your own custom message during API call you can use it like that

  apiClient.METHOD(get/post/put....)(API_URL, PAYLOAD(if any or else don't pass), {
    suppressErrorNotification: true,
  });
*/

NProgress.configure({ showSpinner: false });

const apiClient = axios.create({
  baseURL: HELPERS.getAPI() || '',
  withCredentials: true,
});

// Request
apiClient.interceptors.request.use(
  (config) => {
    NProgress.start();
    const { orgId } = useOrgStore.getState();
    if (orgId) {
      config.headers['skylio-org-id'] = orgId;
    }
    return config;
  },
  (error) => {
    NProgress.done();
    return Promise.reject(error);
  }
);

// Response
apiClient.interceptors.response.use(
  (response) => {
    NProgress.done();
    return response;
  },
  (error) => {
    NProgress.done();

    const config = error?.config as { suppressErrorNotification?: boolean };

    if (!config?.suppressErrorNotification) {
      const message = HELPERS.getErrorMessage(error)

      HELPERS.messageAlert({
        error: message
      })
    }

    // Handle 401 - Authentication Failed
    if (error?.response?.status === 401 && error?.response?.data === "Authentication failed") {
      if (typeof window !== 'undefined') {
        // Clear cookies
        ['skylio-session-id', 'skylio-session-token'].forEach((name) => {
          document.cookie = `${name}=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/`;
        });
        window.location.reload();
      }
    }

    return Promise.reject(error);
  }
);

export default apiClient;
