import { NotificationPlacement } from "antd/es/notification/interface";

interface ShowNotificationProps {
    type?: 'success' | 'info' | 'warning' | 'error'; // AntD supports only these types
    message?: string;
    description?: string;
    autoClose?: boolean;
    btn?: React.ReactNode;
    placement?: NotificationPlacement;
}

interface APIResponse {
    data?: {
        success?: boolean;
        errorMessage?: string;
    };
    response?: {
        data?: {
            success?: boolean;
            errorMessage?: string;
        };
        status?: number;
    };
    status?: number;
    success?: boolean;
    errorMessage?: string;
}

interface MessageAlertProps {
    error?: APIResponse | string | null;
    warning?: APIResponse | string | null;
    success?: APIResponse | string | null;
    info?: APIResponse | string | null;
    msg?: string | null;
    prefix?: string;
    suffix?: string;
    showCloseIcon?: boolean;
    autoClose?: boolean;
    stringMessage?: boolean;
    placement?: NotificationPlacement;
}

interface LabelValueOptionTypes {
    label?: string,
    value?: string
}