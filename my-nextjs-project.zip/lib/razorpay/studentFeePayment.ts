"use client"

import apiClient from "@/lib/apiClient";
import HELPERS from "@/lib/helpers";

const handlePaymentSuccess = async (
  response: RazorPayOptionsProps,
  callback = () => {}
) => {
  try {
    if (
      response?.razorpay_order_id &&
      response?.razorpay_payment_id &&
      response?.razorpay_signature
    ) {
      await apiClient.post(
        `/pg/verify?razorpay_order_id=${response?.razorpay_order_id}&razorpay_payment_id=${response?.razorpay_payment_id}&razorpay_signature=${response?.razorpay_signature}`
      );
      callback();
      HELPERS.messageAlert({ success: "Payment successful!" });
    }
  } finally {
  }
};

export async function handleMakePaymentRazorpay({
  amount,
  studentId,
  academicYearId,
  setLoader = () => {},
  callback = () => {},
}: {
  amount: number;
  studentId?: string;
  academicYearId?: string;
  callback?: () => void;
  setLoader?: (flag: boolean) => void;
}) {
  try {
    setLoader(true);
    const orderRes = await apiClient.post(
      `/pg/order/${studentId}/${academicYearId}`,
      amount,
      {
        headers: { "Content-Type": "application/json" },
      }
    );
    const order = orderRes.data;

    setLoader(false);

    if (!order?.orderId) {
      HELPERS.messageAlert({ error: "Failed to create Razorpay order" });
      return;
    }

    const razorpayOptions: RazorpayOptions = {
      key: order?.keyId,
      amount: order?.amount,
      currency: order?.currency || "INR",
      name: order?.orgName,
      description: "Payment",
      order_id: order?.orderId,
      receipt: `${order?.studentName}_${order?.orgName}_payment_reciept`,
      handler: function (response) {
        handlePaymentSuccess(response as RazorPayOptionsProps, callback);
      },
      prefill: {
        name: order?.studentName,
      },
      theme: {
        color: "#5469D4",
      },
    };

    if (typeof window !== "undefined" && window.Razorpay) {
      const razorpay = new window.Razorpay(razorpayOptions);
      razorpay.open();
    }
  } catch (error) {
    console.log({ PAYMENT_ISSUE: error });
  }
}
