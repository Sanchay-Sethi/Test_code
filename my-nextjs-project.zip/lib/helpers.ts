// import { parsePhoneNumberFromString } from 'libphonenumber-js';
import axios, { AxiosError } from "axios";
import { GLOBAL_CONSTANTS } from "@/constants";
import { notification } from "antd";
import { APIResponse, MessageAlertProps, ShowNotificationProps } from "./Types";
import { ArgsProps } from "antd/es/notification";
import { getMenuItems } from "@/components/home/Sidebar/Helpers.Sidebar";
import { StudentAccessMapProps } from "@/types";

const entityPattern = /&#?([a-z0-9]+);/gi;

const entities = {
    amp: "&",
    apos: "'",
    lt: "<",
    gt: ">",
    quot: '"',
    nbsp: "\xa0",
    comma: ",",
};

const getBaseURL = () => {
    if (typeof window !== "undefined") {
        const hostname = window.location.hostname;
        if (hostname === "localhost") {
            return GLOBAL_CONSTANTS.BASE_LOCAL_URL;
        }
        return window.location.origin;
    }
    return (
        process.env.NEXT_PUBLIC_API_BASE_URL || GLOBAL_CONSTANTS.BASE_LOCAL_URL
    );
};

const getAPI = () => getBaseURL() + "/api";

const axiosInstance = axios.create({
    baseURL: getAPI(),
    withCredentials: true,
});

const validateEmailPhone = (value = "") => {
    const trimmed = value?.trim();

    if (value === "") {
        return {
            error: "Please enter valid value",
            value: "",
        };
    }

    // Quick check if input looks like phone (digits, +, spaces, dashes)
    const phoneLike = /^[+\d\s\-()]+$/.test(trimmed);
    if (phoneLike) {
        // const phone = parsePhoneNumberFromString(trimmed);
        // if (phone && phone?.isValid()) {
        // }
        return {
            error: "",
            value: trimmed,
        };
        return {
            error: "Please enter a valid phone number",
            value: "",
        };
    }

    // Check if input looks like email
    const emailLike = trimmed?.includes("@");
    if (emailLike) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (emailRegex?.test(trimmed)) {
            return {
                error: "",
                value: trimmed,
            };
        }
        return {
            error: "Please enter a valid email address",
            value: "",
        };
    }

    return {
        error: "Please enter a valid email or phone number",
        value: "",
    };
};

const darkenColor = (hex: string, percent: number = 10): string => {
    if (!hex) return "";
    hex = hex.replace(/^#/, "");

    // Parse r, g, b values
    const r = parseInt(hex?.substring(0, 2), 16);
    const g = parseInt(hex?.substring(2, 4), 16);
    const b = parseInt(hex?.substring(4, 6), 16);

    // Calculate darker color components
    const newR = Math.max(0, Math.floor(r * (1 - percent / 100)));
    const newG = Math.max(0, Math.floor(g * (1 - percent / 100)));
    const newB = Math.max(0, Math.floor(b * (1 - percent / 100)));

    // Convert back to hex string
    const toHex = (c: number): string => c?.toString(16)?.padStart(2, "0");

    return `#${toHex(newR)}${toHex(newG)}${toHex(newB)}`;
};

const capitalizeFirst = (str: string): string =>
    str?.charAt(0)?.toUpperCase() + str?.slice(1)?.toLowerCase();

const decodeFromHTML = (text = "") => {
    // A single replace pass with a static RegExp is faster than a loop
    if (Object.prototype.toString.call(text) === "[object String]") {
        return text.replace(entityPattern, function (match, entity) {
            entity = entity?.toLowerCase();
            if (entities.hasOwnProperty(entity)) {
                return entities?.[entity as keyof typeof entities];
            } else {
                return String?.fromCharCode(entity);
            }
        });
    }
    return text;
};
const showNotification = ({
    type = 'info',
    message,
    description,
    autoClose = true,
    btn,
    placement,
}: ShowNotificationProps): void => {
    if (!notification[type]) return;

    notification[type]({
        message,
        description,
        btn,
        duration: autoClose ? 5 : null,
        placement,
    } as ArgsProps);

    notification.config({
        maxCount: 10,
    });
};

const messageAlert = ({
    error = null,
    warning = null,
    success = null,
    info = null,
    msg = null,
    prefix = '',
    suffix = '',
    showCloseIcon = false,
    autoClose = true,
    stringMessage = true,
    placement = 'topRight',
}: MessageAlertProps): void => {
    let message: string | null = null;
    let isSuccess: boolean | undefined;
    let OkAlert: APIResponse | string | null = success || info;

    // Normalize `OkAlert` for success/info
    if (OkAlert && typeof OkAlert !== 'string') {
        if (
            OkAlert.data?.success !== undefined &&
            OkAlert.data?.errorMessage &&
            OkAlert.status === 200
        ) {
            OkAlert = OkAlert.data;
        } else if (
            OkAlert.response?.data?.success !== undefined &&
            OkAlert.response?.data?.errorMessage &&
            OkAlert.response?.status === 200
        ) {
            OkAlert = OkAlert.response.data;
        }

        if ('success' in OkAlert && 'errorMessage' in OkAlert) {
            isSuccess = OkAlert.success;
        }
    }

    if (success && isSuccess === false) {
        message = (OkAlert as APIResponse)?.errorMessage || null;
        error = '';
        prefix = '';
        suffix = '';
    }

    if (success && isSuccess !== false) {
        message = msg || (typeof success === 'string' ? `${prefix}${success}${suffix}` : 'success...');
        showNotification({
            type: 'success',
            message: 'Success',
            description: decodeFromHTML(message),
            autoClose,
            btn: showCloseIcon,
            placement,
        });
        return;
    }

    if (info && isSuccess !== false) {
        message = msg || (typeof info === 'string' ? `${prefix}${info}${suffix}` : 'Alert...');
        showNotification({
            type: 'info',
            message: 'Information',
            description: decodeFromHTML(message),
            autoClose,
            btn: showCloseIcon,
            placement,
        });
        return;
    }

    const status =
        (typeof error === 'object' && error?.response?.status) ||
        (typeof warning === 'object' && warning?.response?.status) ||
        null;

    isSuccess =
        (typeof error === 'object' && (error?.response?.data?.success || error?.success)) ||
        (typeof warning === 'object' && (warning?.response?.data?.success || warning?.success)) ||
        false;

    if (status === 200 && isSuccess === true) return;

    if (warning) {
        if (typeof warning === 'string') {
            message = `${prefix}${warning}${suffix}`;
        } else {
            message =
                warning?.response?.data?.errorMessage ||
                warning?.errorMessage ||
                'Problem in Performing the Request';
            message = `${prefix}${message}${suffix}`;
        }

        showNotification({
            type: 'warning',
            message: 'Warning',
            description: decodeFromHTML(message),
            autoClose,
            btn: showCloseIcon,
            placement,
        });
        return;
    }

    if (error) {
        if (stringMessage) {
            if (typeof error === 'string') {
                message = `${prefix}${error}${suffix}`;
            } else {
                message =
                    error?.response?.data?.errorMessage || error?.errorMessage || 'Error in Performing the Request';
                message = `${prefix}${message}${suffix}`;
            }

            showNotification({
                type: 'error',
                message: 'Error',
                description: decodeFromHTML(message),
                autoClose: false,
                btn: showCloseIcon,
                placement,
            });
        } else {
            showNotification({
                type: 'error',
                message: 'Error',
                description: typeof error === 'string' ? error : JSON.stringify(error),
                autoClose: false,
                btn: showCloseIcon,
                placement,
            });
        }
        return;
    }

    if (msg) {
        message = `${prefix}${msg}${suffix}`;
        showNotification({
            type: 'info',
            message: 'Information',
            description: decodeFromHTML(message),
            autoClose,
            btn: showCloseIcon,
            placement,
        });
    }
};

function getRelativePath(path: string) {
    const match = path.match(/^\/home\/[^/]+\/[^/]+(\/.*)?$/);
    return match?.[1] || '/';
}

function getErrorMessage(error: AxiosError) {
    if (error?.response?.data) {
        if (typeof error?.response?.data === "string") {
            return error?.response?.data;
        }
        const errorData = error?.response?.data as { errors?: string[] };
        if (errorData?.errors && Array.isArray(errorData?.errors)) {
            if (errorData?.errors?.length === 1) {
                return errorData?.errors?.[0];
            }
            return errorData?.errors.map((msg: string, index = 0) => `${index + 1}. ${msg}`)?.join('\n');
        }
        return JSON.stringify(error?.response?.data)
    }
    return error?.message || 'Something went wrong';
}

function getDefaultPath(accessMap = {}, orgId = "", branchId = "") {
    if (!accessMap || Object.keys(accessMap || {})?.length === 0) {
        return "";
    }
    const MENU_HASH = getMenuItems("", "", accessMap as StudentAccessMapProps);
    return `/home/${orgId}/${branchId}${MENU_HASH?.[0]?.key || "/dashboard"}`
}

function formatDate(input: Date | string): string | null {
  let date: Date;
  if (input instanceof Date && !isNaN(input.getTime())) {
    date = input;
  } else if (typeof input === "string" && !isNaN(Date.parse(input))) {
    date = new Date(input);
  } else {
    return null;
  }

  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");

  return `${year}-${month}-${day}`;
}

const HELPERS = {
    axiosInstance,
    getAPI,
    getBaseURL,
    validateEmailPhone,
    darkenColor,
    capitalizeFirst,
    showNotification,
    messageAlert,
    getRelativePath,
    getErrorMessage,
    getDefaultPath,
    formatDate
};

export default HELPERS;
