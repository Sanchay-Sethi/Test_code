"use client";
import { redirect } from 'next/navigation';

const Custom404 = () => {
  redirect('/auth/login')
}

export default Custom404