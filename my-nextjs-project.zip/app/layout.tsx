import type { Metadata } from "next";
import { inter } from "../fonts/font";
import "@ant-design/v5-patch-for-react-19";
import { AntdRegistry } from "@ant-design/nextjs-registry";
import { Karla } from "next/font/google";
import "./globals.css";
import "./scrollbar.css";
import { NavigationProvider } from "@/lib/context/NavigationContext";
import GlobalLoader from "@/components/reusable/Loader/GlobalLoader";
import Script from "next/script";
import ReactNativeAppProvider from "@/lib/context/ReactNativeAppProvider";

const geistKarla = Karla({
  variable: "--font-geist-karla",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Skylio",
  description: "School ERP platform",
  icons: {
    icon: "/assets/icons/logos/general/company-logo-purple-latest.svg",
  },
};

export default function Layout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <head>
        <Script
          src="https://checkout.razorpay.com/v1/checkout.js"
          strategy="afterInteractive"
        />
      </head>
      <body
        className={`${geistKarla.variable} ${inter.variable} font-karla antialiased skylio-scrollbar`}
      >
        <ReactNativeAppProvider>
          <AntdRegistry>
            <NavigationProvider>
              <GlobalLoader />
              {children}
            </NavigationProvider>
          </AntdRegistry>
        </ReactNativeAppProvider>
      </body>
    </html>
  );
}
