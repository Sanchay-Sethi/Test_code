"use client";
import { useEffect, useState } from "react";
import { redirect } from "next/navigation";
import BrandLogo from "@/components/reusable/Loader/BrandLogo/BrandLogo";
import { GLOBAL_APIS } from "@/lib";
import { useOrgStore } from "@/lib/hooks/useOrgStore";

export default function HomeRootPage() {
  const setOrgId = useOrgStore((state) => state?.setOrgId);
  const [message, setMessage] = useState("");

  useEffect(() => {
    (async () => {
      try {
        const accessRes = await GLOBAL_APIS.getUserAccessPermissions();
        const branchesRes = await GLOBAL_APIS.getBranchesList();

        const defaultOrg = Object?.keys(accessRes?.data?.orgIdNameMap || {})?.[0];
        const defaultBranch = branchesRes?.data?.[0]?.id;

        if (defaultOrg && defaultBranch) {
          setOrgId(defaultOrg);
          redirect(`/home/${defaultOrg}/${defaultBranch}`);
        } else {
          // THIS CASE WILL NOT HAPPEN USUALLY
          setMessage("Access denied. Try clearing the cache and reload.")
        }
      } finally {
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return <BrandLogo message = {message}/>;
}
