import type { Metadata } from "next";
import { Karla } from "next/font/google";
import { Layout } from "antd";
import "@ant-design/v5-patch-for-react-19";
import { AntdRegistry } from "@ant-design/nextjs-registry";
import { GlobalProvider } from "@/lib/context/GlobalContext";
import GlobalGate from "@/lib/context/GlobalGate";
import { ThemeProvider, ThemeWrapper } from "@/lib/context/ThemeContext";
import Sidebar from "@/components/home/Sidebar/Sidebar";
import HomeParentWrapper, { ClientHydrationWrapper } from "@/components/home";
import { inter } from "../../../../fonts/font";
import MobileNavbar from "@/components/home/MobileNavbar/MobileNavbar";

const geistKarla = Karla({
  variable: "--font-geist-karla",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Home | Skylio",
  description: "School ERP platform",
  icons: {
    icon: "/assets/icons/logos/general/company-logo-purple-latest.svg",
  },
};

export default function HomeLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body
        className={`${geistKarla.variable} ${inter.variable} font-karla antialiased`}
      >
        <GlobalProvider>
          <ThemeProvider>
            <ThemeWrapper>
              <AntdRegistry>
                <Layout>
                  <ClientHydrationWrapper>
                    <Sidebar />
                  </ClientHydrationWrapper>
                  <Layout>
                    <MobileNavbar />
                    <HomeParentWrapper>
                      <GlobalGate>{children}</GlobalGate>
                    </HomeParentWrapper>
                  </Layout>
                </Layout>
              </AntdRegistry>
            </ThemeWrapper>
          </ThemeProvider>
        </GlobalProvider>
      </body>
    </html>
  );
}