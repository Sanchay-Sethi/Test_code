import StudentForm from "@/components/home/Students/Student/StudentForm"

const StudentCreationPage = () => {
  return (
    <StudentForm/>
  )
}

export default StudentCreationPage