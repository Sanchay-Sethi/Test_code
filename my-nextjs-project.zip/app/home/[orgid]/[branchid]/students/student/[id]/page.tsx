import Student from "@/components/home/Students/Student/Student";
interface StudentDetailPageProps {
  params: Promise<{ id: string; }>;
}

const page = async ({ params }: StudentDetailPageProps) => {
  const { id } = await params;
  return <Student id={id} />;
};

export default page;
