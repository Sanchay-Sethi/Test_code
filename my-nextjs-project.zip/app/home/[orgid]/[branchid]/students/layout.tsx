import { inter } from "@/fonts/font";
import { StudentsProvider } from "@/lib/context/students/StudentsContext";
import type { Metadata } from "next";
import { Karla } from "next/font/google";

const geistKarla = Karla({
  variable: "--font-geist-karla",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Students | Skylio",
  description: "Students listing/details",
};

export default function StudentsLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className={`${geistKarla.variable} ${inter.variable} font-karla antialiased`}>
        <StudentsProvider>{children}</StudentsProvider>
      </body>
    </html>
  );
}
