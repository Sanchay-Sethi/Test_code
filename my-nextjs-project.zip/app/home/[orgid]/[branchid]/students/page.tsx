import Students from "@/components/home/Students/Students"

const StudentsPage = () => {
  return (
    <Students />
  )
}

export default StudentsPage