import Fees from "@/components/home/StudentView/Fees/Fees"

const StudentFeesPage = () => {
  return (
    <Fees />
  )
}

export default StudentFeesPage