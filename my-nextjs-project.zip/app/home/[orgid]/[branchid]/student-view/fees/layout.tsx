import { inter } from "@/fonts/font";
import type { Metadata } from "next";
import { Karla } from "next/font/google";

const geistKarla = Karla({
  variable: "--font-geist-karla",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Student fee | Skylio",
  description: "Student fee skylio",
};

export default function StudentFeesLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className={`${geistKarla.variable} ${inter.variable} font-karla antialiased`}>
        {children}
      </body>
    </html>
  );
}
