import Announcements from "@/components/home/Announcements/Announcements";

interface AnnouncementsWithIdPageProps {
  params: Promise<{ id: string }>;
}

const StudentAnnouncementsWithIdPage = async ({
  params,
}: AnnouncementsWithIdPageProps) => {
  const { id } = await params;
  return <Announcements id={id} isStudent/>;
};

export default StudentAnnouncementsWithIdPage;
