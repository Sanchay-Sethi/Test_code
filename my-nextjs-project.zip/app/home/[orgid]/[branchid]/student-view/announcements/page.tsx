"use client";

import Announcements from "@/components/home/Announcements/Announcements";
import { useGlobalContext } from "@/lib/context/GlobalContext";

const StudentAnnouncementsPage = () => {
  const { state } = useGlobalContext();
  const isStudent = state?.user?.accessMap?.ROLE === "STUDENT";
  return <Announcements isStudent={isStudent} />;
};

export default StudentAnnouncementsPage;
