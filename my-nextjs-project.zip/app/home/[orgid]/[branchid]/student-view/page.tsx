"use client"
import { redirect, useParams } from "next/navigation";

const StudentView = () => {
  const { orgid = "", branchid = "" } = useParams();
  return redirect(`/home/${orgid}/${branchid}/student-view/profile`);
};

export default StudentView;
