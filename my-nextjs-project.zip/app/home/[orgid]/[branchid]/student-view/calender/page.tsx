"use client";

import AcademicCalender from "@/components/home/AcademicCalender/AcademicCalender";
import { useGlobalContext } from "@/lib/context/GlobalContext";

const StudentCalenderPage = () => {
  const { state } = useGlobalContext();
  const isStudent = state?.user?.accessMap?.ROLE === "STUDENT";
  return <AcademicCalender isStudent={isStudent} />;
};

export default StudentCalenderPage;
