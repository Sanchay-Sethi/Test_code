import Profile from "@/components/home/StudentView/Profile/Profile"

const StudentProfilePage = () => {
  return (
    <Profile />
  )
}

export default StudentProfilePage