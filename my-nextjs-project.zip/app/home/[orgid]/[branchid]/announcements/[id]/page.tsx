import Announcements from "@/components/home/Announcements/Announcements";

interface AnnouncementsWithIdPageProps {
  params: Promise<{ id: string }>;
}

const AnnouncementsWithIdPage = async ({
  params,
}: AnnouncementsWithIdPageProps) => {
  const { id } = await params;
  return <Announcements id={id} />;
};

export default AnnouncementsWithIdPage;
