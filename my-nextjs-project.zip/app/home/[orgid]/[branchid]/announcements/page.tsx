import Announcements from "@/components/home/Announcements/Announcements";

const AnnouncementsPage = () => {
  return <Announcements />;
};

export default AnnouncementsPage;
