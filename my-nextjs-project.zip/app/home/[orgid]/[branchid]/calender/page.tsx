import AcademicCalender from "@/components/home/AcademicCalender/AcademicCalender";

const CalenderPage = () => {
  return <AcademicCalender />;
};

export default CalenderPage;
