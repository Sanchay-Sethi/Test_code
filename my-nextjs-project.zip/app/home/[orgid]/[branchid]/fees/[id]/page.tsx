import StudentFee from "@/components/home/Fee/StudentFee";

interface FeeWithIdPageProps {
  params: Promise<{ id: string; }>;
}

const FeeWithIdPage = async ({ params }: FeeWithIdPageProps) => {
  const { id } = await params;

  return <StudentFee id={id} />;
};

export default FeeWithIdPage;
