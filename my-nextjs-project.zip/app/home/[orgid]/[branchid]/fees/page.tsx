import Fee from "@/components/home/Fee/Fee";

const FeePage = () => {
  return <Fee />;
};

export default FeePage;
