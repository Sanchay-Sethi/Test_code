import StudentsPayment from "@/components/home/Settings/Payments/StudentsPayment/StudentsPayment"

const StudentsPaymentPage = () => {
  return (
    <StudentsPayment />
  )
}

export default StudentsPaymentPage