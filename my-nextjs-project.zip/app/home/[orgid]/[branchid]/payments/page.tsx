import Payments from "@/components/home/Settings/Payments/Payments"

const PaymentsPage = () => {
  return (
    <Payments />
  )
}

export default PaymentsPage