"use client";

import { GENERAL_COMPONENTS } from "@/components/common";

const Custom404 = () => {
  return (
    <div className="w-full h-full flex justify-center items-center">
      <GENERAL_COMPONENTS.Error404/>
    </div>
  )
}

export default Custom404