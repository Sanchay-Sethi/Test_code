import School from "@/components/home/Settings/School/School"

const SchoolSettings = () => {
  return (
    <School />
  )
}

export default SchoolSettings