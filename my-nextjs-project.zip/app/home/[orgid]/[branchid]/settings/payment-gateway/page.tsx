import PaymentGateway from "@/components/home/Settings/PaymentGateway/PaymentGateway"

const PaymentGatewayPage = () => {
  return (
    <PaymentGateway />
  )
}

export default PaymentGatewayPage