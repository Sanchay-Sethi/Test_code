import Program from "@/components/home/Settings/Program/Program"

const ProgramSettingsPage = () => {
  return (
    <Program />
  )
}

export default ProgramSettingsPage