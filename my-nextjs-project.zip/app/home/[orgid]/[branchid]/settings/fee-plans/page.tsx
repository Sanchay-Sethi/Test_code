import FeePlans from "@/components/home/Settings/FeePlans/FeePlans"

const FeePlanPage = () => {
  return (
    <FeePlans/>
  )
}

export default FeePlanPage