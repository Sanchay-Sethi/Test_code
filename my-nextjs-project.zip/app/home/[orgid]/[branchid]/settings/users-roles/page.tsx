import UserRoles from "@/components/home/Settings/UserRoles/UserRoles"

const UserRolesSettings = () => {
  return (
    <UserRoles />
  )
}

export default UserRolesSettings