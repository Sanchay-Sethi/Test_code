import RolesPermissions from "@/components/home/Settings/UserRoles/RolesPermissions/RolesPermissions"

const RolesSettings = () => {
  return (
    <RolesPermissions />
  )
}

export default RolesSettings