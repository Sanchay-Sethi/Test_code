import RolesPermissions from "@/components/home/Settings/UserRoles/RolesPermissions/RolesPermissions";

interface PageProps {
  params: Promise<{ id: string; }>;
}

const RolesSettingsWithId = async ({ params }: PageProps) => {
  const { id } = await params;
  return <RolesPermissions id={id} />;
};

export default RolesSettingsWithId;
