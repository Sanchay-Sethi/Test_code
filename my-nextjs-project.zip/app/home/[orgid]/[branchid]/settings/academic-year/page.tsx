import AcademicYear from "@/components/home/Settings/AcademicYear/AcademicYear"

const AcademicYearSettings = () => {
  return (
    <AcademicYear />
  )
}

export default AcademicYearSettings