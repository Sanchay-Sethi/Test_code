import FeeStructures from "@/components/home/Settings/FeeStructures/FeeStructures"

const FeeStructuresSettings = () => {
  return (
    <FeeStructures />
  )
}

export default FeeStructuresSettings