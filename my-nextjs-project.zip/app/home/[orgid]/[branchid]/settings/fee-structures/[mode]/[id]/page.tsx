import FeeStructuresMode from "@/components/home/Settings/FeeStructures/FeeStructuresMode";

interface PageProps {
  params: Promise<{ mode: string, id: string, }>;
}

const FeeStructuresModeIdSettings = async ({ params }: PageProps) => {
  const { mode, id } = await params;
  return <FeeStructuresMode mode={mode} id = {id}/>;
};

export default FeeStructuresModeIdSettings;