import FeeStructuresMode from "@/components/home/Settings/FeeStructures/FeeStructuresMode";

interface PageProps {
  params: Promise<{ mode: string }>;
}

const FeeStructuresModeSettings = async ({ params }: PageProps) => {
  const { mode } = await params;
  return <FeeStructuresMode mode={mode} />;
};

export default FeeStructuresModeSettings;
