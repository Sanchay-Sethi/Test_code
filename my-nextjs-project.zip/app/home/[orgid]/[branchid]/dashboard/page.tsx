import UnderConstructionPage from '@/components/reusable/StaticMessages/UnderConstructionPage'

const page = () => {
  return (
    <UnderConstructionPage/>
  )
}

export default page