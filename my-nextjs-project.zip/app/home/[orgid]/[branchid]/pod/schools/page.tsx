import Schools from "@/components/home/Pod/Schools/Schools"

const SchoolsPodPage = () => {
  return (
    <Schools />
  )
}

export default SchoolsPodPage