import Admins from "@/components/home/Pod/Admins/Admins"

const AdminsPodPage = () => {
  return (
    <Admins />
  )
}

export default AdminsPodPage