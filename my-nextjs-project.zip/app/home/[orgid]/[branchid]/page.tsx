"use client"

import { useEffect } from 'react';
import { redirect, useParams } from 'next/navigation';
import { useGlobalContext } from '@/lib/context/GlobalContext';
import BrandLogo from '@/components/reusable/Loader/BrandLogo/BrandLogo';
import HELPERS from '@/lib/helpers';

export default function OrgBranchPage() {
  const { orgid = "", branchid = "" } = useParams();
  const { state } = useGlobalContext();

  useEffect(() => {
    (() => {
      if (
        state.user?.accessMap &&
        Object?.keys(state.user?.accessMap)?.length >= 0 && orgid && branchid
      ) {
        const defaultPath = HELPERS.getDefaultPath(
          state.user?.accessMap,
          `${orgid}`,
          `${branchid}`
        );
        redirect(defaultPath || `/home/${orgid}/${branchid}/dashboard`);
      }
    })();
  }, [state.user?.accessMap, orgid, branchid]);

  return <BrandLogo />;
}
