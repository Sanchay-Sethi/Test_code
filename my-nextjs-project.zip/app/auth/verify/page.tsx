"use client";

import { useState, useEffect } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import { AuthBox } from "@/components/authentication/AuthenticationComponents";
import { GLOBAL_CONSTANTS } from "@/constants";
import apiClient from "@/lib/apiClient";

export default function VerifyPage() {
  const searchParams = useSearchParams();
  const emailOrMobile = searchParams.get("emailOrMobile") || "";
  const router = useRouter();
  
  const [otp, setOtp] = useState("");
  const [loading, setLoading] = useState(false);
  
  useEffect(() => {
    if (!emailOrMobile) {
      router.replace("/auth/login");
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [emailOrMobile]);

  function handleOTPChange(value = "") {
    setOtp(value);
  }

  const handleVerifyOtp = async () => {
    try {
      setLoading(true);
      const res = await apiClient.post(`/session/login`, {
        emailOrMobile,
        otp
      });
      if (res) {
        const redirectParam = searchParams.get('redirect')
        const redirectPath = redirectParam ? decodeURIComponent(redirectParam) : '/home'
        window.location.href = redirectPath
      }
    } finally {
      setLoading(false);
    }
  };

  const handleResendOtp = async () => {
   try {
      await apiClient.post(`/session/otp/${emailOrMobile}`)
    } catch {}
  };

  const handleBackButtonClick = () => {
   router.push("/auth/login");
  };

  return (
    <div className="w-[100%] h-[100%] flex justify-center items-start md:items-center pt-[20%] md:pt-0">
      <AuthBox
        type="otp"
        emailOrMobile={emailOrMobile}
        loading = {loading}
        onChange={handleOTPChange}
        onSubmit={handleVerifyOtp}
        onResendOTP={handleResendOtp}
        onBackButtonClick={handleBackButtonClick}
        submitButtonEnabled={!!otp && otp?.length === GLOBAL_CONSTANTS.OTP_MAX_LENGTH}
      />
    </div>
  );
}
