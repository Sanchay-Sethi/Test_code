import type { Metadata } from "next";
import { Karla } from "next/font/google";
import '@ant-design/v5-patch-for-react-19';
import { inter } from "../../fonts/font";
import { ClientHydrationWrapper } from "@/components/home";
import { AuthParentWrapper } from "@/components/authentication/AuthenticationComponents";
import "../globals.css";

const geistKarla = Karla({
  variable: "--font-geist-karla",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Skylio Auth",
  description: "Login to access the platform",
  icons: {
    icon: "/assets/icons/logos/general/company-logo-purple-latest.svg",
  },
};

export default function AuthLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body
        className={`${geistKarla.variable} ${inter.variable} font-karla antialiased`}
      >
        <AuthParentWrapper>
          <ClientHydrationWrapper>{children}</ClientHydrationWrapper>
        </AuthParentWrapper>
      </body>
    </html>
  );
}
