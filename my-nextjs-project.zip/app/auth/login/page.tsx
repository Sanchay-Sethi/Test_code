"use client";

import { useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { AuthBox } from "@/components/authentication/AuthenticationComponents";
import apiClient from "@/lib/apiClient";
import HELPERS from "@/lib/helpers";

export default function LoginPage() {
  const searchParams = useSearchParams();
  const [emailOrMobile, setEmailOrMobile] = useState("");
  const [loading, setLoading] = useState(false);
  const router = useRouter();
  function handleEmailOrMobileChange(value = "") {
    setEmailOrMobile(value);
  }

  const handleSendOtp = async () => {
    const { error = "", value = "" } =
      HELPERS.validateEmailPhone(emailOrMobile);
    if (error?.length) {
      return;
    }
    try {
      setLoading(true);
      await apiClient.post(`/session/otp/${value}`);
      const redirectPath = searchParams.get("redirect");
      if (redirectPath) {
        router.replace(
          `/auth/verify?emailOrMobile=${value}&redirect=${redirectPath}`
        );
      } else {
        router.push(`/auth/verify?emailOrMobile=${value}`);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-[100%] h-[100%] flex justify-center items-start md:items-center pt-[20%] md:pt-0">
      <AuthBox
        type="login"
        emailOrMobile={emailOrMobile}
        submitButtonEnabled={!!emailOrMobile?.trim()}
        onChange={handleEmailOrMobileChange}
        onSubmit={handleSendOtp}
        loading={loading}
      />
    </div>
  );
}
